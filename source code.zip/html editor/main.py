import webview
import sys
import os
import tempfile
import webbrowser

# This class acts as the bridge between your JS frontend and Python backend
class PageforgeAPI:
    def __init__(self):
        pass

    def log_to_python(self, message):
        print(f"[Frontend Log]: {message}")
        return "Message received by Python"

    def save_file(self, filename, content):
        """
        Opens a native Save dialog and writes `content` to the chosen path.

        The JS side used to trigger downloads via a blob: URL + a hidden
        <a download> click, but pywebview's embedded WebView2 doesn't have
        a download handler wired up for that — it hands blob: links off to
        Windows' "Open with" resolver, which fails ("no app can open this
        link"). Doing the save natively in Python sidesteps that entirely.
        """
        try:
            result = webview.windows[0].create_file_dialog(
                webview.SAVE_DIALOG,
                save_filename=filename or "export.html"
            )

            if not result:
                return {"ok": False, "cancelled": True}

            path = result if isinstance(result, str) else result[0]

            with open(path, "w", encoding="utf-8") as f:
                f.write(content)

            return {"ok": True, "path": path}

        except Exception as e:
            return {"ok": False, "error": str(e)}

    def preview_html(self, content):
        """
        Writes `content` to a temp .html file and opens it in the system's
        default browser. Same reasoning as save_file(): window.open() on a
        blob: URL doesn't work in this embedded webview, so we hand off to
        a real browser instead — which also happens to be a more honest
        preview of the exported page anyway.
        """
        try:
            fd, path = tempfile.mkstemp(suffix=".html", prefix="pageforge_preview_")

            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(content)

            webbrowser.open("file://" + path)

            return {"ok": True}

        except Exception as e:
            return {"ok": False, "error": str(e)}

def get_asset_path(relative_path):
    # PyInstaller creates a temporary folder and stores the path in _MEIPASS
    # This ensures the app finds the 'web' folder whether running normally or as an .exe
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

if __name__ == '__main__':
    api = PageforgeAPI()
    
    # Safely resolve the absolute path to your index.html
    html_path = get_asset_path(os.path.join('web', 'index.html'))
    
    # Initialize the native OS window
    window = webview.create_window(
        'Pageforge',
        url=f"file://{html_path}",
        js_api=api,
        width=1280,
        height=800,
        min_size=(900, 600),
        background_color='#1A1A1A'
    )
    
    webview.start(debug=False)