// web/app.js
//
// NOTE: this file is loaded as a plain classic script (no type="module").
// pywebview on Windows renders via Edge WebView2 (Chromium), which blocks
// ES module `import` statements when the page is served over file:// —
// the import fetches are treated as cross-origin from a "null" origin and
// get silently blocked by CORS, so none of the app code ever ran. All
// editor/control files are now loaded via plain <script> tags in
// index.html, in dependency order, before this file.

// 1. Initialize all managers once the DOM is fully loaded
window.addEventListener("DOMContentLoaded", () => {

    // NOTE: always call these via window.X.initialize(), never the bare
    // class name — several classes (Registry, Renderer, Inspector, Binder)
    // are declared with the exact same name as the global instance, so a
    // bare reference resolves to the class itself (shadowing the window
    // property) and .initialize is an instance method, not static.

    if (window.Registry?.initialize)
        window.Registry.initialize();

    if (window.Renderer?.initialize)
        window.Renderer.initialize();

    if (window.Selection?.initialize)
        window.Selection.initialize();

    if (window.Inspector?.initialize)
        window.Inspector.initialize();

    if (window.Canvas?.initialize)
        window.Canvas.initialize();

    if (window.ResizeHandles?.initialize)
        window.ResizeHandles.initialize();

    if (window.History?.initialize)
        window.History.initialize();

    if (window.Binder?.initialize)
        window.Binder.initialize();

    if (window.Settings?.initialize)
        window.Settings.initialize();

    if (window.Logic?.initialize)
        window.Logic.initialize();

    if (window.Animation?.initialize)
        window.Animation.initialize();

    if (window.HoverFX?.initialize)
        window.HoverFX.initialize();

    if (window.Responsive?.initialize)
        window.Responsive.initialize();

    window.Responsive?.onChange(() => {

        const tag = window.Selection?.getTag?.();

        if (tag)
            window.Renderer?.render(tag);

    });

    bindTopBar();

    // Static chrome (index.html's data-i18n elements) is re-applied by
    // I18n.setLang() itself. Dynamic panels built by JS — the inspector
    // and the animation timeline — need an explicit rebuild so their
    // already-baked translated strings refresh too.
    window.I18n?.onChange(() => {

        const tag = window.Selection?.getTag?.();

        if (tag) {

            window.Renderer?.render(tag);

            window.Binder?.refresh();

        } else if (window.Inspector?.title) {

            window.Inspector.title.textContent = t("inspector_no_selection");

        }

        if (window.Animation?.currentEl)
            window.Animation.render();

    });

    console.log("Pageforge initialized successfully.");

    // Show the start screen last, once everything else is wired up.
    window.StartScreen?.show();

});

// Page-level metadata set from the start screen, used when exporting.
window.pageSettings = { title: t("Página sin título") };

// 3. Build a clean, standalone HTML document from the current canvas
function getExportHtml() {

    const canvas = document.getElementById("canvas");

    // If the animation timeline is mid-scrub, restore the real element's
    // style first — otherwise the clone below would freeze on whatever
    // frame the playhead happened to be parked on.
    window.Animation?.resetPreviewStyle();

    const clone = canvas.cloneNode(true);

    clone.removeAttribute("id");

    clone.querySelectorAll("*").forEach(el => {

        el.classList.remove("selected", "hovered", "dragging", "canvas-movable", "free-dragging");

        el.removeAttribute("draggable");

    });

    const bg = canvas.style.backgroundColor || window.getComputedStyle(canvas).backgroundColor;

    // While previewing Tablet/Mobile in the editor, canvas.style.maxWidth
    // temporarily holds the *preview* width (see responsive.js's
    // setBreakpoint) — the exported page's base layout must always use the
    // real Desktop width, with breakpoint-specific sizing left to the
    // @media blocks below.
    const maxWidth = (window.Responsive && window.Responsive.current !== "desktop")
        ? (window.Responsive._desktopWidth || "900px")
        : (canvas.style.maxWidth || "900px");

    const title = window.pageSettings?.title || t("Página exportada");

    // Logic rules (see logic.js) get turned into real event listeners here,
    // scoped to this exported document — they're never active on the
    // editing canvas itself (that would fight with element selection).
    const logicScript = window.Logic?.buildRuntimeScript
        ? window.Logic.buildRuntimeScript(clone)
        : "";

    // Keyframe animations (see animation.js) compile down to real CSS
    // @keyframes here — autoplay is pure CSS (animation-play-state), no
    // JS needed unless a Logic rule also triggers "Reproducir animación".
    const animationCss = window.Animation?.buildExportCSS
        ? window.Animation.buildExportCSS(clone)
        : "";

    // Pure-CSS ":hover" transitions (see hover.js) — no JS, never active
    // on the editing canvas itself.
    const hoverCss = window.HoverFX?.buildExportCSS
        ? window.HoverFX.buildExportCSS(clone)
        : "";

    // Real @media (max-width: ...) blocks compiled from data-responsive
    // (see responsive.js) — never active on the editing canvas itself,
    // which uses its own injected preview <style> instead.
    const responsiveCss = window.Responsive?.buildExportCSS
        ? window.Responsive.buildExportCSS(clone)
        : "";

    // Custom code blocks (see customCode.js) — raw CSS/JS the author wrote
    // by hand. The HTML is already part of clone.innerHTML (it was set as
    // the block's real innerHTML the moment it was typed, same as any
    // other element's content); only the CSS/JS need pulling out of
    // data-code and placed for real, since the editor-only preview
    // <style> tag they use while editing never leaves the app's own
    // <head>. The JS never runs on the canvas — this export is the first
    // time it executes at all.
    const customCodeCss = window.CustomCode?.buildExportCSS
        ? window.CustomCode.buildExportCSS(clone)
        : "";

    const customCodeScript = window.CustomCode?.buildExportScripts
        ? window.CustomCode.buildExportScripts(clone)
        : "";

    // Only pull the Google Fonts actually used on the canvas (see fonts.js).
    const fontsLinkTag = window.Fonts?.buildLinkTag
        ? window.Fonts.buildLinkTag(clone)
        : "";

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    ${fontsLinkTag}
    <style>
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        .page { position: relative; max-width: ${maxWidth}; margin: 0 auto; padding: 40px; background: ${bg}; box-sizing: border-box; }
        .logic-hidden { opacity: 0 !important; pointer-events: none !important; }
        @keyframes logicPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.06); } }
        .logic-pulse { animation-name: logicPulse; animation-timing-function: ease-in-out; animation-duration: 0.6s; }
        ${animationCss}
        ${hoverCss}
        ${responsiveCss}
        ${customCodeCss}
    </style>
</head>
<body>
<div class="page">
${clone.innerHTML}
</div>
${logicScript}
${customCodeScript}
</body>
</html>`;

}

// 4. Wire up Preview / Export
function bindTopBar() {

    document.getElementById("export-btn")?.addEventListener("click", () => {

        Utils.download("export.html", getExportHtml());

    });

    document.getElementById("preview-btn")?.addEventListener("click", () => {

        const html = getExportHtml();

        // Inside pywebview, hand off to main.py's preview_html(), which
        // writes a temp file and opens it in the system's default browser
        // — window.open() on a blob: URL doesn't work in the embedded
        // WebView2 shell (same "Open with" dead end as downloads).
        if (window.pywebview?.api?.preview_html) {

            window.pywebview.api.preview_html(html);

            return;

        }

        // Fallback for running in a regular browser tab (e.g. testing).
        const blob = new Blob([html], { type: "text/html" });

        window.open(URL.createObjectURL(blob), "_blank");

    });

}