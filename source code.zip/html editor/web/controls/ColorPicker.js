// web/controls/ColorPicker.js

class ColorPicker {

    constructor(property) {

        this.property = property;

        this.root = document.createElement("div");

        this.root.className = "property-row";

        this.build();

    }

    build() {

        const label = document.createElement("label");

        label.textContent = this.property.label;

        this.input = document.createElement("input");

        this.input.type = "color";

        this.root.appendChild(label);

        this.root.appendChild(this.input);

        window.Binder.bindStyle(

            this.input,

            this.property.css,

            "color"

        );

    }

    getElement() {

        return this.root;

    }

}

window.ColorPicker = ColorPicker;