// web/controls/NumberInput.js

class NumberInput {

    constructor(property) {

        this.property = property;

        this.root = document.createElement("div");
        this.root.className = "property-row";

        this.build();

    }

    build() {

        const label = document.createElement("label");
        label.textContent = this.property.label;

        const wrapper = document.createElement("div");
        wrapper.className = "number-control";

        this.input = document.createElement("input");
        this.input.type = "number";

        if (this.property.min != null)
            this.input.min = this.property.min;

        if (this.property.max != null)
            this.input.max = this.property.max;

        if (this.property.step != null)
            this.input.step = this.property.step;

        wrapper.appendChild(this.input);

        if (this.property.unit) {

            const unit = document.createElement("span");

            unit.className = "unit";

            unit.textContent = this.property.unit;

            wrapper.appendChild(unit);

        }

        this.root.appendChild(label);
        this.root.appendChild(wrapper);

        window.Binder.bindStyle(

            this.input,

            this.property.css,

            "number",

            {

                unit: this.property.unit

            }

        );

    }

    getElement() {

        return this.root;

    }

}

window.NumberInput = NumberInput;