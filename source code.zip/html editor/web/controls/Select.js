// web/controls/Select.js

class Select {

    constructor(property) {

        this.property = property;

        this.root = document.createElement("div");

        this.root.className = "property-row";

        this.build();

    }

    build() {

        const label = document.createElement("label");

        label.textContent = this.property.label;

        this.select = document.createElement("select");

        // Safety fallback to an empty array
        const options = this.property.options || [];

        options.forEach(option => {

            const o = document.createElement("option");

            if (typeof option === "string") {

                o.value = option;

                o.textContent = option;

            }

            else {

                o.value = option.value;

                o.textContent = option.label;

            }

            this.select.appendChild(o);

        });

        this.root.appendChild(label);

        this.root.appendChild(this.select);

        window.Binder.bindStyle(

            this.select,

            this.property.css,

            "text"

        );

    }

    getElement() {

        return this.root;

    }

}

window.Select = Select;