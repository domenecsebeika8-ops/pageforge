// web/controls/TextInput.js

class TextInput {

    constructor(property) {

        this.property = property;

        this.root = document.createElement("div");

        this.root.className = "property-row";

        this.build();

    }

    build() {

        const label = document.createElement("label");

        label.textContent = this.property.label;

        this.input = document.createElement("input");

        this.input.type = "text";

        this.root.appendChild(label);

        this.root.appendChild(this.input);

        if (this.property.css) {

            window.Binder.bindStyle(

                this.input,

                this.property.css,

                "text"

            );

        }

        else if (this.property.html) {

            window.Binder.bindAttribute(

                this.input,

                this.property.html

            );

        }

        else {

            window.Binder.bindText(

                this.input

            );

        }

    }

    getElement() {

        return this.root;

    }

}

window.TextInput = TextInput;