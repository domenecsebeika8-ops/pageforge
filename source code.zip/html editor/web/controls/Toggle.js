// web/controls/Toggle.js

class Toggle {

    constructor(property) {

        this.property = property;

        this.root = document.createElement("div");

        this.root.className = "property-row";

        this.build();

    }

    build() {

        const label = document.createElement("label");

        label.textContent = this.property.label;

        this.input = document.createElement("input");

        this.input.type = "checkbox";

        this.root.appendChild(label);

        this.root.appendChild(this.input);

        window.Binder.bindStyle(

            this.input,

            this.property.css,

            "checkbox",

            {

                trueValue: this.property.trueValue,

                falseValue: this.property.falseValue

            }

        );

    }

    getElement() {

        return this.root;

    }

}

window.Toggle = Toggle;