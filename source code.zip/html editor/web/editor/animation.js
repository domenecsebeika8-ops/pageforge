// web/editor/animation.js
//
// Sistema de animación por fotogramas clave, estilo Premiere Pro: cada
// elemento puede llevar una animación con varias "pistas" (una por
// propiedad — posición X/Y, escala, rotación, opacidad, fondo, color de
// texto), y cada pista tiene sus propios fotogramas clave independientes
// en el tiempo. Los datos viven en el atributo data-animation (JSON),
// igual que data-logic para las reglas de Lógica.
//
// La edición ocurre en un panel inferior con una regla de tiempo, un
// playhead arrastrable que previsualiza en vivo sobre el lienzo, y
// diamantes de fotograma clave por pista. Al exportar/previsualizar, los
// datos se convierten en una animación CSS real (@keyframes), reproducida
// automáticamente al cargar por defecto, y también disparable como una
// nueva acción de Lógica ("Reproducir animación").

const ANIMATION_TRACK_DEFS = {

    x: { label: "Posición X", type: "number", unit: "px", step: 1, default: () => 0 },
    y: { label: "Posición Y", type: "number", unit: "px", step: 1, default: () => 0 },
    scaleX: { label: "Escala X", type: "number", unit: "x", step: 0.01, min: 0, default: () => 1 },
    scaleY: { label: "Escala Y", type: "number", unit: "x", step: 0.01, min: 0, default: () => 1 },
    rotation: { label: "Rotación", type: "number", unit: "°", step: 1, default: () => 0 },
    opacity: { label: "Opacidad", type: "number", unit: "", step: 0.01, min: 0, max: 1, default: (el) => {
        const v = parseFloat(el?.style?.opacity);
        return Number.isNaN(v) ? 1 : v;
    } },
    background: { label: "Fondo", type: "color", default: (el) => Utils.rgbToHex(
        el ? (el.style.backgroundColor || window.getComputedStyle(el).backgroundColor) : "#B4A996"
    ) },
    color: { label: "Color de texto", type: "color", default: (el) => Utils.rgbToHex(
        el ? (el.style.color || window.getComputedStyle(el).color) : "#000000"
    ) },
    // Trail/glow intensity (a blur radius in px) — the trail's colour is
    // NOT keyframed per-point (a streak doesn't usually change hue mid
    // animation), it's one fixed colour for the whole animation, stored
    // separately as data.glowColor and edited in the timeline header.
    glow: { label: "Estela de resplandor", type: "number", unit: "px", step: 1, min: 0, default: () => 0 }

};

const ANIMATION_TRACK_ORDER = ["x", "y", "scaleX", "scaleY", "rotation", "opacity", "background", "color", "glow"];

const ANIMATION_TRANSFORM_TRACKS = ["x", "y", "scaleX", "scaleY", "rotation"];

// One-click starting points, listed in the inspector's "Animación" empty
// state — each just pre-populates the normal track/keyframe data, so the
// timeline opens ready to fine-tune rather than starting from a blank
// slate. See the matching applyXPreset() methods on AnimationManager.
const ANIMATION_PRESET_MENU = [
    { method: "applyStretchMovePreset", icon: "⚡", label: "Estirar y mover a otro lugar" },
    { method: "applyStreakVanishPreset", icon: "☄", label: "Estela y deslizar hacia dentro" },
    { method: "applyBouncePreset", icon: "⬇", label: "Rebote" },
    { method: "applyZoomInPreset", icon: "🔍", label: "Aparecer con zoom" },
    { method: "applyShakePreset", icon: "↔", label: "Sacudida" },
    { method: "applyAttentionPulsePreset", icon: "●", label: "Pulso de atención (bucle)" },
    { method: "applySlideUpPreset", icon: "↑", label: "Deslizar desde abajo" }
];

const ANIMATION_DEFAULT_DURATION = 2000;

class AnimationManager {

    constructor() {

        this.panel = null;

        this.currentEl = null;

        this.originalStyle = null;

        this.currentTime = 0;

        this.selectedKeyframe = null; // { track, index }

        this.playing = false;

        this.playRaf = null;

        this.draggingKeyframe = null; // { track, index }

        this.draggingPlayhead = false;

        this.handleGlobalMouseMove = this.onGlobalMouseMove.bind(this);
        this.handleGlobalMouseUp = this.onGlobalMouseUp.bind(this);
        this.handleAddTrackMenuClose = this.closeAddTrackMenu.bind(this);

    }

    initialize() {

        this.panel = document.getElementById("animation-panel");

    }

    /* =========================================================
       Data model
       ========================================================= */

    getData(el) {

        if (!el)
            return null;

        try {

            const raw = el.getAttribute("data-animation");

            return raw ? JSON.parse(raw) : null;

        } catch (e) {

            return null;

        }

    }

    hasAnimation(el) {

        const data = this.getData(el);

        return !!(data && data.tracks && Object.values(data.tracks).some(t => t && t.length));

    }

    ensureData(el) {

        let data = this.getData(el);

        if (!data) {

            data = {
                duration: ANIMATION_DEFAULT_DURATION,
                loop: false,
                autoplay: true,
                tracks: {}
            };

            this.saveData(el, data);

        }

        return data;

    }

    saveData(el, data, { snapshot = true } = {}) {

        if (snapshot)
            window.History?.snapshot();

        el.setAttribute("data-animation", JSON.stringify(data));

    }

    remove(el) {

        window.History?.snapshot();

        el.removeAttribute("data-animation");

        if (this.currentEl === el)
            this.close();

    }

    updateSettings(el, patch) {

        const data = this.ensureData(el);

        Object.assign(data, patch);

        this.saveData(el, data);

        return data;

    }

    /* =========================================================
       Keyframe CRUD — every track is its own sorted array of
       { time, value }, entirely independent from other tracks.
       ========================================================= */

    addKeyframe(el, track, time, value, opts = {}) {

        const data = this.ensureData(el);

        if (!data.tracks[track])
            data.tracks[track] = [];

        const list = data.tracks[track];

        const existing = list.findIndex(k => k.time === time);

        if (existing >= 0)
            list[existing].value = value;

        else
            list.push({ time, value });

        list.sort((a, b) => a.time - b.time);

        this.saveData(el, data, opts);

        return list.findIndex(k => k.time === time);

    }

    updateKeyframe(el, track, index, patch, opts = {}) {

        const data = this.getData(el);

        const list = data?.tracks?.[track];

        if (!list || !list[index])
            return index;

        Object.assign(list[index], patch);

        list.sort((a, b) => a.time - b.time);

        // The index may have shifted if the time changed and re-sorted.
        const newIndex = list.indexOf(list.find(k => k === list[index]) || list[index]);

        this.saveData(el, data, opts);

        return newIndex;

    }

    removeKeyframe(el, track, index) {

        const data = this.getData(el);

        const list = data?.tracks?.[track];

        if (!list)
            return;

        list.splice(index, 1);

        if (!list.length)
            delete data.tracks[track];

        this.saveData(el, data);

    }

    removeTrack(el, track) {

        const data = this.getData(el);

        if (!data?.tracks)
            return;

        delete data.tracks[track];

        this.saveData(el, data);

    }

    /* =========================================================
       Interpolation
       ========================================================= */

    lerp(a, b, t) {

        return a + (b - a) * t;

    }

    lerpColor(hexA, hexB, t) {

        const a = this.parseHex(hexA);

        const b = this.parseHex(hexB);

        const r = Math.round(this.lerp(a.r, b.r, t));
        const g = Math.round(this.lerp(a.g, b.g, t));
        const bl = Math.round(this.lerp(a.b, b.b, t));

        return "#" + [r, g, bl].map(v => Utils.clamp(v, 0, 255).toString(16).padStart(2, "0")).join("");

    }

    parseHex(hex) {

        const clean = (hex || "#000000").replace("#", "");

        const full = clean.length === 3
            ? clean.split("").map(c => c + c).join("")
            : clean.padEnd(6, "0");

        const bigint = parseInt(full, 16) || 0;

        return { r: (bigint >> 16) & 255, g: (bigint >> 8) & 255, b: bigint & 255 };

    }

    // Value of a single track at a given time (ms), interpolated between
    // its neighbouring keyframes, clamped at the ends, falling back to the
    // property's natural/current value when the track has none at all.
    valueAt(el, track, time) {

        const def = ANIMATION_TRACK_DEFS[track];

        const data = this.getData(el);

        const list = data?.tracks?.[track];

        if (!list || !list.length)
            return def.default(el);

        if (list.length === 1 || time <= list[0].time)
            return list[0].value;

        if (time >= list[list.length - 1].time)
            return list[list.length - 1].value;

        let i = 0;

        while (i < list.length - 1 && list[i + 1].time < time)
            i++;

        const a = list[i];

        const b = list[i + 1];

        const span = b.time - a.time;

        const t = span > 0 ? (time - a.time) / span : 0;

        return def.type === "color"
            ? this.lerpColor(a.value, b.value, t)
            : this.lerp(Number(a.value), Number(b.value), t);

    }

    // Full visual state of the element at `time`, only including the
    // groups that actually have at least one keyframe somewhere.
    computeState(el, time) {

        const data = this.getData(el);

        if (!data)
            return {};

        const tracks = data.tracks || {};

        const state = {};

        const hasTransform = ANIMATION_TRANSFORM_TRACKS.some(k => tracks[k]?.length);

        if (hasTransform) {

            const x = this.valueAt(el, "x", time);
            const y = this.valueAt(el, "y", time);
            const scaleX = this.valueAt(el, "scaleX", time);
            const scaleY = this.valueAt(el, "scaleY", time);
            const rotation = this.valueAt(el, "rotation", time);

            state.transform = `translate(${x}px, ${y}px) scale(${scaleX}, ${scaleY}) rotate(${rotation}deg)`;

        }

        if (tracks.opacity?.length)
            state.opacity = String(this.valueAt(el, "opacity", time));

        if (tracks.background?.length)
            state.backgroundColor = this.valueAt(el, "background", time);

        if (tracks.color?.length)
            state.color = this.valueAt(el, "color", time);

        if (tracks.glow?.length) {

            const blur = this.valueAt(el, "glow", time);

            state.boxShadow = blur > 0 ? `0 0 ${blur}px ${data.glowColor || "#B4A996"}` : "none";

        }

        return state;

    }

    applyPreview(el, time) {

        const state = this.computeState(el, time);

        if (state.transform !== undefined) el.style.transform = state.transform;
        if (state.opacity !== undefined) el.style.opacity = state.opacity;
        if (state.backgroundColor !== undefined) el.style.backgroundColor = state.backgroundColor;
        if (state.color !== undefined) el.style.color = state.color;
        if (state.boxShadow !== undefined) el.style.boxShadow = state.boxShadow;

    }

    /* =========================================================
       Quick preset — "Estirar y mover a otro lugar": a fast elastic
       stretch (anticipation, along the direction of travel) that snaps
       back to the element's normal shape right as it lands somewhere
       else. Just a starting set of keyframes on the normal track system
       — the user can drag/retime/delete them like any other keyframe
       once the timeline opens.
       ========================================================= */

    applyStretchMovePreset(el) {

        const rect = el.getBoundingClientRect?.();

        const offsetX = Math.max(120, Math.round((rect?.width || 100) * 1.2));

        const data = {

            duration: 500,

            loop: false,

            autoplay: true,

            tracks: {

                x: [{ time: 0, value: 0 }, { time: 120, value: 0 }, { time: 400, value: offsetX }],

                y: [{ time: 0, value: 0 }, { time: 120, value: 0 }, { time: 400, value: 0 }],

                // Stretched thin-and-long along the movement axis at the
                // anticipation frame (120ms), then back to its normal
                // proportions by the time it lands in the new spot.
                scaleX: [{ time: 0, value: 1 }, { time: 120, value: 1.6 }, { time: 400, value: 1 }],

                scaleY: [{ time: 0, value: 1 }, { time: 120, value: 0.6 }, { time: 400, value: 1 }]

            }

        };

        this.saveData(el, data);

        return data;

    }

    // "Estela y deslizar hacia dentro": stretches into a smear as it
    // moves, trailing a glow in the element's own predominant colour
    // (falls back to the app's accent if it has none), then collapses
    // back down to nothing right as it lands — a slide-inward vanish
    // instead of a plain fade.
    applyStreakVanishPreset(el) {

        const rect = el.getBoundingClientRect?.();

        const offsetX = Math.max(160, Math.round((rect?.width || 100) * 1.4));

        const bg = window.getComputedStyle ? window.getComputedStyle(el).backgroundColor : "";

        const hasRealBg = bg && bg !== "rgba(0, 0, 0, 0)" && bg !== "transparent";

        const glowColor = hasRealBg ? Utils.rgbToHex(bg) : "#B4A996";

        const data = {

            duration: 650,

            loop: false,

            autoplay: true,

            glowColor,

            tracks: {

                x: [{ time: 0, value: 0 }, { time: 450, value: offsetX }],

                // Smears into a long, thin streak while in motion (200ms),
                // returns to its normal shape right as it arrives (450ms),
                // then squeezes down toward nothing as it vanishes (650ms).
                scaleX: [
                    { time: 0, value: 1 },
                    { time: 200, value: 2.2 },
                    { time: 450, value: 1 },
                    { time: 650, value: 0.05 }
                ],

                scaleY: [
                    { time: 0, value: 1 },
                    { time: 200, value: 0.5 },
                    { time: 450, value: 1 },
                    { time: 650, value: 0.6 }
                ],

                // The trail: flares up while smearing, fades out once it's
                // back to its normal shape and settled.
                glow: [
                    { time: 0, value: 0 },
                    { time: 200, value: 28 },
                    { time: 450, value: 8 },
                    { time: 650, value: 0 }
                ],

                opacity: [
                    { time: 0, value: 1 },
                    { time: 450, value: 1 },
                    { time: 650, value: 0 }
                ]

            }

        };

        this.saveData(el, data);

        return data;

    }

    // "Rebote": drops in from above and settles with a couple of
    // decreasing bounces, like it landed under gravity.
    applyBouncePreset(el) {

        const data = {

            duration: 600,

            loop: false,

            autoplay: true,

            tracks: {

                y: [
                    { time: 0, value: -80 },
                    { time: 280, value: 0 },
                    { time: 380, value: -16 },
                    { time: 480, value: 0 },
                    { time: 560, value: -4 },
                    { time: 600, value: 0 }
                ],

                opacity: [{ time: 0, value: 0 }, { time: 120, value: 1 }]

            }

        };

        this.saveData(el, data);

        return data;

    }

    // "Aparecer con zoom": grows in from small with a slight overshoot,
    // fading in at the same time.
    applyZoomInPreset(el) {

        const data = {

            duration: 400,

            loop: false,

            autoplay: true,

            tracks: {

                scaleX: [{ time: 0, value: 0.4 }, { time: 300, value: 1.05 }, { time: 400, value: 1 }],

                scaleY: [{ time: 0, value: 0.4 }, { time: 300, value: 1.05 }, { time: 400, value: 1 }],

                opacity: [{ time: 0, value: 0 }, { time: 250, value: 1 }]

            }

        };

        this.saveData(el, data);

        return data;

    }

    // "Sacudida": a quick, decaying side-to-side shake — the classic
    // "wrong input" / "grab attention" gesture.
    applyShakePreset(el) {

        const data = {

            duration: 400,

            loop: false,

            autoplay: true,

            tracks: {

                x: [
                    { time: 0, value: 0 },
                    { time: 50, value: -10 },
                    { time: 100, value: 10 },
                    { time: 150, value: -10 },
                    { time: 200, value: 10 },
                    { time: 250, value: -6 },
                    { time: 300, value: 6 },
                    { time: 350, value: -2 },
                    { time: 400, value: 0 }
                ]

            }

        };

        this.saveData(el, data);

        return data;

    }

    // "Pulso de atención": a slow, gentle, looping breathing scale — for
    // drawing the eye to something without being as aggressive as a shake.
    applyAttentionPulsePreset(el) {

        const data = {

            duration: 900,

            loop: true,

            autoplay: true,

            tracks: {

                scaleX: [{ time: 0, value: 1 }, { time: 450, value: 1.06 }, { time: 900, value: 1 }],

                scaleY: [{ time: 0, value: 1 }, { time: 450, value: 1.06 }, { time: 900, value: 1 }]

            }

        };

        this.saveData(el, data);

        return data;

    }

    // "Deslizar desde abajo": rises in from just below its resting spot
    // while fading in — the standard scroll-reveal entrance.
    applySlideUpPreset(el) {

        const data = {

            duration: 500,

            loop: false,

            autoplay: true,

            tracks: {

                y: [{ time: 0, value: 60 }, { time: 500, value: 0 }],

                opacity: [{ time: 0, value: 0 }, { time: 350, value: 1 }]

            }

        };

        this.saveData(el, data);

        return data;

    }

    /* =========================================================
       Timeline panel
       ========================================================= */

    open(el) {

        if (!this.panel)
            return;

        if (this.currentEl && this.currentEl !== el)
            this.close();

        this.currentEl = el;

        this.currentTime = 0;

        this.selectedKeyframe = null;

        this.originalStyle = {
            transform: el.style.transform,
            opacity: el.style.opacity,
            backgroundColor: el.style.backgroundColor,
            color: el.style.color,
            boxShadow: el.style.boxShadow
        };

        this.ensureData(el);

        this.panel.classList.add("open");

        this.render();

        this.applyPreview(el, 0);

    }

    // Restores the currently-open element to its pre-preview inline style
    // without closing the panel — used right before export/preview so a
    // mid-scrub transform never leaks into the generated HTML.
    resetPreviewStyle() {

        if (this.currentEl && this.originalStyle) {

            Object.entries(this.originalStyle).forEach(([prop, value]) => {

                this.currentEl.style[prop] = value;

            });

        }

    }

    close() {

        this.stopPlayback();

        if (this.currentEl && this.originalStyle) {

            Object.entries(this.originalStyle).forEach(([prop, value]) => {

                this.currentEl.style[prop] = value;

            });

        }

        this.currentEl = null;

        this.originalStyle = null;

        this.selectedKeyframe = null;

        if (this.panel) {

            this.panel.classList.remove("open");

            this.panel.innerHTML = "";

        }

    }

    render() {

        if (!this.panel || !this.currentEl)
            return;

        Utils.empty(this.panel);

        const data = this.getData(this.currentEl);

        this.panel.appendChild(this.buildHeader(data));

        this.panel.appendChild(this.buildTimeline(data));

        if (this.selectedKeyframe)
            this.panel.appendChild(this.buildKeyframeEditor(data));

    }

    buildHeader(data) {

        const header = document.createElement("div");

        header.className = "animation-panel-header";

        const title = document.createElement("div");

        title.className = "animation-panel-title";

        const text = (this.currentEl.textContent || "").trim().slice(0, 20) || t("(sin texto)");

        title.textContent = `${t("Animación")} — <${this.currentEl.tagName.toLowerCase()}> ${text}`;

        header.appendChild(title);

        const controls = document.createElement("div");

        controls.className = "animation-panel-controls";

        // Duración
        const durWrap = document.createElement("label");

        durWrap.className = "animation-inline-field";

        durWrap.textContent = t("Duración");

        const durInput = document.createElement("input");

        durInput.type = "number";

        durInput.min = "100";

        durInput.step = "100";

        durInput.value = data.duration;

        durInput.addEventListener("input", () => {

            if (durInput.value === "")
                return;

            const next = Math.max(100, Number(durInput.value));

            this.updateSettings(this.currentEl, { duration: next });

            this.currentTime = Math.min(this.currentTime, next);

            this.render();

        });

        durWrap.appendChild(durInput);

        const ms = document.createElement("span");

        ms.className = "unit";

        ms.textContent = "ms";

        durWrap.appendChild(ms);

        controls.appendChild(durWrap);

        // Bucle
        controls.appendChild(this.buildCheckboxField(t("Bucle"), data.loop, checked => {

            this.updateSettings(this.currentEl, { loop: checked });

        }));

        // Autorreproducción
        controls.appendChild(this.buildCheckboxField(t("Autorreproducción"), data.autoplay, checked => {

            this.updateSettings(this.currentEl, { autoplay: checked });

        }));

        // Color de la estela — only meaningful once the "glow" track is
        // active (its intensity is keyframed, but the colour itself is
        // one fixed value for the whole animation).
        if (data.tracks?.glow?.length) {

            const glowField = document.createElement("label");

            glowField.className = "animation-inline-field";

            const glowInput = document.createElement("input");

            glowInput.type = "color";

            glowInput.value = Utils.rgbToHex(data.glowColor || "#B4A996");

            glowInput.addEventListener("input", () => {

                this.updateSettings(this.currentEl, { glowColor: glowInput.value });

                this.applyPreview(this.currentEl, this.currentTime);

            });

            glowField.appendChild(glowInput);

            const glowLabel = document.createElement("span");

            glowLabel.textContent = t("Color de la estela");

            glowField.appendChild(glowLabel);

            controls.appendChild(glowField);

        }

        // Reproducir
        const playBtn = document.createElement("button");

        playBtn.type = "button";

        playBtn.className = "section-action-btn";

        // A stable, language-independent marker for startPlayback/
        // stopPlayback to flip the label without needing to substring-match
        // (translated) button text.
        playBtn.dataset.playState = this.playing ? "pause" : "play";

        playBtn.textContent = this.playing ? t("⏸ Pausar") : t("▶ Reproducir");

        playBtn.addEventListener("click", () => {

            if (this.playing)
                this.stopPlayback();

            else
                this.startPlayback(data);

        });

        controls.appendChild(playBtn);

        // + Pista
        const addTrackBtn = document.createElement("button");

        addTrackBtn.type = "button";

        addTrackBtn.className = "section-action-btn";

        addTrackBtn.textContent = t("+ Pista");

        addTrackBtn.addEventListener("click", (e) => {

            e.stopPropagation();

            this.toggleAddTrackMenu(addTrackBtn, data);

        });

        controls.appendChild(addTrackBtn);

        // Cerrar
        const closeBtn = document.createElement("button");

        closeBtn.type = "button";

        closeBtn.className = "icon-btn";

        closeBtn.textContent = "✕";

        closeBtn.addEventListener("click", () => {

            this.close();

            window.Inspector?.refresh();

        });

        controls.appendChild(closeBtn);

        header.appendChild(controls);

        return header;

    }

    buildCheckboxField(labelText, checked, onChange) {

        const label = document.createElement("label");

        label.className = "animation-inline-field";

        const input = document.createElement("input");

        input.type = "checkbox";

        input.checked = !!checked;

        input.addEventListener("change", () => onChange(input.checked));

        label.appendChild(input);

        const span = document.createElement("span");

        span.textContent = labelText;

        label.appendChild(span);

        return label;

    }

    toggleAddTrackMenu(anchor, data) {

        const existing = document.getElementById("animation-add-track-menu");

        if (existing) {

            this.closeAddTrackMenu();

            return;

        }

        const menu = document.createElement("div");

        menu.id = "animation-add-track-menu";

        menu.className = "add-menu";

        const active = new Set(Object.keys(data.tracks || {}).filter(k => data.tracks[k]?.length));

        const available = ANIMATION_TRACK_ORDER.filter(k => !active.has(k));

        if (!available.length) {

            const item = document.createElement("div");

            item.className = "add-menu-item";

            item.textContent = t("Todas las pistas añadidas");

            menu.appendChild(item);

        }

        available.forEach(track => {

            const btn = document.createElement("button");

            btn.type = "button";

            btn.className = "add-menu-item";

            btn.textContent = t(ANIMATION_TRACK_DEFS[track].label, ANIMATION_TRACK_DEFS[track].label);

            btn.addEventListener("click", (e) => {

                e.stopPropagation();

                const def = ANIMATION_TRACK_DEFS[track];

                const value = def.default(this.currentEl);

                const index = this.addKeyframe(this.currentEl, track, 0, value);

                this.selectedKeyframe = { track, index };

                this.closeAddTrackMenu();

                this.render();

            });

            menu.appendChild(btn);

        });

        document.body.appendChild(menu);

        const rect = anchor.getBoundingClientRect();

        const menuRect = menu.getBoundingClientRect();

        menu.style.left = Math.max(8, Math.min(
            rect.right - menuRect.width,
            window.innerWidth - menuRect.width - 8
        )) + "px";

        // The "+ Track" button lives inside the animation panel, which is
        // docked at the bottom of the window — there's often not enough
        // room below it for a menu with one row per track (up to 7). Flip
        // to opening upward when that's the case, same as canvas.js's "+"
        // menu already does for its own bottom-docked button; either way,
        // clamp the final position so the menu can never end up partially
        // off-screen even in a very short window.
        const spaceBelow = window.innerHeight - rect.bottom - 6;

        const openAbove = spaceBelow < menuRect.height && (rect.top - menuRect.height - 6) >= 0;

        menu.style.top = openAbove
            ? (rect.top - menuRect.height - 6) + "px"
            : Math.max(8, Math.min(rect.bottom + 6, window.innerHeight - menuRect.height - 8)) + "px";

        setTimeout(() => document.addEventListener("click", this.handleAddTrackMenuClose), 0);

    }

    closeAddTrackMenu() {

        document.getElementById("animation-add-track-menu")?.remove();

        document.removeEventListener("click", this.handleAddTrackMenuClose);

    }

    buildTimeline(data) {

        const wrap = document.createElement("div");

        wrap.className = "animation-timeline";

        const inner = document.createElement("div");

        inner.className = "animation-timeline-inner";

        // Ruler row: an empty spacer matching the track-label column width,
        // then the actual ruler — so its tick marks land in the exact same
        // x-coordinates as every track lane below it.
        const rulerRow = document.createElement("div");

        rulerRow.className = "animation-ruler-row";

        const spacer = document.createElement("div");

        spacer.className = "animation-track-label-spacer";

        rulerRow.appendChild(spacer);

        const ruler = document.createElement("div");

        ruler.className = "animation-ruler";

        const steps = 10;

        for (let i = 0; i <= steps; i++) {

            const mark = document.createElement("span");

            mark.className = "animation-ruler-mark";

            mark.style.left = (i / steps * 100) + "%";

            mark.textContent = ((data.duration * i / steps) / 1000).toFixed(2) + "s";

            ruler.appendChild(mark);

        }

        ruler.addEventListener("mousedown", (e) => {

            if (e.target.closest(".animation-keyframe"))
                return;

            this.startPlayheadDrag(e, ruler, data);

        });

        rulerRow.appendChild(ruler);

        inner.appendChild(rulerRow);

        const tracksWrap = document.createElement("div");

        tracksWrap.className = "animation-tracks";

        const activeTracks = ANIMATION_TRACK_ORDER.filter(k => data.tracks?.[k]?.length);

        if (!activeTracks.length) {

            const empty = document.createElement("div");

            empty.className = "modal-subtitle";

            empty.style.padding = "12px";

            empty.textContent = t('Añade una pista con "+ Pista" para empezar a crear fotogramas clave.');

            tracksWrap.appendChild(empty);

        }

        activeTracks.forEach(track => {

            tracksWrap.appendChild(this.buildTrackRow(track, data));

        });

        inner.appendChild(tracksWrap);

        // Playhead — lives inside an overlay aligned to the shared lane
        // column (see .animation-lanes-overlay), spanning the ruler and
        // every track row beneath it.
        const overlay = document.createElement("div");

        overlay.className = "animation-lanes-overlay";

        const playhead = document.createElement("div");

        playhead.className = "animation-playhead";

        playhead.style.left = (data.duration ? (this.currentTime / data.duration * 100) : 0) + "%";

        playhead.addEventListener("mousedown", (e) => {

            this.startPlayheadDrag(e, ruler, data);

        });

        overlay.appendChild(playhead);

        inner.appendChild(overlay);

        wrap.appendChild(inner);

        return wrap;

    }

    buildTrackRow(track, data) {

        const def = ANIMATION_TRACK_DEFS[track];

        const row = document.createElement("div");

        row.className = "animation-track";

        const label = document.createElement("div");

        label.className = "animation-track-label";

        const span = document.createElement("span");

        span.textContent = t(def.label, def.label);

        label.appendChild(span);

        const removeBtn = document.createElement("button");

        removeBtn.type = "button";

        removeBtn.className = "remove-attr";

        removeBtn.title = t("Quitar pista");

        removeBtn.textContent = "✕";

        removeBtn.addEventListener("click", () => {

            this.removeTrack(this.currentEl, track);

            if (this.selectedKeyframe?.track === track)
                this.selectedKeyframe = null;

            this.render();

        });

        label.appendChild(removeBtn);

        row.appendChild(label);

        const lane = document.createElement("div");

        lane.className = "animation-track-lane";

        (data.tracks[track] || []).forEach((kf, index) => {

            lane.appendChild(this.buildKeyframeDot(track, index, kf, data));

        });

        lane.addEventListener("click", (e) => {

            if (e.target.closest(".animation-keyframe"))
                return;

            const rect = lane.getBoundingClientRect();

            const ratio = Utils.clamp((e.clientX - rect.left) / rect.width, 0, 1);

            const time = Math.round(ratio * data.duration);

            const value = this.valueAt(this.currentEl, track, time);

            const index = this.addKeyframe(this.currentEl, track, time, value);

            this.selectedKeyframe = { track, index };

            this.currentTime = time;

            this.applyPreview(this.currentEl, time);

            this.render();

        });

        row.appendChild(lane);

        return row;

    }

    buildKeyframeDot(track, index, kf, data) {

        const dot = document.createElement("div");

        dot.className = "animation-keyframe";

        if (this.selectedKeyframe?.track === track && this.selectedKeyframe?.index === index)
            dot.classList.add("selected");

        dot.style.left = (data.duration ? (kf.time / data.duration * 100) : 0) + "%";

        dot.addEventListener("mousedown", (e) => {

            e.stopPropagation();

            this.startKeyframeDrag(e, track, index, dot);

        });

        dot.addEventListener("click", (e) => {

            e.stopPropagation();

            this.selectedKeyframe = { track, index };

            this.currentTime = kf.time;

            this.applyPreview(this.currentEl, kf.time);

            this.render();

        });

        return dot;

    }

    buildKeyframeEditor(data) {

        const { track, index } = this.selectedKeyframe;

        const list = data.tracks?.[track];

        const kf = list?.[index];

        const wrap = document.createElement("div");

        wrap.className = "animation-kf-editor";

        if (!kf) {

            this.selectedKeyframe = null;

            return wrap;

        }

        const def = ANIMATION_TRACK_DEFS[track];

        const title = document.createElement("span");

        title.className = "animation-kf-editor-title";

        title.textContent = t(def.label, def.label) + " — " + t("fotograma clave");

        wrap.appendChild(title);

        const timeField = document.createElement("label");

        timeField.className = "animation-inline-field";

        timeField.textContent = t("Tiempo");

        const timeInput = document.createElement("input");

        timeInput.type = "number";

        timeInput.min = "0";

        timeInput.max = String(data.duration);

        timeInput.value = kf.time;

        timeInput.addEventListener("input", () => {

            if (timeInput.value === "")
                return;

            const time = Utils.clamp(Number(timeInput.value), 0, data.duration);

            const newIndex = this.updateKeyframe(this.currentEl, track, index, { time });

            this.selectedKeyframe = { track, index: newIndex };

            this.render();

        });

        timeField.appendChild(timeInput);

        const msLabel = document.createElement("span");

        msLabel.className = "unit";

        msLabel.textContent = "ms";

        timeField.appendChild(msLabel);

        wrap.appendChild(timeField);

        const valueField = document.createElement("label");

        valueField.className = "animation-inline-field";

        valueField.textContent = t("Valor");

        const valueInput = document.createElement("input");

        if (def.type === "color") {

            valueInput.type = "color";

            valueInput.value = Utils.rgbToHex(kf.value);

        } else {

            valueInput.type = "number";

            if (def.min != null) valueInput.min = def.min;
            if (def.max != null) valueInput.max = def.max;
            valueInput.step = def.step || 1;

            valueInput.value = kf.value;

        }

        valueInput.addEventListener("input", () => {

            const value = def.type === "color" ? valueInput.value : Number(valueInput.value);

            this.updateKeyframe(this.currentEl, track, index, { value });

            this.applyPreview(this.currentEl, this.currentTime);

        });

        valueField.appendChild(valueInput);

        if (def.unit) {

            const u = document.createElement("span");

            u.className = "unit";

            u.textContent = def.unit;

            valueField.appendChild(u);

        }

        wrap.appendChild(valueField);

        const deleteBtn = document.createElement("button");

        deleteBtn.type = "button";

        deleteBtn.className = "add-link";

        deleteBtn.textContent = t("Eliminar fotograma clave");

        deleteBtn.addEventListener("click", () => {

            this.removeKeyframe(this.currentEl, track, index);

            this.selectedKeyframe = null;

            this.render();

        });

        wrap.appendChild(deleteBtn);

        return wrap;

    }

    /* =========================================================
       Dragging — one history snapshot per gesture, not per pixel.
       ========================================================= */

    startPlayheadDrag(event, ruler, data) {

        event.preventDefault();

        this.draggingPlayhead = { ruler, data };

        this.scrubFromEvent(event, ruler, data);

        document.addEventListener("mousemove", this.handleGlobalMouseMove);

        document.addEventListener("mouseup", this.handleGlobalMouseUp);

    }

    scrubFromEvent(event, ruler, data) {

        const rect = ruler.getBoundingClientRect();

        const ratio = Utils.clamp((event.clientX - rect.left) / rect.width, 0, 1);

        this.currentTime = Math.round(ratio * data.duration);

        this.applyPreview(this.currentEl, this.currentTime);

        const playhead = this.panel.querySelector(".animation-playhead");

        if (playhead)
            playhead.style.left = (ratio * 100) + "%";

    }

    startKeyframeDrag(event, track, index, dot) {

        event.preventDefault();

        window.History?.snapshot();

        const lane = dot.parentElement;

        this.draggingKeyframe = { track, index, lane, dot };

        this.selectedKeyframe = { track, index };

        document.addEventListener("mousemove", this.handleGlobalMouseMove);

        document.addEventListener("mouseup", this.handleGlobalMouseUp);

    }

    onGlobalMouseMove(event) {

        if (this.draggingPlayhead) {

            this.scrubFromEvent(event, this.draggingPlayhead.ruler, this.draggingPlayhead.data);

            return;

        }

        if (this.draggingKeyframe) {

            const { track, index, lane, dot } = this.draggingKeyframe;

            const data = this.getData(this.currentEl);

            const rect = lane.getBoundingClientRect();

            const ratio = Utils.clamp((event.clientX - rect.left) / rect.width, 0, 1);

            const time = Math.round(ratio * data.duration);

            dot.style.left = (ratio * 100) + "%";

            const list = data.tracks[track];

            if (list && list[index]) {

                list[index].time = time;

                this.saveData(this.currentEl, data, { snapshot: false });

                this.currentTime = time;

                this.applyPreview(this.currentEl, time);

            }

        }

    }

    onGlobalMouseUp() {

        if (this.draggingKeyframe) {

            // Commit the final order (re-sort by time) now that the drag
            // gesture is over, and re-resolve the keyframe's index.
            const { track } = this.draggingKeyframe;

            const data = this.getData(this.currentEl);

            const list = data.tracks[track];

            const draggedTime = list[this.draggingKeyframe.index]?.time;

            list.sort((a, b) => a.time - b.time);

            this.saveData(this.currentEl, data, { snapshot: false });

            const newIndex = list.findIndex(k => k.time === draggedTime);

            this.selectedKeyframe = { track, index: newIndex >= 0 ? newIndex : 0 };

            this.draggingKeyframe = null;

            this.render();

        }

        this.draggingPlayhead = false;

        document.removeEventListener("mousemove", this.handleGlobalMouseMove);
        document.removeEventListener("mouseup", this.handleGlobalMouseUp);

    }

    /* =========================================================
       Preview playback (▶ button) — sweeps the playhead once (or in a
       loop, matching the "Bucle" setting) purely for editor preview.
       ========================================================= */

    startPlayback(data) {

        this.playing = true;

        const startedAt = performance.now() - this.currentTime;

        const step = (now) => {

            if (!this.playing)
                return;

            let elapsed = now - startedAt;

            if (elapsed >= data.duration) {

                if (data.loop) {

                    elapsed = elapsed % data.duration;

                } else {

                    this.currentTime = data.duration;

                    this.applyPreview(this.currentEl, data.duration);

                    this.stopPlayback();

                    return;

                }

            }

            this.currentTime = elapsed;

            this.applyPreview(this.currentEl, elapsed);

            const playhead = this.panel.querySelector(".animation-playhead");

            if (playhead)
                playhead.style.left = (elapsed / data.duration * 100) + "%";

            this.playRaf = requestAnimationFrame(step);

        };

        const playBtn = [...this.panel.querySelectorAll(".animation-panel-controls .section-action-btn")]
            .find(b => b.dataset.playState === "play" || b.dataset.playState === "pause");

        if (playBtn) {
            playBtn.dataset.playState = "pause";
            playBtn.textContent = t("⏸ Pausar");
        }

        this.playRaf = requestAnimationFrame(step);

    }

    stopPlayback() {

        this.playing = false;

        if (this.playRaf)
            cancelAnimationFrame(this.playRaf);

        this.playRaf = null;

        const playBtn = this.panel?.querySelector(".animation-panel-controls .section-action-btn");

        if (playBtn && playBtn.dataset.playState === "pause") {
            playBtn.dataset.playState = "play";
            playBtn.textContent = t("▶ Reproducir");
        }

    }

    /* =========================================================
       Export — real CSS @keyframes, applied to the exported/previewed
       document. Transform-group properties (x/y/scaleX/scaleY/rotation) are
       merged into a single `transform` declaration per keyframe time
       (CSS can't animate that group as separate independent properties),
       while opacity/background/color stay fully independent per their
       own keyframe times — exactly mirroring the editor's per-track
       model.
       ========================================================= */

    buildExportCSS(root) {

        const animated = [...root.querySelectorAll("[data-animation]")];

        if (!animated.length)
            return "";

        let css = "";

        animated.forEach(el => {

            let data;

            try {

                data = JSON.parse(el.getAttribute("data-animation"));

            } catch (e) {

                return;

            }

            const tracks = data.tracks || {};

            const hasAny = Object.values(tracks).some(t => t?.length);

            if (!hasAny)
                return;

            const lid = window.Logic ? window.Logic.resolveLid(el) : (() => {

                if (!el.dataset.lid)
                    el.dataset.lid = "lid-" + Math.random().toString(36).slice(2, 9);

                return el.dataset.lid;

            })();

            const animName = "anim_" + lid.replace(/[^a-zA-Z0-9_]/g, "");

            const keyframeBlock = this.buildKeyframeBlock(el, data, animName);

            if (!keyframeBlock)
                return;

            css += keyframeBlock;

            const iterationCount = data.loop ? "infinite" : "1";

            const playState = data.autoplay ? "running" : "paused";

            css += `[data-lid="${lid}"] { animation: ${animName} ${data.duration}ms linear ${iterationCount} both; animation-play-state: ${playState}; }\n`;

        });

        return css;

    }

    buildKeyframeBlock(el, data, animName) {

        const tracks = data.tracks || {};

        const duration = data.duration || ANIMATION_DEFAULT_DURATION;

        const hasTransform = ANIMATION_TRANSFORM_TRACKS.some(k => tracks[k]?.length);

        // percentage -> { transform?, opacity?, backgroundColor?, color? }
        const percentages = {};

        const setAt = (time, key, value) => {

            const pct = duration ? Utils.clamp(time / duration * 100, 0, 100) : 0;

            const roundedPct = Math.round(pct * 100) / 100;

            if (!percentages[roundedPct])
                percentages[roundedPct] = {};

            percentages[roundedPct][key] = value;

        };

        if (hasTransform) {

            const times = new Set([0, duration]);

            ANIMATION_TRANSFORM_TRACKS.forEach(k => (tracks[k] || []).forEach(kf => times.add(kf.time)));

            [...times].sort((a, b) => a - b).forEach(time => {

                const x = this.trackValueAtStatic(tracks.x, "x", time, el);
                const y = this.trackValueAtStatic(tracks.y, "y", time, el);
                const scaleX = this.trackValueAtStatic(tracks.scaleX, "scaleX", time, el);
                const scaleY = this.trackValueAtStatic(tracks.scaleY, "scaleY", time, el);
                const rotation = this.trackValueAtStatic(tracks.rotation, "rotation", time, el);

                setAt(time, "transform", `translate(${x}px, ${y}px) scale(${scaleX}, ${scaleY}) rotate(${rotation}deg)`);

            });

        }

        ["opacity", "background", "color"].forEach(track => {

            const list = tracks[track];

            if (!list?.length)
                return;

            const times = new Set([0, duration]);

            list.forEach(kf => times.add(kf.time));

            const cssKey = track === "background" ? "background-color" : (track === "color" ? "color" : "opacity");

            [...times].sort((a, b) => a - b).forEach(time => {

                setAt(time, cssKey, this.trackValueAtStatic(list, track, time, el));

            });

        });

        // Trail/glow (box-shadow) — intensity is keyframed, colour is
        // fixed for the whole animation (data.glowColor).
        const glowList = tracks.glow;

        if (glowList?.length) {

            const times = new Set([0, duration]);

            glowList.forEach(kf => times.add(kf.time));

            const glowColor = data.glowColor || "#B4A996";

            [...times].sort((a, b) => a - b).forEach(time => {

                const blur = this.trackValueAtStatic(glowList, "glow", time, el);

                setAt(time, "box-shadow", blur > 0 ? `0 0 ${blur}px ${glowColor}` : "none");

            });

        }

        const pctKeys = Object.keys(percentages).sort((a, b) => Number(a) - Number(b));

        if (!pctKeys.length)
            return "";

        let body = "";

        pctKeys.forEach(pct => {

            const decls = Object.entries(percentages[pct])
                .map(([prop, value]) => `${prop}: ${value};`)
                .join(" ");

            body += `  ${pct}% { ${decls} }\n`;

        });

        return `@keyframes ${animName} {\n${body}}\n`;

    }

    // Same interpolation as valueAt(), but reading from a plain track
    // array (used during export, where we're working off parsed JSON
    // rather than the live data-animation attribute on `el`).
    trackValueAtStatic(list, track, time, el) {

        const def = ANIMATION_TRACK_DEFS[track];

        if (!list || !list.length)
            return def.default(el);

        if (list.length === 1 || time <= list[0].time)
            return list[0].value;

        if (time >= list[list.length - 1].time)
            return list[list.length - 1].value;

        let i = 0;

        while (i < list.length - 1 && list[i + 1].time < time)
            i++;

        const a = list[i];

        const b = list[i + 1];

        const span = b.time - a.time;

        const t = span > 0 ? (time - a.time) / span : 0;

        return def.type === "color"
            ? this.lerpColor(a.value, b.value, t)
            : this.lerp(Number(a.value), Number(b.value), t);

    }

}

window.Animation = new AnimationManager();
