// web/editor/binder.js

class Binder {

    constructor() {

        this.boundControls = [];

    }

    initialize() {

        Selection.addListener("selectionChanged", () => {

            this.refresh();

        });

        Selection.addListener("styleChanged", () => {

            this.refresh();

        });

        Selection.addListener("textChanged", () => {

            this.refresh();

        });

        Selection.addListener("attributeChanged", () => {

            this.refresh();

        });

    }

    register(control) {

        this.boundControls.push(control);

    }

    unregister(control) {

        this.boundControls = this.boundControls.filter(c => c !== control);

    }

    clear() {

        this.boundControls = [];

    }

    refresh() {

        const element = Selection.getSelected();

        if (!element)
            return;

        this.boundControls.forEach(control => {

            this.updateControl(control, element);

        });

    }

    updateControl(control, element) {

        switch (control.kind) {

            case "style":

                this.updateStyleControl(control, element);

                break;

            case "attribute":

                this.updateAttributeControl(control, element);

                break;

            case "text":

                this.updateTextControl(control, element);

                break;

        }

    }

    updateStyleControl(control, element) {

        const computed = window.getComputedStyle(element);

        let value = computed[control.property];

        if (control.type === "number") {

            value = parseFloat(value);

            if (Number.isNaN(value))
                value = "";

        }

        if (control.type === "color") {

            value = this.rgbToHex(value);

        }

        if (control.type === "checkbox") {

            control.element.checked = value === control.trueValue;

            return;

        }

        control.element.value = value;

    }

    updateAttributeControl(control, element) {

        control.element.value =

            element.getAttribute(control.attribute) ?? "";

    }

    updateTextControl(control, element) {

        control.element.value = element.textContent;

    }

    bindStyle(input, property, type = "text", options = {}) {

        const control = {

            kind: "style",

            type,

            property,

            element: input,

            trueValue: options.trueValue,

            falseValue: options.falseValue

        };

        this.register(control);

        input.addEventListener("input", () => {

            let value = input.value;

            if (options.unit)
                value += options.unit;

            Selection.updateStyle(property, value);

        });

        return control;

    }

    bindAttribute(input, attribute) {

        const control = {

            kind: "attribute",

            attribute,

            element: input

        };

        this.register(control);

        input.addEventListener("input", () => {

            Selection.updateAttribute(

                attribute,

                input.value

            );

        });

        return control;

    }

    bindText(input) {

        const control = {

            kind: "text",

            element: input

        };

        this.register(control);

        input.addEventListener("input", () => {

            Selection.updateText(

                input.value

            );

        });

        return control;

    }

    rgbToHex(rgb) {

        if (!rgb.startsWith("rgb"))
            return rgb;

        const values = rgb.match(/\d+/g);

        return "#" +

            values.slice(0, 3)

            .map(v => Number(v).toString(16).padStart(2, "0"))

            .join("");

    }

}

window.Binder = new Binder();