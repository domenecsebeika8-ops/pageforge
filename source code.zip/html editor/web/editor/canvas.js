// web/editor/canvas.js

// Element presets offered by the "+" menu. Seed content (text/html) is
// resolved through t() at insertion time (see insertPreset), so a freshly
// inserted element's placeholder text matches whatever UI language is
// active right now — it's a one-time stamp, not a live-bound label, same
// as any other text the user can immediately overwrite.
const CANVAS_PRESETS = {

    text: { tag: "p", textKey: "Nuevo texto" },

    button: { tag: "button", textKey: "Botón" },

    image: {
        tag: "img",
        attrsFn: () => ({
            src: Utils.imagePlaceholder(t("Imagen"), 300, 180),
            alt: t("Imagen")
        }),
        // display:block matters here: <img> defaults to display:inline,
        // and an inline image dropped next to block siblings (a heading,
        // a paragraph...) can end up sharing a "line" with them instead of
        // cleanly stacking — see the same fix on the Card/Label presets
        // and the Portfolio/Store templates for the full story.
        style: { display: "block", width: "240px", height: "144px" }
    },

    colorbox: {
        tag: "div",
        style: { width: "120px", height: "120px", background: "#B4A996" }
    },

    container: { tag: "div", textKey: "Contenedor" },

    form: {
        tag: "form",
        htmlFn: () =>
            `<label class="canvas-element">${t("Nombre")}</label>` +
            `<input class="canvas-element" type="text" placeholder="${t("Tu nombre")}">` +
            `<label class="canvas-element">${t("Mensaje")}</label>` +
            `<textarea class="canvas-element" placeholder="${t("Escribe tu mensaje")}" rows="3"></textarea>` +
            `<button class="canvas-element" type="submit">${t("Enviar")}</button>`,
        style: { display: "flex", flexDirection: "column", gap: "8px", maxWidth: "320px" }
    },

    card: {
        tag: "div",
        htmlFn: () =>
            `<img class="canvas-element" src="${Utils.imagePlaceholder(t("Imagen"), 280, 120)}" alt="${t("Imagen")}" ` +
            `style="display:block;width:100%;height:120px;object-fit:cover;border-radius:6px;margin-bottom:10px;">` +
            `<strong class="canvas-element">${t("Título de la tarjeta")}</strong>` +
            `<p class="canvas-element">${t("Una breve descripción de este elemento.")}</p>` +
            `<button class="canvas-element">${t("Ver más")}</button>`,
        style: { padding: "16px", background: "#FFFFFF", borderRadius: "10px", boxShadow: "0 4px 16px rgba(0,0,0,0.08)", maxWidth: "280px" }
    },

    // Image + text combo. The default arrangement is a flex row (image
    // left, text right) — Renderer's Content Layout section (Direction +
    // the "Reverse order" toggle) is what lets the user flip this to any
    // of the 4 arrangements the user actually cares about: text to the
    // right (Row), text to the left (Row, reversed), text below (Column),
    // text above (Column, reversed). Not a special-cased control, just the
    // same generic flex controls every container gets.
    label: {
        tag: "div",
        htmlFn: () =>
            `<img class="canvas-element" src="${Utils.imagePlaceholder(t("Imagen"), 64, 64)}" alt="${t("Imagen")}" ` +
            `style="display:block;width:56px;height:56px;object-fit:cover;border-radius:6px;flex-shrink:0;">` +
            `<span class="canvas-element">${t("Etiqueta")}</span>`,
        style: { display: "flex", flexDirection: "row", alignItems: "center", gap: "10px" }
    },

    divider: {
        tag: "hr",
        style: { border: "none", borderTop: "1px solid #E5E5E5", margin: "20px 0", width: "100%" }
    },

    // Escape hatch: raw HTML/CSS/JS, edited via the "Code" inspector
    // section (see customCode.js / Renderer.buildCustomCodeSection). The
    // seed content here is exactly what CustomCode.applyPreviewHtml()
    // would render for empty data-code, so the block looks the same
    // whether you're looking at it fresh from the "+" menu or after
    // clearing the HTML field back out.
    code: {
        tag: "div",
        htmlFn: () => `<span style="opacity:.5;font-style:italic;">${t("Bloque de código vacío — añade HTML en el inspector.")}</span>`,
        style: { padding: "16px", border: "1px dashed #CCC", borderRadius: "6px", minHeight: "48px" }
    }

};

const CANVAS_PRESET_MENU = [
    { key: "text", labelKey: "preset_text", icon: "T" },
    { key: "button", labelKey: "preset_button", icon: "▭" },
    { key: "image", labelKey: "preset_image", icon: "▨" },
    { key: "colorbox", labelKey: "preset_colorbox", icon: "■" },
    { key: "container", labelKey: "preset_container", icon: "◻" },
    { key: "form", labelKey: "preset_form", icon: "▤" },
    { key: "card", labelKey: "preset_card", icon: "▥" },
    { key: "label", labelKey: "preset_label", icon: "🏷" },
    { key: "code", labelKey: "preset_code", icon: "</>" },
    { key: "divider", labelKey: "preset_divider", icon: "―" }
];

class CanvasManager {

    constructor() {

        this.canvas = null;

        this.dragging = null;

        this.placeholder = null;

        this.snapLines = [];

        // Bind the methods once to preserve the reference in memory
        this.handleDragStart = this.dragStart.bind(this);
        this.handleDragEnd = this.dragEnd.bind(this);
        this.closeAddMenu = this.closeAddMenu.bind(this);
        this.handleAddMenuEscape = this.handleAddMenuEscape.bind(this);
        this.handleFreeDragStart = this.freeDragStart.bind(this);

    }

    initialize() {

        this.canvas = document.getElementById("canvas");

        if (!this.canvas)
            return;

        this.enableDragging();

        this.enableDropping();

        this.observe();

        this.bindToolbar();

    }

    /* ========================================================= */

    bindToolbar() {

        document.getElementById("add-btn")?.addEventListener(
            "click",
            (e) => {

                e.stopPropagation();

                if (document.getElementById("add-menu"))
                    this.closeAddMenu();

                else
                    this.showAddMenu();

            }
        );

        document.getElementById("duplicate-btn")?.addEventListener(
            "click",
            () => this.duplicate()
        );

        document.getElementById("wrap-btn")?.addEventListener(
            "click",
            () => this.wrap()
        );

        document.getElementById("hide-btn")?.addEventListener(
            "click",
            () => this.toggleVisibility()
        );

        document.getElementById("delete-btn")?.addEventListener(
            "click",
            () => this.delete()
        );

    }

    /* ========================================================= */

    observe() {

        const observer = new MutationObserver(() => {

            this.enableDragging();

        });

        observer.observe(this.canvas, {

            childList: true,

            subtree: true,

            // Also watch style changes: switching an element's Position
            // to Absolute/Inline in the inspector needs to re-decide
            // whether it drags freely (move) or reorders (HTML5 drag),
            // and that's a style mutation, not a childList one.
            attributes: true,

            attributeFilter: ["style"]

        });

    }

    /* ========================================================= */

    enableDragging() {

        this.canvas.querySelectorAll(".canvas-element")

            .forEach(element => {

                // Always clear both interaction modes first, then attach
                // only the one that applies — an absolutely- or fixed-
                // positioned element is moved freely with the mouse (top/
                // left), a normal flow element is reordered via HTML5
                // drag & drop. Sticky elements stay in normal flow (their
                // top/left only kick in once the scroll threshold hits),
                // so they still reorder like any other flow element.
                element.removeEventListener("dragstart", this.handleDragStart);
                element.removeEventListener("dragend", this.handleDragEnd);
                element.removeEventListener("mousedown", this.handleFreeDragStart);

                const isFreeFloating = element.style.position === "absolute" || element.style.position === "fixed";

                element.draggable = !isFreeFloating;

                // Editor-only affordance class (not an inline style) so it
                // never leaks into the exported HTML.
                element.classList.toggle("canvas-movable", isFreeFloating);

                if (isFreeFloating) {

                    element.addEventListener("mousedown", this.handleFreeDragStart);

                } else {

                    element.addEventListener("dragstart", this.handleDragStart);

                    element.addEventListener("dragend", this.handleDragEnd);

                }

            });

    }

    /* ========================================================= */

    // Free-form dragging for Position: Absolute elements — click and drag
    // the element itself anywhere on the canvas, updating top/left live.
    freeDragStart(event) {

        // Only the left mouse button starts a move.
        if (event.button !== 0)
            return;

        const element = event.currentTarget;

        event.preventDefault();

        Selection.select(element);

        const startX = event.clientX;

        const startY = event.clientY;

        const startLeft = parseFloat(element.style.left) || 0;

        const startTop = parseFloat(element.style.top) || 0;

        let moved = false;

        const onMouseMove = (moveEvent) => {

            const dx = moveEvent.clientX - startX;

            const dy = moveEvent.clientY - startY;

            if (!moved && (Math.abs(dx) > 2 || Math.abs(dy) > 2)) {

                moved = true;

                // One snapshot for the whole drag, taken right before the
                // first real movement — not per pixel.
                window.History?.snapshot();

                element.classList.add("free-dragging");

            }

            if (!moved)
                return;

            element.style.left = (startLeft + dx) + "px";

            element.style.top = (startTop + dy) + "px";

        };

        const onMouseUp = () => {

            document.removeEventListener("mousemove", onMouseMove);

            document.removeEventListener("mouseup", onMouseUp);

            element.classList.remove("free-dragging");

            // Refresh the inspector so the Position section's Top/Left
            // fields reflect where the element actually landed.
            if (moved)
                window.Inspector?.refresh();

        };

        document.addEventListener("mousemove", onMouseMove);

        document.addEventListener("mouseup", onMouseUp);

    }

    /* ========================================================= */

    dragStart(event) {

        this.dragging = event.target;

        event.dataTransfer.effectAllowed = "move";

        event.target.classList.add("dragging");

    }

    /* ========================================================= */

    dragEnd(event) {

        event.target.classList.remove("dragging");

        this.removePlaceholder();

        this.dragging = null;

    }

    /* ========================================================= */

    enableDropping() {

        this.canvas.addEventListener("dragover", e => {

            e.preventDefault();

            const after = this.getDragAfterElement(

                e.clientY

            );

            if (!after) {

                this.canvas.appendChild(

                    this.getPlaceholder()

                );

            } else {

                this.canvas.insertBefore(

                    this.getPlaceholder(),

                    after

                );

            }

        });

        this.canvas.addEventListener("drop", e => {

            e.preventDefault();

            if (!this.dragging)
                return;

            window.History?.snapshot();

            this.getPlaceholder().replaceWith(

                this.dragging

            );

        });

    }

    /* ========================================================= */

    getPlaceholder() {

        if (!this.placeholder) {

            this.placeholder = document.createElement("div");

            this.placeholder.className = "drop-placeholder";

        }

        return this.placeholder;

    }

    /* ========================================================= */

    removePlaceholder() {

        this.placeholder?.remove();

    }

    /* ========================================================= */

    getDragAfterElement(y) {

        const elements = [

            ...this.canvas.querySelectorAll(

                ".canvas-element:not(.dragging)"

            )

        ];

        return elements.reduce(

            (closest, child) => {

                const box = child.getBoundingClientRect();

                const offset =

                    y -

                    box.top -

                    box.height / 2;

                if (

                    offset < 0 &&

                    offset > closest.offset

                ) {

                    return {

                        offset,

                        element: child

                    };

                }

                return closest;

            },

            {

                offset: Number.NEGATIVE_INFINITY

            }

        ).element;

    }

    /* ========================================================= */

    duplicate() {

        const selected = Selection.getSelected();

        if (!selected)
            return;

        // Snapshot the pre-change state so Undo actually reverts this action
        window.History?.snapshot();

        const clone = selected.cloneNode(true);

        selected.after(clone);

    }

    /* ========================================================= */

    // Hide/show the selected element right on the editing canvas. It stays
    // selected (and the toolbar stays reachable) while hidden, so clicking
    // this same button again always brings it back — no need to click
    // through an invisible element to restore it.
    toggleVisibility() {

        const selected = Selection.getSelected();

        if (!selected)
            return;

        window.History?.snapshot();

        const isHidden = selected.style.display === "none";

        if (isHidden) {

            selected.style.display = selected.dataset.prevDisplay || "";

            delete selected.dataset.prevDisplay;

        } else {

            selected.dataset.prevDisplay = selected.style.display || "";

            selected.style.display = "none";

        }

    }

    /* ========================================================= */

    delete() {

        const selected = Selection.getSelected();

        if (!selected)
            return;

        window.History?.snapshot();

        selected.remove();

        Selection.clear();

    }

    /* ========================================================= */

    wrap(tag = "div") {

        const selected = Selection.getSelected();

        if (!selected)
            return;

        window.History?.snapshot();

        const wrapper = document.createElement(tag);

        wrapper.classList.add("canvas-element");

        selected.parentNode.insertBefore(

            wrapper,

            selected

        );

        wrapper.appendChild(selected);

    }

    /* ========================================================= */

    append(tag = "div") {

        window.History?.snapshot();

        const el = document.createElement(tag);

        el.className = "canvas-element";

        el.dataset.tag = tag;

        el.textContent = tag;

        this.canvas.appendChild(el);

    }

    /* ========================================================= */
    /* "+" menu: pick an element type to insert                  */
    /* ========================================================= */

    showAddMenu() {

        this.closeAddMenu();

        const btn = document.getElementById("add-btn");

        if (!btn)
            return;

        const rect = btn.getBoundingClientRect();

        const menu = document.createElement("div");

        menu.id = "add-menu";

        menu.className = "add-menu";

        CANVAS_PRESET_MENU.forEach(item => {

            const menuBtn = document.createElement("button");

            menuBtn.type = "button";

            menuBtn.className = "add-menu-item";

            const icon = document.createElement("span");

            icon.className = "add-menu-icon";

            icon.textContent = item.icon;

            const label = document.createElement("span");

            label.textContent = t(item.labelKey, item.labelKey);

            menuBtn.appendChild(icon);

            menuBtn.appendChild(label);

            menuBtn.addEventListener("click", (e) => {

                e.stopPropagation();

                this.insertPreset(item.key);

                this.closeAddMenu();

            });

            menu.appendChild(menuBtn);

        });

        document.body.appendChild(menu);

        const menuRect = menu.getBoundingClientRect();

        menu.style.left = Math.max(8, Math.min(
            rect.left + rect.width / 2 - menuRect.width / 2,
            window.innerWidth - menuRect.width - 8
        )) + "px";

        // Opens upward from the bottom-docked floating toolbar — clamped
        // to never go above the viewport's top edge in a very short
        // window (same safety net as animation.js's "+ Track" menu).
        menu.style.top = Math.max(8, rect.top - menuRect.height - 8) + "px";

        setTimeout(() => {

            document.addEventListener("click", this.closeAddMenu);

        }, 0);

        document.addEventListener("keydown", this.handleAddMenuEscape);

    }

    closeAddMenu() {

        document.getElementById("add-menu")?.remove();

        document.removeEventListener("click", this.closeAddMenu);

        document.removeEventListener("keydown", this.handleAddMenuEscape);

    }

    handleAddMenuEscape(e) {

        if (e.key === "Escape")
            this.closeAddMenu();

    }

    insertPreset(key) {

        const preset = CANVAS_PRESETS[key];

        if (!preset)
            return;

        window.History?.snapshot();

        const el = document.createElement(preset.tag);

        el.className = "canvas-element";

        el.dataset.tag = preset.tag;

        // Which preset this came from (text/button/image/colorbox/
        // container) — the inspector uses this to only show fields that
        // make sense for this kind of element (e.g. no "Texto" section on
        // a plain color box), see Renderer.resolveKind().
        el.dataset.kind = key;

        if (preset.textKey !== undefined)
            el.textContent = t(preset.textKey, preset.textKey);

        else if (preset.text !== undefined)
            el.textContent = preset.text;

        // Multi-element presets (form, card...) — each inner piece also
        // gets .canvas-element so it's individually selectable/editable,
        // same as everything inserted via a start template.
        if (preset.htmlFn !== undefined)
            el.innerHTML = preset.htmlFn();

        else if (preset.html !== undefined)
            el.innerHTML = preset.html;

        const attrs = preset.attrsFn ? preset.attrsFn() : preset.attrs;

        if (attrs) {

            Object.entries(attrs).forEach(([name, value]) => {

                el.setAttribute(name, value);

            });

        }

        if (preset.style) {

            Object.entries(preset.style).forEach(([prop, value]) => {

                el.style[prop] = value;

            });

        }

        this.canvas.appendChild(el);

        Selection.select(el);

    }

}

window.Canvas = new CanvasManager();