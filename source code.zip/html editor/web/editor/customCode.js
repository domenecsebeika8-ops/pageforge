// web/editor/customCode.js
//
// The "Code" preset — a deliberately simple escape hatch for anything the
// visual editor doesn't have a control for: raw HTML, CSS, and/or
// JavaScript, written by hand and dropped straight into the page. Think
// Webflow's "Embed" element: unmanaged, unscoped, entirely the author's
// own responsibility — this app makes no attempt to sandbox or namespace
// it, since doing that safely is a much bigger feature than "muy simple"
// calls for, and the content only ever comes from the person building
// their own page, never a third party.
//
// Data model: a single data-code JSON attribute, { html, css, js }.
//
// Same split as Logic (logic.js) and Responsive (responsive.js) between
// what happens live on the editing canvas vs. what happens in the
// exported page:
//   - HTML previews live (it's just markup — set as the block's
//     innerHTML so you can see roughly what it'll look like).
//   - CSS previews live too, via one injected <style> in the editor's own
//     <head> (same trick responsive.js uses), so custom styles are
//     visible while editing without touching the block's own inline style
//     or leaking into the export clone.
//   - JS never runs on the canvas — only once exported/previewed. Running
//     arbitrary user JS during editing could interfere with selection,
//     dragging, or any other part of the app; Logic rules follow this
//     same principle already (see logic.js's own comment on this).

class CustomCodeManager {

    getData(el) {

        try {

            const raw = el.getAttribute("data-code");

            return raw ? JSON.parse(raw) : null;

        } catch (e) {

            return null;

        }

    }

    ensureData(el) {

        return this.getData(el) || { html: "", css: "", js: "" };

    }

    saveData(el, data) {

        window.History?.snapshot();

        const hasAny = (data.html || "").trim() || (data.css || "").trim() || (data.js || "").trim();

        if (hasAny)
            el.setAttribute("data-code", JSON.stringify(data));

        else
            el.removeAttribute("data-code");

    }

    updateField(el, field, value) {

        const data = this.ensureData(el);

        data[field] = value;

        this.saveData(el, data);

        this.applyPreviewHtml(el);

        this.applyPreviewCSS();

    }

    /* =========================================================
       Live canvas preview — HTML renders directly, CSS via one shared
       injected <style>, JS never runs here (see file header).
       ========================================================= */

    applyPreviewHtml(el) {

        const data = this.getData(el);

        const html = data?.html?.trim();

        if (html)
            el.innerHTML = html;

        else
            el.innerHTML = `<span style="opacity:.5;font-style:italic;">${t("Bloque de código vacío — añade HTML en el inspector.")}</span>`;

    }

    applyPreviewCSS() {

        let styleEl = document.getElementById("custom-code-preview-style");

        if (!styleEl) {

            styleEl = document.createElement("style");

            styleEl.id = "custom-code-preview-style";

            document.head.appendChild(styleEl);

        }

        const canvas = document.getElementById("canvas");

        if (!canvas)
            return;

        let css = "";

        canvas.querySelectorAll("[data-code]").forEach(el => {

            const data = this.getData(el);

            if (data?.css?.trim())
                css += data.css + "\n";

        });

        styleEl.textContent = css;

    }

    /* =========================================================
       Export — HTML is already in the clone (applyPreviewHtml already
       wrote it into the live element, and getExportHtml() clones #canvas
       as-is); CSS/JS need to be pulled out of data-code and placed for
       real, since editor-only affordances like the preview <style> tag
       above never leave the editor's own <head>.
       ========================================================= */

    buildExportCSS(root) {

        let css = "";

        root.querySelectorAll("[data-code]").forEach(el => {

            let data;

            try {
                data = JSON.parse(el.getAttribute("data-code"));
            } catch (e) {
                return;
            }

            if (data?.css?.trim())
                css += `/* custom code block */\n${data.css}\n`;

        });

        return css;

    }

    buildExportScripts(root) {

        const blocks = [...root.querySelectorAll("[data-code]")]
            .map(el => {

                try {
                    return JSON.parse(el.getAttribute("data-code"));
                } catch (e) {
                    return null;
                }

            })
            .filter(data => data?.js?.trim());

        if (!blocks.length)
            return "";

        const body = blocks
            .map(data => `(function () {\n${data.js}\n})();`)
            .join("\n");

        return `<script>\n${body}\n</script>`;

    }

}

window.CustomCode = new CustomCodeManager();
