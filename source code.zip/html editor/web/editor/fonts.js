// web/editor/fonts.js
//
// A small curated set of Google Fonts, on top of the original 5 system
// font choices. Picking one of these loads the real font (both live in
// the editor, and in the exported/previewed page) via a <link> to Google
// Fonts' CSS API — this needs an internet connection to actually render,
// same trade-off any real site using Google Fonts has.

const GOOGLE_FONTS = [
    { name: "Poppins", stack: "'Poppins', sans-serif", weights: "400;500;600;700" },
    { name: "Montserrat", stack: "'Montserrat', sans-serif", weights: "400;500;600;700" },
    { name: "Playfair Display", stack: "'Playfair Display', serif", weights: "400;600;700" },
    { name: "Lato", stack: "'Lato', sans-serif", weights: "400;700" },
    { name: "Nunito", stack: "'Nunito', sans-serif", weights: "400;600;700" },
    { name: "Raleway", stack: "'Raleway', sans-serif", weights: "400;600;700" },
    { name: "Merriweather", stack: "'Merriweather', serif", weights: "400;700" },
    { name: "Work Sans", stack: "'Work Sans', sans-serif", weights: "400;500;600" },
    { name: "DM Sans", stack: "'DM Sans', sans-serif", weights: "400;500;700" },
    { name: "Space Grotesk", stack: "'Space Grotesk', sans-serif", weights: "400;500;700" }
];

class FontsManager {

    // Looks up a font-family stack against the curated list. Browsers
    // normalize quoted font names in CSSOM (single quotes -> double
    // quotes) when you read style.fontFamily back from a real element, so
    // comparison strips quotes/whitespace instead of matching verbatim.
    findByStack(stack) {

        const normalize = (s) => (s || "").replace(/["']/g, "").trim();

        return GOOGLE_FONTS.find(f => normalize(f.stack) === normalize(stack));

    }

    urlFor(fonts) {

        const families = fonts
            .map(f => "family=" + encodeURIComponent(f.name).replace(/%20/g, "+") + ":wght@" + f.weights)
            .join("&");

        return `https://fonts.googleapis.com/css2?${families}&display=swap`;

    }

    // Injects (once) the <link> needed to actually render a chosen Google
    // Font inside the editor's own document, so the Texto section's font
    // picker previews the real typeface immediately.
    ensureLoaded(stack) {

        const font = this.findByStack(stack);

        if (!font)
            return;

        const href = this.urlFor([font]);

        if (document.querySelector(`link[href="${href}"]`))
            return;

        const link = document.createElement("link");

        link.rel = "stylesheet";

        link.href = href;

        document.head.appendChild(link);

    }

    // Scans a (detached, exported) root for every font-family actually in
    // use and returns one combined <link> tag for just those — used by
    // getExportHtml() so the exported page only pulls the fonts it needs.
    buildLinkTag(root) {

        const used = new Set();

        root.querySelectorAll("[style*='font-family']").forEach(el => {

            const stack = el.style.fontFamily;

            const font = this.findByStack(stack);

            if (font)
                used.add(font.name);

        });

        if (!used.size)
            return "";

        const fonts = [...used].map(name => GOOGLE_FONTS.find(f => f.name === name));

        return `<link rel="stylesheet" href="${this.urlFor(fonts)}">`;

    }

}

window.Fonts = new FontsManager();
