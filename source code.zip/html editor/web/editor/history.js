// web/editor/history.js

class HistoryManager {

    constructor() {

        this.undoStack = [];

        this.redoStack = [];

        this.maxStates = 100;

    }

    initialize() {

        document.getElementById("undo-btn")?.addEventListener(

            "click",

            () => this.undo()

        );

        document.getElementById("redo-btn")?.addEventListener(

            "click",

            () => this.redo()

        );

        document.addEventListener("keydown", (e) => {

            if (e.ctrlKey && e.key.toLowerCase() === "z") {

                e.preventDefault();

                this.undo();

            }

            if (e.ctrlKey && e.key.toLowerCase() === "y") {

                e.preventDefault();

                this.redo();

            }

        });

    }

    snapshot() {

        const canvas = document.getElementById("canvas");

        if (!canvas)
            return;

        this.undoStack.push(canvas.innerHTML);

        if (this.undoStack.length > this.maxStates)

            this.undoStack.shift();

        this.redoStack.length = 0;

    }

    undo() {

        if (!this.undoStack.length)
            return;

        const canvas = document.getElementById("canvas");

        this.redoStack.push(canvas.innerHTML);

        canvas.innerHTML = this.undoStack.pop();

        Selection.clear();

    }

    redo() {

        if (!this.redoStack.length)
            return;

        const canvas = document.getElementById("canvas");

        this.undoStack.push(canvas.innerHTML);

        canvas.innerHTML = this.redoStack.pop();

        Selection.clear();

    }

    clear() {

        this.undoStack.length = 0;

        this.redoStack.length = 0;

    }

}

window.History = new HistoryManager();

// NOTE: snapshots used to be taken here, reactively, *after* Selection had
// already emitted these events (i.e. after the change happened). That made
// Undo capture the post-change state instead of the pre-change one, so
// clicking Undo appeared to do nothing until you clicked it a second time.
// Snapshots are now taken proactively, before each mutation, directly in
// Selection's update methods (see selection.js) and Canvas's action methods
// (see canvas.js) — so nothing needs to happen here anymore.