// web/editor/hover.js
//
// Pure-CSS hover transitions (":hover" can't be an inline style, so this
// needs a real stylesheet rule) and the shared box-shadow presets used by
// both this file's "Sombra" hover option and Renderer's static shadow
// control in the Apariencia section.
//
// Like Logic and Animation, hover settings are pure data on the element
// (data-hover) while editing — they never actually fire on the canvas
// itself (that's the established convention for anything interactive in
// this app, so it never fights with click-to-select) — and only become a
// real `:hover` rule in the exported/previewed page, via buildExportCSS().

const SHADOW_PRESETS = [
    { value: "soft", labelKey: "shadow_preset_soft", y: 1, blur: 3, alpha: 0.12 },
    { value: "medium", labelKey: "shadow_preset_medium", y: 6, blur: 16, alpha: 0.18 },
    { value: "strong", labelKey: "shadow_preset_strong", y: 20, blur: 40, alpha: 0.28 }
];

function hexToRgbParts(hex) {

    const clean = (hex || "#000000").replace("#", "");

    const full = clean.length === 3 ? clean.split("").map(c => c + c).join("") : clean.padEnd(6, "0");

    const n = parseInt(full, 16) || 0;

    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };

}

// Builds a real box-shadow value from a preset name + hex color.
function composeShadow(presetName, hex) {

    const preset = SHADOW_PRESETS.find(p => p.value === presetName) || SHADOW_PRESETS[1];

    const { r, g, b } = hexToRgbParts(hex || "#000000");

    return `0 ${preset.y}px ${preset.blur}px rgba(${r}, ${g}, ${b}, ${preset.alpha})`;

}

const HOVER_PROPS = [
    { value: "backgroundColor", labelKey: "hover_prop_background", type: "color", cssProp: "background-color" },
    { value: "opacity", labelKey: "hover_prop_opacity", type: "number", min: 0, max: 1, step: 0.01, cssProp: "opacity" },
    { value: "scale", labelKey: "hover_prop_scale", type: "number", min: 0, step: 0.01, cssProp: "transform" },
    { value: "boxShadow", labelKey: "hover_prop_shadow", type: "shadow", cssProp: "box-shadow" }
];

const HOVER_DEFAULT_DURATION = 200;

class HoverManager {

    initialize() {

        // Nothing global to wire — everything is per-element data, read
        // by Renderer's Apariencia section and compiled at export time.

    }

    getData(el) {

        try {

            const raw = el.getAttribute("data-hover");

            return raw ? JSON.parse(raw) : null;

        } catch (e) {

            return null;

        }

    }

    saveData(el, data) {

        window.History?.snapshot();

        el.setAttribute("data-hover", JSON.stringify(data));

    }

    ensureData(el) {

        let data = this.getData(el);

        if (!data) {

            data = { property: "backgroundColor", value: "#8B8B8B", duration: HOVER_DEFAULT_DURATION };

            this.saveData(el, data);

        }

        return data;

    }

    updateData(el, patch) {

        const data = this.ensureData(el);

        Object.assign(data, patch);

        this.saveData(el, data);

        return data;

    }

    remove(el) {

        window.History?.snapshot();

        el.removeAttribute("data-hover");

    }

    /* Compiles every [data-hover] element inside `root` into a real
       :hover rule + matching transition, using each element's data-lid
       (shared with Logic's targeting) as the selector. */
    buildExportCSS(root) {

        const elements = [...root.querySelectorAll("[data-hover]")];

        if (!elements.length)
            return "";

        let css = "";

        elements.forEach(el => {

            let data;

            try {

                data = JSON.parse(el.getAttribute("data-hover"));

            } catch (e) {

                return;

            }

            if (!data?.property)
                return;

            const def = HOVER_PROPS.find(p => p.value === data.property);

            if (!def)
                return;

            const lid = window.Logic ? window.Logic.resolveLid(el) : (() => {

                if (!el.dataset.lid)
                    el.dataset.lid = "lid-" + Math.random().toString(36).slice(2, 9);

                return el.dataset.lid;

            })();

            const duration = data.duration != null && data.duration !== "" ? Number(data.duration) : HOVER_DEFAULT_DURATION;

            let value;

            if (def.value === "scale")
                value = `scale(${data.value})`;

            else if (def.value === "boxShadow")
                value = composeShadow(data.value, data.shadowColor || "#000000");

            else
                value = data.value;

            css += `[data-lid="${lid}"] { transition: ${def.cssProp} ${duration}ms ease; }\n`;

            css += `[data-lid="${lid}"]:hover { ${def.cssProp}: ${value}; }\n`;

        });

        return css;

    }

}

window.HoverFX = new HoverManager();
