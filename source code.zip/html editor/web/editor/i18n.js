// ============================================================
// i18n.js — translation dictionary + language switching.
// English is the base/default language; Spanish is the alternate.
// Loaded first (before every other script) so `t()` is available
// everywhere, including inside static config objects that use
// `labelKey` fields resolved at render time.
// ============================================================

const TRANSLATIONS = {
    en: {
        // Sidebar
        sidebar_explorer: "Project explorer",
        sidebar_components: "Components",
        sidebar_component_layout: "Layout",
        sidebar_component_typography: "Typography",
        sidebar_component_button: "Button",
        sidebar_component_image: "Image",

        // Top bar
        topbar_project: "Project",
        topbar_preview: "Preview",
        topbar_export: "Export",

        // Floating toolbar tooltips
        toolbar_add: "Add element",
        toolbar_duplicate: "Duplicate",
        toolbar_wrap: "Wrap",
        toolbar_hide: "Show/Hide",
        toolbar_delete: "Delete",

        // Inspector
        inspector_no_selection: "No selection",
        inspector_search_placeholder: "Search properties...",
        inspector_empty_state: "Select an element on the canvas to edit its properties.",

        // Shadow presets (hover.js / renderer.js Appearance section) —
        // stable English `value`s with labelKey-driven display text.
        shadow_preset_soft: "Soft",
        shadow_preset_medium: "Medium",
        shadow_preset_strong: "Strong",

        // Hover-transition property picker (hover.js)
        hover_prop_background: "Background",
        hover_prop_opacity: "Opacity",
        hover_prop_scale: "Scale",
        hover_prop_shadow: "Shadow",

        // -------------------------------------------------------------
        // Inspector panel (renderer.js) — section titles, row labels,
        // and dropdown/segmented option labels. These use the original
        // Spanish UI text as the lookup key (see renderer.js's row(),
        // subheading(), section(), selectInput() and segmented()
        // helpers, which call t(text, text) so untranslated strings
        // degrade gracefully to their original Spanish rather than
        // breaking).
        // -------------------------------------------------------------
        "+ Añadir atributo": "+ Add attribute",
        "+ Añadir borde": "+ Add border",
        "+ Añadir otra capa de sombra": "+ Add another shadow layer",
        "+ Añadir regla": "+ Add rule",
        "+ Añadir sombra": "+ Add shadow",
        "+ Añadir transición al pasar el ratón": "+ Add hover transition",
        "+ Crear animación": "+ Create animation",
        "Abajo": "Bottom",
        "Abajo → Arriba": "Bottom → Top",
        "Absoluta": "Absolute",
        "Acción": "Action",
        "Activado": "On",
        "Ajustar": "Hug",
        "Ajuste": "Fit",
        "Alineación": "Alignment",
        "Alinear elementos": "Align items",
        "Alto contraste": "High contrast",
        "Animación": "Animation",
        "Apariencia": "Appearance",
        "Arriba": "Top",
        "Arriba → Abajo": "Top → Bottom",
        "atributo": "attribute",
        "Atributo": "Attribute",
        "Avanzado": "Advanced",
        "Blanco y negro": "Black & white",
        "Borde": "Border",
        "Centro": "Center",
        "clave, p. ej. nombre-usuario": "key, e.g. username",
        "Clase CSS": "CSS class",
        "Clave": "Key",
        "Color": "Color",
        "Color de fondo": "Background color",
        "Color de sombra": "Shadow color",
        "Color del patrón": "Pattern color",
        "Columna": "Column",
        "Contener (sin recortar)": "Contain (no crop)",
        "Contenido": "Content",
        "Cuadrícula": "Grid",
        "Cubrir (recortar)": "Cover (crop)",
        "Cuándo": "When",
        "Degradado": "Gradient",
        "Derecha": "Right",
        "Derecha → Izquierda": "Right → Left",
        "Desvanecido": "Fade",
        "Dirección": "Direction",
        "Discontinuo": "Dashed",
        "Diseño": "Layout",
        "Distribución de contenido": "Content layout",
        "Duración": "Duration",
        "Editar línea de tiempo": "Edit timeline",
        "Efectos rápidos": "Quick effects",
        "Eliminar animación": "Delete animation",
        "Empieza a desvanecerse": "Starts fading at",
        "En línea": "Inline",
        "Espaciado": "Spacing",
        "Espacio": "Gap",
        "Espacio alrededor": "Space around",
        "Espacio entre": "Space between",
        "Estilo": "Style",
        "Estilo de color": "Color style",
        "Estirar": "Stretch",
        "Exportar": "Export",
        "Exportar selección": "Export selection",
        "Fecha objetivo": "Target date",
        "Fijo": "Fixed",
        "Fila": "Row",
        "Filtro": "Filter",
        "Final": "End",
        "Forma": "Shape",
        "Fuente": "Font",
        "Grosor": "Width",
        "Hacia un lado": "To one side",
        "Hacia un punto": "Toward a point",
        "Horizontal": "Horizontal",
        "Imagen": "Image",
        "Imagen subida desde tu ordenador. Pega una URL abajo si prefieres usar una externa.":
            "Image uploaded from your computer. Paste a URL below if you'd rather use an external one.",
        "Individual": "Individual",
        "Iniciales": "Capitalize",
        "Inicio": "Start",
        "Intensidad": "Intensity",
        "Interlineado": "Line height",
        "Invertir orden": "Reverse order",
        "Izquierda": "Left",
        "Izquierda → Derecha": "Left → Right",
        "Justificar contenido": "Justify content",
        "Ligera": "Light",
        "Lineal": "Linear",
        "Lógica": "Logic",
        "MAYÚSCULAS": "UPPERCASE",
        "Margen": "Margin",
        "Mayúsculas": "Capitalization",
        "Media": "Medium",
        "minúsculas": "lowercase",
        "Modo": "Mode",
        "Negra": "Black",
        "Negrita": "Bold",
        "Ninguna": "None",
        "Ninguno": "None",
        "Nueva pestaña": "New tab",
        "Objetivo": "Target",
        "Opacidad": "Opacity",
        "Origen (URL)": "Source (URL)",
        "Oscurecer": "Darken",
        "p. ej. Enter, Escape, a (vacío = cualquiera)": "e.g. Enter, Escape, a (blank = any)",
        "Patrón": "Pattern",
        "Peso": "Weight",
        "Posición": "Position",
        "Predeterminada": "Default",
        "Propiedad": "Property",
        "Punteado": "Dotted",
        "Puntos": "Dots",
        "Quitar borde": "Remove border",
        "Quitar transición": "Remove transition",
        "Radial": "Radial",
        "Radio": "Radius",
        "Rayas diagonales": "Diagonal stripes",
        "Recortar": "Crop",
        "Regla": "Rule",
        "Regular": "Regular",
        "Rellenar": "Fill",
        "Rellenar (deformar)": "Fill (stretch)",
        "Relleno (padding)": "Padding",
        "Retraso": "Delay",
        "Saturado": "Saturated",
        "Se desvanece hacia abajo": "Fades downward",
        "Se desvanece hacia arriba": "Fades upward",
        "Se desvanece hacia la derecha": "Fades to the right",
        "Se desvanece hacia la izquierda": "Fades to the left",
        "Seminegrita": "Semibold",
        "Sepia": "Sepia",
        "Sombra": "Shadow",
        "Subir imagen desde tu ordenador": "Upload image from your computer",
        "Sólido": "Solid",
        "Tamaño": "Size",
        "Tamaño original": "Original size",
        "También puedes arrastrar el elemento directamente en el lienzo.":
            "You can also drag the element directly onto the canvas.",
        "Tecla": "Key",
        "Texto": "Text",
        "Texto alternativo": "Alt text",
        "Tipo de fondo": "Background type",
        "Todos": "All",
        "Todos los lados": "All sides",
        "Transición al pasar el ratón": "Hover transition",
        "Valor": "Value",
        "valor": "value",
        "Vertical": "Vertical",
        "Vidrio esmerilado": "Frosted glass",
        "X e Y": "X & Y",
        "Ángulo": "Angle",

        // -------------------------------------------------------------
        // Canvas element presets (canvas.js) — "+" menu labels and the
        // one-time seed text/HTML stamped onto a freshly inserted element.
        // -------------------------------------------------------------
        preset_text: "Text",
        preset_button: "Button",
        preset_image: "Image",
        preset_colorbox: "Color box",
        preset_container: "Container",
        preset_form: "Form",
        preset_card: "Card",
        preset_label: "Label",
        preset_code: "Code",
        preset_divider: "Divider",

        "Nuevo texto": "New text",
        "Botón": "Button",
        "Contenedor": "Container",
        "Etiqueta": "Label",
        "Bloque de código vacío — añade HTML en el inspector.": "Empty code block — add HTML in the inspector.",
        "Nombre": "Name",
        "Tu nombre": "Your name",
        "Mensaje": "Message",
        "Escribe tu mensaje": "Write your message",
        "Enviar": "Submit",
        "Título de la tarjeta": "Card title",
        "Una breve descripción de este elemento.": "A short description of this element.",
        "Ver más": "Learn more",

        // -------------------------------------------------------------
        // Image crop modal (imageCrop.js)
        // -------------------------------------------------------------
        "Recortar imagen": "Crop image",
        "Arrastra sobre la imagen para dibujar el área que quieres conservar.":
            "Drag over the image to draw the area you want to keep.",
        "Cancelar": "Cancel",
        "Aplicar recorte": "Apply crop",
        "No se pudo recortar esta imagen — probablemente viene de una URL externa sin permiso para editarla. Prueba a subirla primero desde tu ordenador y recórtala después.":
            "Couldn't crop this image — it's probably from an external URL without permission to edit it. Try uploading it from your computer first, then crop it.",

        // -------------------------------------------------------------
        // Start screen (startScreen.js)
        // -------------------------------------------------------------
        "Nuevo proyecto": "New project",
        "Elige una plantilla y configura tu página.": "Choose a template and set up your page.",
        "Plantilla": "Template",
        "En blanco": "Blank",
        "Empieza desde cero.": "Start from scratch.",
        "Landing simple": "Simple landing page",
        "Titular, texto y botón de llamada a la acción.": "Headline, text, and a call-to-action button.",
        "Portfolio básico": "Basic portfolio",
        "Encabezado y una cuadrícula de proyectos.": "Header and a grid of projects.",
        "Blog": "Blog",
        "Encabezado y una lista de artículos.": "Header and a list of posts.",
        "Tienda simple": "Simple store",
        "Encabezado y una cuadrícula de productos.": "Header and a grid of products.",
        "Currículum": "Résumé",
        "Nombre, experiencia y habilidades.": "Name, experience, and skills.",
        "Título de la página": "Page title",
        "Mi página": "My page",
        "Tamaño de lienzo": "Canvas size",
        "Móvil": "Mobile",
        "Empezar": "Get started",
        "Página sin título": "Untitled page",

        // -------------------------------------------------------------
        // Logic (logic.js) — triggers, actions, style-property picker,
        // and target dropdown.
        // -------------------------------------------------------------
        logic_target_self: "This same element",
        "(sin texto)": "(no text)",

        "Clic": "Click",
        "Doble clic": "Double click",
        "Ratón entra": "Mouse enters",
        "Ratón sale": "Mouse leaves",
        "Al cargar la página": "On page load",
        "Al aparecer en pantalla": "When it scrolls into view",
        "Tecla pulsada": "Key pressed",
        "Temporizador (retraso)": "Timer (delay)",

        "Mostrar / ocultar elemento": "Show / hide element",
        "Cambiar un estilo": "Change a style",
        "Alternar clase CSS": "Toggle CSS class",
        "Alternar resplandor (glow)": "Toggle glow",
        "Animación de pulso": "Pulse animation",
        "Cambiar texto": "Change text",
        "Cambiar un atributo": "Change an attribute",
        "Alternar un atributo": "Toggle an attribute",
        "Desplazarse a otro elemento": "Scroll to another element",
        "Enfocar elemento": "Focus element",
        "Incrementar contador": "Increment counter",
        "Ir a una URL": "Go to a URL",
        "Mostrar alerta": "Show alert",
        "Copiar texto al portapapeles": "Copy text to clipboard",
        "Enviar formulario": "Submit form",
        "Restablecer formulario": "Reset form",
        "Mostrar mensaje en consola": "Log message to console",
        "Reproducir animación": "Play animation",
        "Contador hasta una fecha": "Countdown to a date",
        "Guardar valor (entre visitas)": "Remember value (across visits)",
        "Recuperar valor guardado": "Recall saved value",

        "Color de texto": "Text color",
        "Color de borde": "Border color",

        // -------------------------------------------------------------
        // Animation timeline (animation.js) — track labels, preset
        // menu, and panel chrome.
        // -------------------------------------------------------------
        "Posición X": "Position X",
        "Posición Y": "Position Y",
        "Escala X": "Scale X",
        "Escala Y": "Scale Y",
        "Rotación": "Rotation",
        "Estela de resplandor": "Glow trail",

        "Estirar y mover a otro lugar": "Stretch and move elsewhere",
        "Estela y deslizar hacia dentro": "Trail and slide inward",
        "Rebote": "Bounce",
        "Aparecer con zoom": "Zoom in",
        "Sacudida": "Shake",
        "Pulso de atención (bucle)": "Attention pulse (loop)",
        "Deslizar desde abajo": "Slide up",

        "Bucle": "Loop",
        "Autorreproducción": "Autoplay",
        "Color de la estela": "Trail color",
        "⏸ Pausar": "⏸ Pause",
        "▶ Reproducir": "▶ Play",
        "+ Pista": "+ Track",
        "Todas las pistas añadidas": "All tracks added",
        "Quitar pista": "Remove track",
        "fotograma clave": "keyframe",
        "Tiempo": "Time",
        "Eliminar fotograma clave": "Delete keyframe",
        'Añade una pista con "+ Pista" para empezar a crear fotogramas clave.':
            'Add a track with "+ Track" to start creating keyframes.',

        // -------------------------------------------------------------
        // Project settings modal (settings.js)
        // -------------------------------------------------------------
        "Configuración del lienzo": "Canvas settings",
        "Ancho": "Width",
        "Alto": "Height",
        "Cerrar": "Close",

        "Página exportada": "Exported page",

        // -------------------------------------------------------------
        // Responsive breakpoints (responsive.js / renderer.js)
        // -------------------------------------------------------------
        breakpoint_desktop: "Desktop",
        breakpoint_tablet: "Tablet",
        breakpoint_mobile: "Mobile",

        "Responsive": "Responsive",
        "Elige Tablet o Móvil arriba para anular estilos solo en ese tamaño.":
            "Pick Tablet or Mobile above to override styles just for that size.",
        "Ocultar en este tamaño": "Hide at this size",
        "Apilar verticalmente": "Stack vertically",
        "Ancho en este tamaño": "Width at this size",
        "+ Anular ancho en este tamaño": "+ Override width at this size",
        "Quitar anulación de ancho": "Remove width override",
        "Tamaño de texto en este tamaño": "Text size at this size",
        "+ Anular tamaño de texto en este tamaño": "+ Override text size at this size",
        "Quitar anulación de tamaño de texto": "Remove text size override",

        // -------------------------------------------------------------
        // Logic "call-api" action — simple HTTP bridge to any backend
        // (logic.js / renderer.js's buildLogicField)
        // -------------------------------------------------------------
        "Llamar a una API (HTTP)": "Call an API (HTTP)",
        "Método": "Method",
        "Cuerpo": "Body",
        "Al recibir respuesta": "On response",
        "Nada (solo enviar)": "Nothing (fire and forget)",
        "Poner como texto del objetivo": "Set target's text",
        "Poner como valor del objetivo (campos)": "Set target's value (form fields)",
        "Mostrar en consola": "Log to console",
        '{"clave": "valor"} (opcional, ignorado en GET)': '{"key": "value"} (optional, ignored on GET)',

        // -------------------------------------------------------------
        // Position: Fixed/Sticky (renderer.js's buildPositionRows)
        // -------------------------------------------------------------
        "Fija": "Fixed",
        "Pegajosa": "Sticky",
        "Fija se posiciona respecto a la ventana del navegador, no al lienzo — puede que aquí se vea distinto que al exportar. También puedes arrastrarla directamente.":
            "Fixed positions relative to the browser window, not the canvas — it may look different here than once exported. You can also drag it directly.",
        "Desde arriba (al hacer scroll)": "From the top (on scroll)",
        "Se comporta como en línea hasta que el scroll llega a esa distancia del borde superior, y entonces se queda fija ahí.":
            "Behaves like Inline until scrolling reaches that distance from the top edge, then stays fixed there.",

        // -------------------------------------------------------------
        // CSS Grid mode (renderer.js's buildGridContentRows / buildGridItemRows)
        // -------------------------------------------------------------
        "Cuadrícula (Grid)": "Grid",
        "Columnas": "Columns",
        "Justificar elementos": "Justify items",
        'Las filas se crean automáticamente según haga falta. Para que un elemento ocupe varias columnas o filas, selecciónalo y usa "Posición en la cuadrícula" en su propia sección Diseño.':
            'Rows are created automatically as needed. To make an element span multiple columns or rows, select it and use "Grid position" in its own Layout section.',
        "Posición en la cuadrícula (como hijo)": "Grid position (as a child)",
        "Columnas que ocupa": "Column span",
        "Filas que ocupa": "Row span",
        "Solo tiene efecto si el elemento contenedor (el padre) está en modo Cuadrícula (Grid).":
            "Only has an effect if the containing element (the parent) is in Grid mode.",

        // -------------------------------------------------------------
        // Custom Code block (customCode.js / renderer.js's buildCustomCodeSection)
        // -------------------------------------------------------------
        "Código": "Code",
        "El HTML y el CSS se ven aquí mismo en el lienzo. El JavaScript nunca se ejecuta mientras editas — solo al exportar o previsualizar la página.":
            "HTML and CSS show up right here on the canvas. JavaScript never runs while you're editing — only on export or preview.",
    },
    es: {
        sidebar_explorer: "Explorador del proyecto",
        sidebar_components: "Componentes",
        sidebar_component_layout: "Diseño",
        sidebar_component_typography: "Tipografía",
        sidebar_component_button: "Botón",
        sidebar_component_image: "Imagen",

        topbar_project: "Proyecto",
        topbar_preview: "Vista previa",
        topbar_export: "Exportar",

        toolbar_add: "Añadir elemento",
        toolbar_duplicate: "Duplicar",
        toolbar_wrap: "Envolver",
        toolbar_hide: "Ocultar/Mostrar",
        toolbar_delete: "Eliminar",

        inspector_no_selection: "Sin selección",
        inspector_search_placeholder: "Buscar propiedades...",
        inspector_empty_state: "Selecciona un elemento en el lienzo para editar sus propiedades.",

        shadow_preset_soft: "Suave",
        shadow_preset_medium: "Media",
        shadow_preset_strong: "Fuerte",

        hover_prop_background: "Fondo",
        hover_prop_opacity: "Opacidad",
        hover_prop_scale: "Escala",
        hover_prop_shadow: "Sombra",

        preset_text: "Texto",
        preset_button: "Botón",
        preset_image: "Imagen",
        preset_colorbox: "Cuadro de color",
        preset_container: "Contenedor",
        preset_form: "Formulario",
        preset_card: "Tarjeta",
        preset_label: "Etiqueta",
        preset_code: "Código",
        preset_divider: "Separador",

        logic_target_self: "Este mismo elemento",
    },
};

const I18N_STORAGE_KEY = "pageforge-lang";
const I18N_DEFAULT_LANG = "en";

class I18nManager {
    constructor() {
        this.lang = this.loadLang();
        this.listeners = [];
    }

    loadLang() {
        try {
            const saved = window.localStorage && localStorage.getItem(I18N_STORAGE_KEY);
            if (saved && TRANSLATIONS[saved]) return saved;
        } catch (e) {
            // localStorage unavailable (e.g. some file:// contexts) — fall back silently.
        }
        return I18N_DEFAULT_LANG;
    }

    persistLang(lang) {
        try {
            if (window.localStorage) localStorage.setItem(I18N_STORAGE_KEY, lang);
        } catch (e) {
            // ignore — non-persistent session is an acceptable degradation.
        }
    }

    // Looks up `key` in the current language dict. If missing, falls back
    // to `fallback` (or the raw key itself) — NOT to the English dict.
    // This matters a lot: most call sites use the original Spanish UI
    // string as the lookup key itself (t(labelText, labelText)), so an
    // untranslated key must degrade to that original Spanish text while
    // in Spanish mode, rather than leaking the English translation in
    // through an English-dict fallback. Keys that need a real fallback
    // chain (labelKey-style ids like "shadow_preset_soft") always get an
    // explicit entry in *both* language dicts instead of relying on one.
    t(key, fallback) {
        const dict = TRANSLATIONS[this.lang] || TRANSLATIONS[I18N_DEFAULT_LANG];
        if (dict && dict[key] !== undefined) return dict[key];
        return fallback !== undefined ? fallback : key;
    }

    getLang() {
        return this.lang;
    }

    setLang(lang) {
        if (!TRANSLATIONS[lang] || lang === this.lang) return;
        this.lang = lang;
        this.persistLang(lang);
        if (typeof document !== "undefined") {
            document.documentElement.lang = lang;
            this.applyStatic();
            this.updateSwitchUI();
        }
        this.listeners.forEach((cb) => {
            try {
                cb(lang);
            } catch (e) {
                console.error("i18n listener error", e);
            }
        });
    }

    // Register a callback fired after the language changes — used by
    // dynamic panels (inspector, animation timeline, start screen...)
    // to trigger their own re-render.
    onChange(cb) {
        this.listeners.push(cb);
    }

    // Applies translations to every element in the static HTML that
    // carries a data-i18n / data-i18n-placeholder / data-tooltip-i18n
    // attribute.
    applyStatic(root) {
        const scope = root || document;
        scope.querySelectorAll("[data-i18n]").forEach((el) => {
            el.textContent = this.t(el.getAttribute("data-i18n"));
        });
        scope.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
            el.setAttribute("placeholder", this.t(el.getAttribute("data-i18n-placeholder")));
        });
        scope.querySelectorAll("[data-tooltip-i18n]").forEach((el) => {
            el.setAttribute("data-tooltip", this.t(el.getAttribute("data-tooltip-i18n")));
        });
        scope.querySelectorAll("[data-i18n-title]").forEach((el) => {
            el.setAttribute("title", this.t(el.getAttribute("data-i18n-title")));
        });
    }

    updateSwitchUI() {
        const switchEl = document.getElementById("lang-switch");
        if (!switchEl) return;
        switchEl.querySelectorAll("button[data-lang]").forEach((btn) => {
            btn.classList.toggle("active", btn.dataset.lang === this.lang);
        });
    }

    init() {
        document.documentElement.lang = this.lang;
        this.applyStatic();
        this.updateSwitchUI();

        const switchEl = document.getElementById("lang-switch");
        if (switchEl) {
            switchEl.addEventListener("click", (e) => {
                const btn = e.target.closest("button[data-lang]");
                if (!btn) return;
                this.setLang(btn.dataset.lang);
            });
        }
    }
}

window.I18n = new I18nManager();
window.t = (key, fallback) => window.I18n.t(key, fallback);

if (typeof document !== "undefined") {
    document.addEventListener("DOMContentLoaded", () => window.I18n.init());
}
