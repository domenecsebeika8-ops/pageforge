// web/editor/imageCrop.js
//
// A small crop tool for <img> elements: drag a rectangle over the image,
// click "Aplicar" and it's actually cropped (drawn onto an offscreen
// canvas and re-encoded), replacing src with the cropped result — so the
// crop is permanent/exported as-is, not just a CSS trick.
//
// Reuses the app's existing .modal-overlay/.modal pattern (see
// startScreen.js / settings.js) rather than inventing new chrome.

class ImageCropManager {

    open(el) {

        const overlay = document.createElement("div");

        overlay.className = "modal-overlay";

        const modal = document.createElement("div");

        modal.className = "modal";

        modal.style.width = "520px";

        const title = document.createElement("h2");

        title.className = "modal-title";

        title.textContent = t("Recortar imagen");

        modal.appendChild(title);

        const subtitle = document.createElement("div");

        subtitle.className = "modal-subtitle";

        subtitle.textContent = t("Arrastra sobre la imagen para dibujar el área que quieres conservar.");

        modal.appendChild(subtitle);

        const stage = document.createElement("div");

        stage.className = "crop-stage";

        const img = document.createElement("img");

        img.src = el.getAttribute("src") || "";

        img.className = "crop-stage-img";

        img.draggable = false;

        stage.appendChild(img);

        const selectionBox = document.createElement("div");

        selectionBox.className = "crop-selection";

        stage.appendChild(selectionBox);

        modal.appendChild(stage);

        let rect = null;

        const startDrag = (event) => {

            event.preventDefault();

            const bounds = stage.getBoundingClientRect();

            const startX = Utils.clamp(event.clientX - bounds.left, 0, bounds.width);

            const startY = Utils.clamp(event.clientY - bounds.top, 0, bounds.height);

            selectionBox.style.display = "block";

            const onMove = (moveEvent) => {

                const x = Utils.clamp(moveEvent.clientX - bounds.left, 0, bounds.width);

                const y = Utils.clamp(moveEvent.clientY - bounds.top, 0, bounds.height);

                const left = Math.min(startX, x);

                const top = Math.min(startY, y);

                const width = Math.abs(x - startX);

                const height = Math.abs(y - startY);

                selectionBox.style.left = left + "px";

                selectionBox.style.top = top + "px";

                selectionBox.style.width = width + "px";

                selectionBox.style.height = height + "px";

                rect = { left, top, width, height, stageWidth: bounds.width, stageHeight: bounds.height };

                applyBtn.disabled = width < 8 || height < 8;

            };

            const onUp = () => {

                document.removeEventListener("mousemove", onMove);

                document.removeEventListener("mouseup", onUp);

            };

            document.addEventListener("mousemove", onMove);

            document.addEventListener("mouseup", onUp);

        };

        stage.addEventListener("mousedown", startDrag);

        const actions = document.createElement("div");

        actions.style.cssText = "display:flex; gap:8px; margin-top:16px;";

        const cancelBtn = document.createElement("button");

        cancelBtn.type = "button";

        cancelBtn.className = "btn secondary";

        cancelBtn.style.flex = "1";

        cancelBtn.textContent = t("Cancelar");

        cancelBtn.addEventListener("click", () => overlay.remove());

        const applyBtn = document.createElement("button");

        applyBtn.type = "button";

        applyBtn.className = "btn primary";

        applyBtn.style.flex = "1";

        applyBtn.textContent = t("Aplicar recorte");

        applyBtn.disabled = true;

        applyBtn.addEventListener("click", () => {

            if (!rect)
                return;

            this.applyCrop(el, img, rect);

            overlay.remove();

        });

        actions.appendChild(cancelBtn);

        actions.appendChild(applyBtn);

        modal.appendChild(actions);

        overlay.appendChild(modal);

        // Click outside the modal cancels, same convention as Settings.
        overlay.addEventListener("click", (e) => {

            if (e.target === overlay)
                overlay.remove();

        });

        document.body.appendChild(overlay);

    }

    applyCrop(el, previewImg, rect) {

        const naturalWidth = previewImg.naturalWidth || rect.stageWidth;

        const naturalHeight = previewImg.naturalHeight || rect.stageHeight;

        const scaleX = naturalWidth / rect.stageWidth;

        const scaleY = naturalHeight / rect.stageHeight;

        const sx = rect.left * scaleX;

        const sy = rect.top * scaleY;

        const sw = rect.width * scaleX;

        const sh = rect.height * scaleY;

        const canvas = document.createElement("canvas");

        canvas.width = Math.max(1, Math.round(sw));

        canvas.height = Math.max(1, Math.round(sh));

        try {

            const ctx = canvas.getContext("2d");

            ctx.drawImage(previewImg, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);

            const dataUrl = canvas.toDataURL("image/png");

            window.History?.snapshot();

            el.setAttribute("src", dataUrl);

            window.Inspector?.refresh();

        } catch (err) {

            // Cross-origin images (loaded via an external URL, without
            // CORS headers) taint the canvas and block toDataURL — this
            // never happens for images uploaded from disk (data: URIs).
            window.alert(t("No se pudo recortar esta imagen — probablemente viene de una URL externa sin permiso para editarla. Prueba a subirla primero desde tu ordenador y recórtala después."));

        }

    }

}

window.ImageCrop = new ImageCropManager();
