// web/editor/inspector.js

class Inspector {

    constructor() {

        this.title = null;

        this.search = null;

        this.container = null;

    }

    initialize() {

        this.title = document.getElementById("selected-element");

        this.search = document.getElementById("property-search");

        this.container = document.getElementById("inspector-content");

        this.search?.addEventListener("input", () => {

            this.filter(this.search.value);

        });

        Selection.addListener("selectionChanged", ({ tag }) => {

            this.title.textContent = `<${tag}>`;

            window.Renderer.render(tag);

            window.Binder.refresh();

        });

        Selection.addListener("selectionCleared", () => {

            this.title.textContent = t("inspector_no_selection");

            window.Renderer.clear();

        });

    }

    filter(query) {

        query = query.toLowerCase();

        const rows = this.container.querySelectorAll(".property-row");

        rows.forEach(row => {

            const label = row.querySelector("label");

            if (!label)
                return;

            row.style.display =

                label.textContent.toLowerCase().includes(query)

                ? ""

                : "none";

        });

        const sections = this.container.querySelectorAll(".inspector-section");

        sections.forEach(section => {

            const visible = [...section.querySelectorAll(".property-row")]

                .some(row => row.style.display !== "none");

            section.style.display = visible ? "" : "none";

        });

    }

    collapseAll() {

        this.container.querySelectorAll(".inspector-section")

            .forEach(section => {

                section.classList.add("collapsed");

            });

    }

    expandAll() {

        this.container.querySelectorAll(".inspector-section")

            .forEach(section => {

                section.classList.remove("collapsed");

            });

    }

    toggleSection(section) {

        if (!section)
            return;

        section.classList.toggle("collapsed");

        // Remember the user's choice so the section doesn't snap shut (or
        // pop back open) the next time the panel is rebuilt.
        const title = section.querySelector(".inspector-section-header")?.dataset.sectionKey;

        if (title)
            window.Renderer?.setSectionExpanded(title, !section.classList.contains("collapsed"));

    }

    attachCollapsing() {

        this.container

            .querySelectorAll(".inspector-section-header")

            .forEach(header => {

                header.onclick = () => {

                    this.toggleSection(

                        header.parentElement

                    );

                };

            });

    }

    refresh() {

        const tag = Selection.getTag();

        if (!tag) {

            window.Renderer.clear();

            return;

        }

        window.Renderer.render(tag);

        window.Binder.refresh();

        this.attachCollapsing();

    }

}

window.Inspector = new Inspector();