// web/editor/logic.js
//
// A small "no-code" interactions system: each canvas element can carry a
// list of simple rules (Trigger -> Action -> Target/Value/...), stored as
// JSON in its data-logic attribute. Rules are pure data while editing —
// they only become real event listeners in the exported/previewed page,
// via buildRuntimeScript(), so they never fire while you're clicking
// around the canvas trying to select things.

const LOGIC_TRIGGERS = [
    { value: "click", label: "Clic" },
    { value: "dblclick", label: "Doble clic" },
    { value: "mouseenter", label: "Ratón entra" },
    { value: "mouseleave", label: "Ratón sale" },
    { value: "load", label: "Al cargar la página" },
    { value: "onview", label: "Al aparecer en pantalla" },
    { value: "keydown", label: "Tecla pulsada" },
    { value: "timer", label: "Temporizador (retraso)" }
];

// Extra fields a TRIGGER needs, same idea as LOGIC_ACTION_FIELDS below.
const LOGIC_TRIGGER_FIELDS = {
    keydown: ["key"],
    timer: ["delay"]
};

const LOGIC_ACTIONS = [
    { value: "toggle-visibility", label: "Mostrar / ocultar elemento" },
    { value: "set-style", label: "Cambiar un estilo" },
    { value: "toggle-class", label: "Alternar clase CSS" },
    { value: "toggle-glow", label: "Alternar resplandor (glow)" },
    { value: "toggle-pulse", label: "Animación de pulso" },
    { value: "set-text", label: "Cambiar texto" },
    { value: "set-attribute", label: "Cambiar un atributo" },
    { value: "toggle-attribute", label: "Alternar un atributo" },
    { value: "scroll-to", label: "Desplazarse a otro elemento" },
    { value: "focus-element", label: "Enfocar elemento" },
    { value: "increment-counter", label: "Incrementar contador" },
    { value: "link", label: "Ir a una URL" },
    { value: "alert", label: "Mostrar alerta" },
    { value: "copy-text", label: "Copiar texto al portapapeles" },
    { value: "submit-form", label: "Enviar formulario" },
    { value: "reset-form", label: "Restablecer formulario" },
    { value: "console-log", label: "Mostrar mensaje en consola" },
    { value: "play-animation", label: "Reproducir animación" },
    { value: "countdown-to-date", label: "Contador hasta una fecha" },
    { value: "remember-value", label: "Guardar valor (entre visitas)" },
    { value: "recall-value", label: "Recuperar valor guardado" },
    { value: "call-api", label: "Llamar a una API (HTTP)" }
];

// Options for call-api's "responseHandling" field — what to do with the
// server's response body once it comes back, if anything.
const LOGIC_RESPONSE_HANDLING_OPTIONS = [
    { value: "none", label: "Nada (solo enviar)" },
    { value: "set-text", label: "Poner como texto del objetivo" },
    { value: "set-value", label: "Poner como valor del objetivo (campos)" },
    { value: "console", label: "Mostrar en consola" }
];

const LOGIC_HTTP_METHODS = [
    { value: "GET", label: "GET" },
    { value: "POST", label: "POST" },
    { value: "PUT", label: "PUT" },
    { value: "PATCH", label: "PATCH" },
    { value: "DELETE", label: "DELETE" }
];

const LOGIC_STYLE_PROPS = [
    { value: "backgroundColor", label: "Fondo" },
    { value: "color", label: "Color de texto" },
    { value: "opacity", label: "Opacidad" },
    { value: "borderColor", label: "Color de borde" }
];

// Which extra fields each action needs, rendered in order by Renderer's
// Logic section. "target" always resolves to "self" or another element's
// data-lid; the rest are plain values stored on the rule.
const LOGIC_ACTION_FIELDS = {
    "toggle-visibility": ["target", "duration"],
    "set-style": ["target", "property", "value", "duration"],
    "toggle-class": ["target", "className"],
    "toggle-glow": ["target", "color", "duration"],
    "toggle-pulse": ["target", "duration"],
    "set-text": ["target", "value"],
    "set-attribute": ["target", "attrName", "value"],
    "toggle-attribute": ["target", "attrName"],
    "scroll-to": ["target"],
    "focus-element": ["target"],
    "increment-counter": ["target"],
    "link": ["url", "newTab"],
    "alert": ["value"],
    "copy-text": ["value"],
    "submit-form": ["target"],
    "reset-form": ["target"],
    "console-log": ["value"],
    "play-animation": ["target"],
    "countdown-to-date": ["target", "date"],
    "remember-value": ["target", "storageKey"],
    "recall-value": ["target", "storageKey"],
    // Simple, language-agnostic bridge to any backend: plain HTTP via
    // fetch(). Works with a local server written in Python, C#, or
    // anything else that can speak HTTP — see USER_GUIDE.md for minimal
    // server examples in a couple of languages. "target" here means
    // "which element gets the response", per responseHandling below.
    "call-api": ["url", "httpMethod", "body", "target", "responseHandling"]
};

// Default transition/animation duration (ms) when a rule doesn't set one.
const LOGIC_DEFAULT_DURATION = 300;

class LogicManager {

    initialize() {

        // Nothing global to wire — everything is per-element, built by
        // Renderer's "Logic" section in the inspector.

    }

    getRules(el) {

        try {

            return JSON.parse(el.dataset.logic || "[]");

        } catch (e) {

            return [];

        }

    }

    saveRules(el, rules) {

        window.History?.snapshot();

        if (rules.length)
            el.setAttribute("data-logic", JSON.stringify(rules));

        else
            el.removeAttribute("data-logic");

    }

    addRule(el) {

        const rules = this.getRules(el);

        rules.push({ trigger: "click", action: "toggle-visibility", target: "self" });

        this.saveRules(el, rules);

    }

    updateRule(el, index, patch) {

        const rules = this.getRules(el);

        if (!rules[index])
            return;

        rules[index] = { ...rules[index], ...patch };

        this.saveRules(el, rules);

    }

    removeRule(el, index) {

        const rules = this.getRules(el);

        rules.splice(index, 1);

        this.saveRules(el, rules);

    }

    /* Returns dropdown options for every element currently on the canvas,
       lazily assigning each a stable data-lid so it can be targeted. */
    getTargetOptions() {

        const canvas = document.getElementById("canvas");

        const options = [{ value: "self", labelKey: "logic_target_self" }];

        if (!canvas)
            return options;

        canvas.querySelectorAll(".canvas-element").forEach(el => {

            const lid = this.resolveLid(el);

            const text = (el.textContent || "").trim().slice(0, 24) || t("(sin texto)");

            options.push({ value: lid, label: `<${el.tagName.toLowerCase()}> ${text}` });

        });

        return options;

    }

    resolveLid(el) {

        if (!el.dataset.lid)
            el.dataset.lid = "lid-" + Math.random().toString(36).slice(2, 9);

        return el.dataset.lid;

    }

    /* Turns every data-logic rule found inside `root` (a detached clone of
       the canvas, built during export/preview) into a <script> block that
       wires up real event listeners in the exported document. */
    buildRuntimeScript(root) {

        const hasLogic = root.querySelector("[data-logic]");

        if (!hasLogic)
            return "";

        return `<script>
(function () {
    function resolveTarget(rule, selfEl) {
        if (!rule.target || rule.target === "self") return selfEl;
        return document.querySelector('[data-lid="' + rule.target + '"]');
    }

    function applyRule(rule, selfEl) {
        var action = rule.action;
        var target = resolveTarget(rule, selfEl);

        var duration = rule.duration != null && rule.duration !== "" ? Number(rule.duration) : ${LOGIC_DEFAULT_DURATION};

        if (action === "toggle-visibility") {
            if (target) {
                target.style.transition = "opacity " + duration + "ms ease";
                target.classList.toggle("logic-hidden");
            }
        } else if (action === "set-style") {
            if (target && rule.property) {
                target.style.transition = rule.property.replace(/[A-Z]/g, function (c) { return "-" + c.toLowerCase(); }) + " " + duration + "ms ease";
                target.style[rule.property] = rule.value || "";
            }
        } else if (action === "toggle-class") {
            if (target && rule.className) target.classList.toggle(rule.className);
        } else if (action === "toggle-glow") {
            if (target) {
                target.style.transition = "box-shadow " + duration + "ms ease";
                target.style.boxShadow = target.style.boxShadow ? "" : ("0 0 20px " + (rule.value || "#B4A996"));
            }
        } else if (action === "toggle-pulse") {
            if (target) {
                target.style.animationDuration = duration + "ms";
                target.classList.remove("logic-pulse");
                void target.offsetWidth; // restart the animation even if the class was already present
                target.classList.add("logic-pulse");
            }
        } else if (action === "set-text") {
            if (target) target.textContent = rule.value || "";
        } else if (action === "set-attribute") {
            if (target && rule.attrName) target.setAttribute(rule.attrName, rule.value || "");
        } else if (action === "toggle-attribute") {
            if (target && rule.attrName) {
                if (target.hasAttribute(rule.attrName)) target.removeAttribute(rule.attrName);
                else target.setAttribute(rule.attrName, "");
            }
        } else if (action === "scroll-to") {
            if (target && target.scrollIntoView) target.scrollIntoView({ behavior: "smooth", block: "start" });
        } else if (action === "focus-element") {
            if (target && target.focus) target.focus();
        } else if (action === "increment-counter") {
            if (target) {
                var n = parseInt(target.textContent, 10);
                target.textContent = (isNaN(n) ? 0 : n) + 1;
            }
        } else if (action === "link") {
            if (rule.url) {
                if (rule.newTab) window.open(rule.url, "_blank");
                else window.location.href = rule.url;
            }
        } else if (action === "alert") {
            window.alert(rule.value || "");
        } else if (action === "copy-text") {
            if (navigator.clipboard) navigator.clipboard.writeText(rule.value || "");
        } else if (action === "submit-form") {
            var form = target ? target.closest("form") : null;
            if (form) { if (form.requestSubmit) form.requestSubmit(); else form.submit(); }
        } else if (action === "reset-form") {
            var form2 = target ? target.closest("form") : null;
            if (form2) form2.reset();
        } else if (action === "console-log") {
            console.log(rule.value || "Logic rule triggered", target);
        } else if (action === "play-animation") {
            if (target) {
                // Restart the CSS animation from frame 0 even if it already
                // ran (or is paused, for a non-autoplay animation) — a bare
                // animation-play-state:running would resume mid-way instead.
                target.style.animationName = "none";
                void target.offsetWidth;
                target.style.animationName = "";
                target.style.animationPlayState = "running";
            }
        } else if (action === "countdown-to-date") {
            if (target && rule.value) {
                var targetTime = new Date(rule.value).getTime();
                var tick = function () {
                    var diff = targetTime - Date.now();
                    if (isNaN(targetTime)) { return; }
                    if (diff <= 0) {
                        target.textContent = "0";
                        clearInterval(intervalId);
                        return;
                    }
                    var days = Math.floor(diff / 86400000);
                    var hours = Math.floor((diff % 86400000) / 3600000);
                    var minutes = Math.floor((diff % 3600000) / 60000);
                    var seconds = Math.floor((diff % 60000) / 1000);
                    target.textContent = days + "d " + hours + "h " + minutes + "m " + seconds + "s";
                };
                tick();
                var intervalId = setInterval(tick, 1000);
            }
        } else if (action === "remember-value") {
            if (target && rule.storageKey) {
                try {
                    var toStore = "value" in target ? target.value : target.textContent;
                    localStorage.setItem(rule.storageKey, toStore);
                } catch (e) {}
            }
        } else if (action === "recall-value") {
            if (target && rule.storageKey) {
                try {
                    var stored = localStorage.getItem(rule.storageKey);
                    if (stored !== null) {
                        if ("value" in target) target.value = stored;
                        else target.textContent = stored;
                    }
                } catch (e) {}
            }
        } else if (action === "call-api") {
            if (rule.url) {
                var method = rule.httpMethod || "GET";
                var opts = { method: method };
                if (rule.body && method !== "GET" && method !== "HEAD") {
                    opts.headers = { "Content-Type": "application/json" };
                    opts.body = rule.body;
                }
                fetch(rule.url, opts).then(function (res) {
                    return res.text();
                }).then(function (text) {
                    if (rule.responseHandling === "set-text") {
                        if (target) target.textContent = text;
                    } else if (rule.responseHandling === "set-value") {
                        if (target && "value" in target) target.value = text;
                    } else if (rule.responseHandling === "console") {
                        console.log("call-api response:", text);
                    }
                }).catch(function (err) {
                    console.error("call-api failed:", err);
                });
            }
        }
    }

    document.querySelectorAll("[data-logic]").forEach(function (el) {
        var rules = [];
        try { rules = JSON.parse(el.getAttribute("data-logic") || "[]"); } catch (e) {}

        rules.forEach(function (rule) {
            if (rule.trigger === "load") {
                applyRule(rule, el);
            } else if (rule.trigger === "onview") {
                if ("IntersectionObserver" in window) {
                    var io = new IntersectionObserver(function (entries) {
                        entries.forEach(function (entry) {
                            if (entry.isIntersecting) {
                                applyRule(rule, el);
                                io.unobserve(el);
                            }
                        });
                    });
                    io.observe(el);
                } else {
                    applyRule(rule, el);
                }
            } else if (rule.trigger === "timer") {
                setTimeout(function () {
                    applyRule(rule, el);
                }, rule.delay != null && rule.delay !== "" ? Number(rule.delay) : 1000);
            } else if (rule.trigger === "keydown") {
                document.addEventListener("keydown", function (e) {
                    if (!rule.key || String(e.key).toLowerCase() === String(rule.key).toLowerCase()) {
                        applyRule(rule, el);
                    }
                });
            } else {
                el.addEventListener(rule.trigger, function () {
                    applyRule(rule, el);
                });
            }
        });
    });
})();
</script>`;

    }

}

window.Logic = new LogicManager();
