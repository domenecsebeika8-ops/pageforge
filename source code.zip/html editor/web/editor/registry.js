/**
 * ============================================================
 * Pageforge Registry
 *
 * Central metadata registry for the editor.
 * ============================================================
 */

class Registry {

    constructor() {

        this.elements = new Map();
        this.capabilities = new Map();
        this.properties = new Map();

    }

    /* ===================================================== */

    registerProperty(property) {

        if (!property.id)
            throw new Error("Property requires an id.");

        this.properties.set(property.id, property);

    }

    /* ===================================================== */

    registerCapability(name, config) {

        this.capabilities.set(name, {

            name,

            label: config.label || name,

            properties: config.properties || []

        });

    }

    /* ===================================================== */

    registerElement(tag, config) {

        this.elements.set(tag.toLowerCase(), {

            tag,

            label: config.label || tag,

            inherits: config.inherits || []

        });

    }

    /* ===================================================== */

    getProperty(id) {

        return this.properties.get(id);

    }

    /* ===================================================== */

    getCapability(name) {

        return this.capabilities.get(name);

    }

    /* ===================================================== */

    getElement(tag) {

        return this.elements.get(tag.toLowerCase());

    }

    /* ===================================================== */

    // web/editor/registry.js

    /* ===================================================== */

    resolve(tag) {

        const element = this.getElement(tag);

        if (!element)
            return [];

        // This will hold the properly formatted section objects
        const resolvedSections = [];

        const added = new Set();

        for (const capabilityName of element.inherits) {

            const capability = this.getCapability(capabilityName);

            if (!capability)
                continue;

            // Group properties for this specific capability
            const sectionProperties = [];

            for (const propertyId of capability.properties) {

                if (added.has(propertyId))
                    continue;

                const property = this.getProperty(propertyId);

                if (!property)
                    continue;

                sectionProperties.push(property);

                added.add(propertyId);

            }

            // If the section has properties, bundle it into the format the Renderer expects
            if (sectionProperties.length > 0) {
                resolvedSections.push({
                    section: { 
                        title: capability.label 
                    },
                    properties: sectionProperties
                });
            }

        }

        return resolvedSections;

    }


    /* ===================================================== */

    initialize() {

        /* -----------------------------
           Properties
        ------------------------------ */

        this.registerProperty({

            id: "text",

            label: "Text",

            type: "text"

        });

        this.registerProperty({

            id: "font-size",

            label: "Font Size",

            type: "number",

            css: "fontSize",

            unit: "px"

        });

        this.registerProperty({

            id: "color",

            label: "Text Color",

            type: "color",

            css: "color"

        });

        this.registerProperty({

            id: "background",

            label: "Background",

            type: "color",

            css: "backgroundColor"

        });

        this.registerProperty({

            id: "width",

            label: "Width",

            type: "number",

            css: "width",

            unit: "px"

        });

        this.registerProperty({

            id: "height",

            label: "Height",

            type: "number",

            css: "height",

            unit: "px"

        });

        /* -----------------------------
           Capabilities
        ------------------------------ */

        this.registerCapability("typography", {

            properties: [

                "text",

                "font-size",

                "color"

            ]

        });

        this.registerCapability("layout", {

            properties: [

                "width",

                "height",

                "background"

            ]

        });

        /* -----------------------------
           Elements
        ------------------------------ */

        this.registerElement("div", {

            inherits: [

                "layout"

            ]

        });

        this.registerElement("button", {

            inherits: [

                "typography",

                "layout"

            ]

        });

        this.registerElement("p", {

            inherits: [

                "typography"

            ]

        });

        this.registerElement("h1", {

            inherits: [

                "typography"

            ]

        });

    }

}

window.Registry = new Registry();

window.Registry.initialize();