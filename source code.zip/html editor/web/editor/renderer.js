// web/editor/renderer.js
//
// Builds the right-hand inspector panel for the currently selected element,
// agrupado en 6 secciones: Texto, Diseño (tamaño + posición + distribución
// de contenido), Espaciado (relleno + margen), Apariencia (fondo/radio/
// opacidad + borde), Lógica y Avanzado (atributos personalizados +
// exportar selección).
//
// Plain value edits (typing in a number/text/color/select field) call
// Selection.updateStyle/updateAttribute directly and do NOT trigger a full
// re-render, so focus/cursor position is preserved while typing. Only
// actions that change *which* controls should be visible (Ajustar/Fijo/
// Rellenar, En línea/Absoluta, modo de relleno/margen, añadir/quitar
// borde, añadir/quitar atributo) trigger a full re-render of the panel.

// CSS position values <-> buildPositionRows' segmented control labels.
// "" (the empty string Selection.updateStyle uses to clear a style) reads
// back as "static", which maps to "Inline" — same as every other
// untouched position-family style in this app.
const RENDERER_POSITION_VALUE_TO_LABEL = { static: "Inline", absolute: "Absolute", fixed: "Fixed", sticky: "Sticky" };
const RENDERER_POSITION_LABEL_TO_VALUE = { Inline: "", Absolute: "absolute", Fixed: "fixed", Sticky: "sticky" };

class Renderer {

    constructor() {

        // Explicit mode overrides (padding/margin) per element — needed
        // because e.g. "0/0/0/0" is ambiguous between "Ninguno" y "Todos".
        this.spacingModes = new WeakMap();

        // Which sections the user has expanded, by title. Persisted across
        // re-renders (including the internal rerenders triggered by mode
        // switches) so a section never snaps shut on you mid-interaction.
        // "Texto" starts open, everything else starts collapsed the first
        // time an element is selected.
        this.expandedSections = new Set(["Texto"]);

    }

    setSectionExpanded(title, expanded) {

        if (expanded)
            this.expandedSections.add(title);

        else
            this.expandedSections.delete(title);

    }

    initialize() {

        this.container = document.getElementById("inspector-content");

    }

    clear() {

        if (!this.container)
            return;

        this.container.innerHTML = "";

    }

    // Which "kind" of element this is (set on insertion by Canvas's "+"
    // menu, see canvas.js's insertPreset) — used to only show inspector
    // fields that actually make sense for it. Falls back to a tag-based
    // guess for elements that predate this (default template content,
    // legacy data) so nothing regresses for them.
    resolveKind(el) {

        if (el.dataset.kind)
            return el.dataset.kind;

        const tag = el.tagName.toLowerCase();

        if (tag === "img")
            return "image";

        return "generic";

    }

    render(tag) {

        this.clear();

        const el = Selection.getSelected();

        if (!el || !this.container)
            return;

        const rerender = () => this.render(tag);

        const kind = this.resolveKind(el);

        // Elements whose "content" isn't a single block of text — a color
        // box (nothing to say), an image (its src is the content), a
        // divider (no content at all), or multi-piece presets (form/card)
        // whose editable text lives on their own nested elements — all
        // skip Texto so editing "Contenido" can't accidentally wipe out
        // their structure.
        const showText = !["colorbox", "image", "divider", "form", "card", "label", "code"].includes(kind);

        const sections = [
            showText ? this.buildTextSection(el, rerender) : null,
            kind === "image" ? this.buildImageSection(el, rerender) : null,
            kind === "code" ? this.buildCustomCodeSection(el, rerender) : null,
            this.buildLayoutSection(el, rerender),
            this.buildResponsiveSection(el, rerender),
            this.buildSpacingSection(el, rerender),
            this.buildAppearanceSection(el, rerender),
            this.buildAnimationSection(el, rerender),
            this.buildLogicSection(el, rerender),
            this.buildAdvancedSection(el, rerender)
        ];

        sections.forEach(section => {

            if (section)
                this.container.appendChild(section);

        });

        // Re-wire the collapse/expand click handlers every time the panel
        // is rebuilt — not just on the initial selection — since internal
        // actions (mode switches, add border, add attribute...) rebuild
        // the whole panel via `rerender()` without going through
        // Inspector's "selectionChanged" listener.
        window.Inspector?.attachCollapsing();

    }

    /* =====================================================
       Generic building blocks
       ===================================================== */

    section(title, rows, { collapsed = false } = {}) {

        // A section the user has explicitly opened stays open across
        // re-renders, regardless of its default collapsed state.
        const actuallyCollapsed = this.expandedSections.has(title) ? false : collapsed;

        const section = document.createElement("div");

        section.className = "inspector-section" + (actuallyCollapsed ? " collapsed" : "");

        const header = document.createElement("div");

        header.className = "inspector-section-header";

        // Store the stable (untranslated) title as the section's identity
        // key — inspector.js's toggleSection/setSectionExpanded key off
        // this, not the displayed text, so collapse-state survives a
        // language switch instead of resetting.
        header.dataset.sectionKey = title;

        const titleSpan = document.createElement("span");

        titleSpan.textContent = t(title, title);

        const chevron = document.createElement("span");

        chevron.className = "chevron";

        chevron.textContent = "▾";

        header.appendChild(titleSpan);

        header.appendChild(chevron);

        section.appendChild(header);

        const body = document.createElement("div");

        body.className = "inspector-section-body";

        rows.forEach(r => {

            if (r)
                body.appendChild(r);

        });

        section.appendChild(body);

        return section;

    }

    // A small non-collapsible label used to separate sub-groups inside a
    // merged section (e.g. "Posición" inside "Diseño").
    subheading(text) {

        const div = document.createElement("div");

        div.className = "section-subheading";

        div.textContent = text ? t(text, text) : text;

        return div;

    }

    row(labelText, controlEl) {

        const row = document.createElement("div");

        row.className = "property-row";

        if (labelText) {

            const label = document.createElement("label");

            label.textContent = t(labelText, labelText);

            row.appendChild(label);

        }

        row.appendChild(controlEl);

        return row;

    }

    twoUp(rowA, rowB) {

        const wrap = document.createElement("div");

        wrap.className = "control-row";

        wrap.style.marginBottom = "8px";

        wrap.appendChild(rowA);

        wrap.appendChild(rowB);

        return wrap;

    }

    textInput(value, onChange) {

        const input = document.createElement("input");

        input.type = "text";

        input.value = value ?? "";

        input.addEventListener("input", () => onChange(input.value));

        return input;

    }

    numberWithUnit(value, unit, onChange, { min, max, step } = {}) {

        const wrap = document.createElement("div");

        wrap.className = "input-unit-wrap";

        const input = document.createElement("input");

        input.type = "number";

        if (min != null) input.min = min;
        if (max != null) input.max = max;
        if (step != null) input.step = step;

        input.value = value;

        input.addEventListener("input", () => {

            if (input.value === "")
                return;

            onChange(Number(input.value));

        });

        wrap.appendChild(input);

        if (unit) {

            const u = document.createElement("span");

            u.className = "unit";

            u.textContent = unit;

            wrap.appendChild(u);

        }

        return wrap;

    }

    colorInput(value, onChange) {

        const input = document.createElement("input");

        input.type = "color";

        input.value = Utils.rgbToHex(value || "#000000");

        input.addEventListener("input", () => onChange(input.value));

        return input;

    }

    // options: array of strings, or { value, label } pairs when the
    // internal value (used for comparisons/CSS) must stay in English while
    // the label shown to the user is translated.
    selectInput(options, value, onChange) {

        const select = document.createElement("select");

        options.forEach(opt => {

            const o = document.createElement("option");

            o.value = typeof opt === "string" ? opt : opt.value;

            o.textContent = typeof opt === "string" ? opt : (opt.labelKey ? t(opt.labelKey, opt.label) : t(opt.label, opt.label));

            if (o.value === value)
                o.selected = true;

            select.appendChild(o);

        });

        select.addEventListener("change", () => onChange(select.value));

        return select;

    }

    // Same value/label split as selectInput — segmented controls compare
    // and store the internal `value`, but display the translated `label`.
    segmented(options, value, onChange) {

        const wrap = document.createElement("div");

        wrap.className = "segmented-control";

        options.forEach(opt => {

            const optValue = typeof opt === "string" ? opt : opt.value;

            const optLabel = typeof opt === "string" ? opt : (opt.labelKey ? t(opt.labelKey, opt.label) : t(opt.label, opt.label));

            const btn = document.createElement("button");

            btn.type = "button";

            btn.textContent = optLabel;

            if (optValue === value)
                btn.classList.add("active");

            btn.addEventListener("click", () => onChange(optValue));

            wrap.appendChild(btn);

        });

        return wrap;

    }

    toggleGroup(options, onToggle) {

        // options: [{ label, active, onClick }]
        const wrap = document.createElement("div");

        wrap.className = "icon-toggle-group";

        options.forEach(opt => {

            const btn = document.createElement("button");

            btn.type = "button";

            btn.textContent = opt.label;

            if (opt.active)
                btn.classList.add("active");

            btn.addEventListener("click", () => {

                btn.classList.toggle("active");

                opt.onClick(btn.classList.contains("active"));

            });

            wrap.appendChild(btn);

        });

        return wrap;

    }

    /* Reads the inline style if present, otherwise the computed value */
    styleValue(el, prop) {

        return el.style[prop] || window.getComputedStyle(el)[prop];

    }

    px(value) {

        const n = parseFloat(value);

        return Number.isNaN(n) ? 0 : n;

    }

    /* =====================================================
       Texto
       ===================================================== */

    buildTextSection(el, rerender) {

        const rows = [];

        rows.push(this.row("Contenido", this.textInput(
            el.textContent,
            value => Selection.updateText(value)
        )));

        const fontOptions = [
            { value: "", label: "Predeterminada" },
            { value: "Inter, system-ui, sans-serif", label: "Sans (Inter)" },
            { value: "Georgia, serif", label: "Georgia" },
            { value: "'Times New Roman', serif", label: "Times New Roman" },
            { value: "'Courier New', monospace", label: "Courier New" },
            { value: "'SF Mono', Menlo, monospace", label: "SF Mono" },
            // Real Google Fonts — picking one loads the actual typeface
            // (needs internet), both here in the editor and in the
            // exported page. See fonts.js.
            ...(typeof GOOGLE_FONTS !== "undefined"
                ? GOOGLE_FONTS.map(f => ({ value: f.stack, label: f.name + " (Google)" }))
                : [])
        ];

        rows.push(this.row("Fuente", this.selectInput(
            fontOptions,
            el.style.fontFamily || "",
            value => {

                Selection.updateStyle("fontFamily", value);

                window.Fonts?.ensureLoaded(value);

            }
        )));

        const sizeRow = this.row("Tamaño", this.numberWithUnit(
            this.px(this.styleValue(el, "fontSize")),
            "px",
            value => Selection.updateStyle("fontSize", value + "px"),
            { min: 0 }
        ));

        const colorRow = this.row("Color", this.colorInput(
            this.styleValue(el, "color"),
            value => Selection.updateStyle("color", value)
        ));

        rows.push(this.twoUp(sizeRow, colorRow));

        rows.push(this.row("Peso", this.selectInput(
            [
                { value: "300", label: "Ligera" },
                { value: "400", label: "Regular" },
                { value: "500", label: "Media" },
                { value: "600", label: "Seminegrita" },
                { value: "700", label: "Negrita" },
                { value: "900", label: "Negra" }
            ],
            String(this.styleValue(el, "fontWeight") || "400").replace("normal", "400").replace("bold", "700"),
            value => Selection.updateStyle("fontWeight", value)
        )));

        const decoration = this.styleValue(el, "textDecorationLine") || "none";

        rows.push(this.row("Estilo", this.toggleGroup([
            {
                label: "N",
                active: Number(this.styleValue(el, "fontWeight")) >= 700 || this.styleValue(el, "fontWeight") === "bold",
                onClick: active => Selection.updateStyle("fontWeight", active ? "700" : "400")
            },
            {
                label: "K",
                active: this.styleValue(el, "fontStyle") === "italic",
                onClick: active => Selection.updateStyle("fontStyle", active ? "italic" : "normal")
            },
            {
                label: "S",
                active: decoration.includes("underline"),
                onClick: active => {

                    const hasStrike = decoration.includes("line-through");

                    const next = [active && "underline", hasStrike && "line-through"].filter(Boolean).join(" ") || "none";

                    Selection.updateStyle("textDecoration", next);

                }
            },
            {
                label: "T",
                active: decoration.includes("line-through"),
                onClick: active => {

                    const hasUnderline = decoration.includes("underline");

                    const next = [hasUnderline && "underline", active && "line-through"].filter(Boolean).join(" ") || "none";

                    Selection.updateStyle("textDecoration", next);

                }
            }
        ])));

        const align = this.styleValue(el, "textAlign") || "left";

        rows.push(this.row("Alineación", this.toggleGroup([
            { label: "≡I", active: align === "left" || align === "start", onClick: () => Selection.updateStyle("textAlign", "left") },
            { label: "≡C", active: align === "center", onClick: () => Selection.updateStyle("textAlign", "center") },
            { label: "≡D", active: align === "right" || align === "end", onClick: () => Selection.updateStyle("textAlign", "right") },
            { label: "≡J", active: align === "justify", onClick: () => Selection.updateStyle("textAlign", "justify") }
        ])));

        rows.push(this.row("Interlineado", this.numberWithUnit(
            parseFloat(this.styleValue(el, "lineHeight")) || 1.4,
            "",
            value => Selection.updateStyle("lineHeight", String(value)),
            { step: 0.05, min: 0 }
        )));

        rows.push(this.row("Mayúsculas", this.selectInput(
            [
                { value: "none", label: "Ninguna" },
                { value: "uppercase", label: "MAYÚSCULAS" },
                { value: "lowercase", label: "minúsculas" },
                { value: "capitalize", label: "Iniciales" }
            ],
            this.styleValue(el, "textTransform") || "none",
            value => Selection.updateStyle("textTransform", value)
        )));

        return this.section("Texto", rows);

    }

    /* =====================================================
       Imagen — reemplaza a Texto para elementos <img>
       ===================================================== */

    composeImageFilter(type, intensity) {

        if (type === "grayscale") return `grayscale(${intensity}%)`;
        if (type === "contrast") return `contrast(${100 + intensity}%)`;
        if (type === "saturate") return `saturate(${100 + intensity * 2}%)`;
        if (type === "sepia") return `sepia(${intensity}%)`;
        if (type === "brightness-down") return `brightness(${100 - intensity}%)`;

        return "";

    }

    // Every filter type is generated only by composeImageFilter() above,
    // so reversing it back to { type, intensity } is unambiguous.
    parseImageFilter(filterStr) {

        let m;

        if ((m = filterStr.match(/^grayscale\((\d+)%\)$/))) return { type: "grayscale", intensity: Number(m[1]) };
        if ((m = filterStr.match(/^contrast\((\d+)%\)$/))) return { type: "contrast", intensity: Number(m[1]) - 100 };
        if ((m = filterStr.match(/^saturate\((\d+)%\)$/))) return { type: "saturate", intensity: (Number(m[1]) - 100) / 2 };
        if ((m = filterStr.match(/^sepia\((\d+)%\)$/))) return { type: "sepia", intensity: Number(m[1]) };
        if ((m = filterStr.match(/^brightness\((\d+)%\)$/))) return { type: "brightness-down", intensity: 100 - Number(m[1]) };

        return { type: "none", intensity: 50 };

    }

    buildImageFilterRows(el, rerender) {

        const current = this.parseImageFilter(el.style.filter || "");

        const rows = [];

        rows.push(this.row("Filtro", this.selectInput(
            [
                { value: "none", label: "Ninguno" },
                { value: "grayscale", label: "Blanco y negro" },
                { value: "contrast", label: "Alto contraste" },
                { value: "saturate", label: "Saturado" },
                { value: "sepia", label: "Sepia" },
                { value: "brightness-down", label: "Oscurecer" }
            ],
            current.type,
            next => {

                Selection.updateStyle("filter", next === "none" ? "" : this.composeImageFilter(next, 50));

                rerender();

            }
        )));

        if (current.type !== "none") {

            rows.push(this.row("Intensidad", this.numberWithUnit(
                current.intensity,
                "%",
                v => Selection.updateStyle("filter", this.composeImageFilter(current.type, v)),
                { min: 0, max: 100 }
            )));

        }

        return rows;

    }

    buildImageSection(el, rerender) {

        const rows = [];

        const src = el.getAttribute("src") || "";

        const isLocalFile = src.startsWith("data:");

        if (src) {

            const preview = document.createElement("img");

            preview.src = src;

            preview.style.cssText =
                "width:100%; max-height:120px; object-fit:contain; border-radius:6px; " +
                "background:var(--bg-app); margin-bottom:8px; display:block;";

            rows.push(preview);

        }

        // Upload from disk — reads the file locally as a data URI, so the
        // image ends up embedded directly in the page (no broken links,
        // works from the exported single HTML file too).
        const uploadBtn = document.createElement("button");

        uploadBtn.type = "button";

        uploadBtn.className = "section-action-btn";

        uploadBtn.textContent = t("Subir imagen desde tu ordenador");

        const fileInput = document.createElement("input");

        fileInput.type = "file";

        fileInput.accept = "image/*";

        fileInput.style.display = "none";

        uploadBtn.addEventListener("click", () => fileInput.click());

        fileInput.addEventListener("change", () => {

            const file = fileInput.files?.[0];

            if (!file)
                return;

            const reader = new FileReader();

            reader.onload = () => {

                Selection.updateAttribute("src", reader.result);

                // Fill in real alt text from the filename, unless the user
                // already wrote something other than the generic preset
                // placeholder (t("Imagen") — "Image"/"Imagen" depending on
                // the language active when the element was inserted).
                const currentAlt = el.getAttribute("alt");

                if (!currentAlt || currentAlt === t("Imagen"))
                    Selection.updateAttribute("alt", file.name.replace(/\.[^.]+$/, ""));

                rerender();

            };

            reader.readAsDataURL(file);

        });

        rows.push(uploadBtn);

        rows.push(fileInput);

        const cropBtn = document.createElement("button");

        cropBtn.type = "button";

        cropBtn.className = "section-action-btn";

        cropBtn.textContent = t("Recortar");

        cropBtn.disabled = !src;

        cropBtn.addEventListener("click", () => window.ImageCrop?.open(el));

        rows.push(cropBtn);

        if (isLocalFile) {

            const hint = document.createElement("div");

            hint.className = "modal-subtitle";

            hint.style.margin = "8px 0 0";

            hint.textContent = t("Imagen subida desde tu ordenador. Pega una URL abajo si prefieres usar una externa.");

            rows.push(hint);

        }

        rows.push(this.row("Origen (URL)", this.textInput(
            isLocalFile ? "" : src,
            value => Selection.updateAttribute("src", value)
        )));

        rows.push(this.row("Texto alternativo", this.textInput(
            el.getAttribute("alt") || "",
            value => Selection.updateAttribute("alt", value)
        )));

        rows.push(this.row("Ajuste", this.selectInput(
            [
                { value: "cover", label: "Cubrir (recortar)" },
                { value: "contain", label: "Contener (sin recortar)" },
                { value: "fill", label: "Rellenar (deformar)" },
                { value: "none", label: "Tamaño original" }
            ],
            this.styleValue(el, "objectFit") || "cover",
            value => Selection.updateStyle("objectFit", value)
        )));

        rows.push(this.subheading("Filtro"));

        rows.push(...this.buildImageFilterRows(el, rerender));

        rows.push(this.subheading("Desvanecido"));

        rows.push(...this.buildImageFadeRows(el, rerender));

        return this.section("Imagen", rows);

    }

    /* =====================================================
       Código — raw HTML/CSS/JS escape hatch (see customCode.js).
       ===================================================== */

    codeTextarea(value, onChange) {

        const textarea = document.createElement("textarea");

        // Reuses the monospace textarea styling introduced for the Logic
        // "call-api" action's Body field — same idea (a code-ish free-text
        // field), no need for a second CSS rule.
        textarea.className = "logic-body-input";

        textarea.rows = 4;

        textarea.value = value || "";

        textarea.addEventListener("input", () => onChange(textarea.value));

        return textarea;

    }

    buildCustomCodeSection(el, rerender) {

        const rows = [];

        const data = window.CustomCode ? window.CustomCode.ensureData(el) : { html: "", css: "", js: "" };

        rows.push(this.row("HTML", this.codeTextarea(
            data.html,
            v => window.CustomCode?.updateField(el, "html", v)
        )));

        rows.push(this.row("CSS", this.codeTextarea(
            data.css,
            v => window.CustomCode?.updateField(el, "css", v)
        )));

        rows.push(this.row("JavaScript", this.codeTextarea(
            data.js,
            v => window.CustomCode?.updateField(el, "js", v)
        )));

        const hint = document.createElement("div");

        hint.className = "modal-subtitle";

        hint.textContent = t("El HTML y el CSS se ven aquí mismo en el lienzo. El JavaScript nunca se ejecuta mientras editas — solo al exportar o previsualizar la página.");

        rows.push(hint);

        return this.section("Código", rows);

    }

    // A gradient alpha mask over the image itself — makes the photo fade
    // to transparent toward an edge or a point, so the page background
    // shows through smoothly. A plain background gradient can't do this
    // for an <img>, since its bitmap always paints on top of its own
    // background.
    buildImageFadeRows(el, rerender) {

        const maskImage = el.style.maskImage || el.style.webkitMaskImage || "";

        const hasFade = /gradient/.test(maskImage);

        const rows = [];

        rows.push(this.row("Desvanecido", this.segmented(
            [
                { value: "off", label: "Ninguno" },
                { value: "on", label: "Activado" }
            ],
            hasFade ? "on" : "off",
            next => {

                if (next === "on") {

                    const value = "linear-gradient(to right, black 60%, transparent 100%)";

                    Selection.updateStyle("maskImage", value);

                    Selection.updateStyle("webkitMaskImage", value);

                } else {

                    Selection.updateStyle("maskImage", "");

                    Selection.updateStyle("webkitMaskImage", "");

                }

                rerender();

            }
        )));

        if (hasFade) {

            const isRadial = maskImage.startsWith("radial-gradient");

            const dirMatch = maskImage.match(/to (right|left|top|bottom)/);

            const direction = dirMatch ? dirMatch[1] : "right";

            const startMatch = maskImage.match(/(\d+)%/);

            const start = startMatch ? Number(startMatch[1]) : 60;

            const compose = (radial, dir, startPct) => radial
                ? `radial-gradient(circle, black ${startPct}%, transparent 100%)`
                : `linear-gradient(to ${dir}, black ${startPct}%, transparent 100%)`;

            const applyMask = (radial, dir, startPct) => {

                const value = compose(radial, dir, startPct);

                Selection.updateStyle("maskImage", value);

                Selection.updateStyle("webkitMaskImage", value);

            };

            rows.push(this.row("Forma", this.segmented(
                [
                    { value: "Linear", label: "Hacia un lado" },
                    { value: "Radial", label: "Hacia un punto" }
                ],
                isRadial ? "Radial" : "Linear",
                next => {

                    applyMask(next === "Radial", direction, start);

                    rerender();

                }
            )));

            if (!isRadial) {

                rows.push(this.row("Dirección", this.selectInput(
                    [
                        { value: "right", label: "Se desvanece hacia la derecha" },
                        { value: "left", label: "Se desvanece hacia la izquierda" },
                        { value: "bottom", label: "Se desvanece hacia abajo" },
                        { value: "top", label: "Se desvanece hacia arriba" }
                    ],
                    direction,
                    next => applyMask(false, next, start)
                )));

            }

            rows.push(this.row("Empieza a desvanecerse", this.numberWithUnit(
                start,
                "%",
                v => applyMask(isRadial, direction, v),
                { min: 0, max: 100 }
            )));

        }

        return rows;

    }

    /* =====================================================
       Diseño — tamaño + posición + distribución de contenido
       ===================================================== */

    sizeMode(el, prop) {

        const value = el.style[prop];

        if (value === "100%")
            return "Fill";

        if (!value || value === "auto" || value === "fit-content")
            return "Hug";

        return "Fixed";

    }

    buildSizeRow(el, prop, label, rerender) {

        const mode = this.sizeMode(el, prop);

        const rows = [];

        rows.push(this.row(label, this.segmented(
            [
                { value: "Hug", label: "Ajustar" },
                { value: "Fixed", label: "Fijo" },
                { value: "Fill", label: "Rellenar" }
            ],
            mode,
            next => {

                if (next === "Hug")
                    Selection.updateStyle(prop, "fit-content");

                else if (next === "Fill")
                    Selection.updateStyle(prop, "100%");

                else
                    Selection.updateStyle(prop, el.getBoundingClientRect()[prop] + "px");

                rerender();

            }
        )));

        if (mode === "Fixed") {

            rows.push(this.row("", this.numberWithUnit(
                this.px(el.style[prop]),
                "px",
                value => Selection.updateStyle(prop, value + "px"),
                { min: 0 }
            )));

        }

        return rows;

    }

    buildPositionRows(el, rerender) {

        const currentValue = this.styleValue(el, "position") || "static";

        const currentLabel = RENDERER_POSITION_VALUE_TO_LABEL[currentValue] || "Inline";

        const rows = [];

        rows.push(this.row("Posición", this.segmented(
            [
                { value: "Inline", label: "En línea" },
                { value: "Absolute", label: "Absoluta" },
                { value: "Fixed", label: "Fija" },
                { value: "Sticky", label: "Pegajosa" }
            ],
            currentLabel,
            next => {

                Selection.updateStyle("position", RENDERER_POSITION_LABEL_TO_VALUE[next]);

                rerender();

            }
        )));

        if (currentLabel === "Absolute" || currentLabel === "Fixed") {

            const topRow = this.row("Arriba", this.numberWithUnit(
                this.px(el.style.top), "px",
                v => Selection.updateStyle("top", v + "px")
            ));

            const leftRow = this.row("Izquierda", this.numberWithUnit(
                this.px(el.style.left), "px",
                v => Selection.updateStyle("left", v + "px")
            ));

            const rightRow = this.row("Derecha", this.numberWithUnit(
                this.px(el.style.right), "px",
                v => Selection.updateStyle("right", v + "px")
            ));

            const bottomRow = this.row("Abajo", this.numberWithUnit(
                this.px(el.style.bottom), "px",
                v => Selection.updateStyle("bottom", v + "px")
            ));

            rows.push(this.twoUp(topRow, leftRow));

            rows.push(this.twoUp(rightRow, bottomRow));

            const hint = document.createElement("div");

            hint.className = "modal-subtitle";

            hint.style.margin = "4px 0 0";

            hint.textContent = currentLabel === "Fixed"
                ? t("Fija se posiciona respecto a la ventana del navegador, no al lienzo — puede que aquí se vea distinto que al exportar. También puedes arrastrarla directamente.")
                : t("También puedes arrastrar el elemento directamente en el lienzo.");

            rows.push(hint);

        } else if (currentLabel === "Sticky") {

            rows.push(this.row("Desde arriba (al hacer scroll)", this.numberWithUnit(
                this.px(el.style.top) || 0, "px",
                v => Selection.updateStyle("top", v + "px")
            )));

            const hint = document.createElement("div");

            hint.className = "modal-subtitle";

            hint.style.margin = "4px 0 0";

            hint.textContent = t("Se comporta como en línea hasta que el scroll llega a esa distancia del borde superior, y entonces se queda fija ahí.");

            rows.push(hint);

        }

        return rows;

    }

    buildContentsLayoutRows(el, rerender) {

        const isGrid = this.styleValue(el, "display") === "grid";

        const rows = [];

        rows.push(this.row("Modo", this.segmented(
            [
                { value: "Flex", label: "Flex" },
                { value: "Grid", label: "Cuadrícula (Grid)" }
            ],
            isGrid ? "Grid" : "Flex",
            next => {

                Selection.updateStyle("display", next === "Grid" ? "grid" : "flex");

                rerender();

            }
        )));

        if (isGrid)
            rows.push(...this.buildGridContentRows(el, rerender));
        else
            rows.push(...this.buildFlexContentRows(el, rerender));

        return rows;

    }

    // CSS Grid mode — deliberately a small, practical subset rather than
    // the full spec (no named template areas, no explicit row tracks):
    // a column count (compiles to grid-template-columns: repeat(N, 1fr)),
    // letting rows generate automatically sized to content, which covers
    // the overwhelming majority of real "grid of cards/images" use cases
    // without asking a non-technical user to write track syntax by hand.
    // Per-item column/row spans live on each child instead — see
    // buildGridItemRows().
    buildGridContentRows(el, rerender) {

        const rows = [];

        const columnsMatch = /repeat\((\d+)/.exec(this.styleValue(el, "gridTemplateColumns") || "");

        const columns = columnsMatch ? parseInt(columnsMatch[1], 10) : 2;

        rows.push(this.row("Columnas", this.numberWithUnit(
            columns, "",
            v => Selection.updateStyle("gridTemplateColumns", `repeat(${Math.max(1, Math.round(v))}, 1fr)`),
            { min: 1, step: 1 }
        )));

        rows.push(this.row("Espacio", this.numberWithUnit(
            this.px(this.styleValue(el, "gap")),
            "px",
            v => Selection.updateStyle("gap", v + "px"),
            { min: 0 }
        )));

        rows.push(this.row("Alinear elementos", this.selectInput(
            [
                { value: "stretch", label: "Estirar" },
                { value: "start", label: "Inicio" },
                { value: "center", label: "Centro" },
                { value: "end", label: "Final" }
            ],
            this.styleValue(el, "alignItems") || "stretch",
            v => Selection.updateStyle("alignItems", v)
        )));

        rows.push(this.row("Justificar elementos", this.selectInput(
            [
                { value: "stretch", label: "Estirar" },
                { value: "start", label: "Inicio" },
                { value: "center", label: "Centro" },
                { value: "end", label: "Final" }
            ],
            this.styleValue(el, "justifyItems") || "stretch",
            v => Selection.updateStyle("justifyItems", v)
        )));

        const hint = document.createElement("div");

        hint.className = "modal-subtitle";

        hint.textContent = t("Las filas se crean automáticamente según haga falta. Para que un elemento ocupe varias columnas o filas, selecciónalo y usa \"Posición en la cuadrícula\" en su propia sección Diseño.");

        rows.push(hint);

        return rows;

    }

    buildFlexContentRows(el, rerender) {

        // flexDirection carries both the axis (row/column) and, appending
        // "-reverse", which end of that axis content starts from — that
        // second bit is exposed as its own "Reverse order" toggle below,
        // so the two together give all 4 arrangements (left/right/top/
        // bottom) a "Label" preset (image + text) or any other flex
        // container needs, e.g. to put the text on either side of an
        // image, or above/below it.
        const direction = this.styleValue(el, "flexDirection") || "row";

        const isColumn = direction.startsWith("column");

        const isReversed = direction.endsWith("-reverse");

        const composeDirection = (column, reversed) =>
            (column ? "column" : "row") + (reversed ? "-reverse" : "");

        const rows = [];

        rows.push(this.row("Dirección", this.segmented(
            [
                { value: "Row", label: "Fila" },
                { value: "Column", label: "Columna" }
            ],
            isColumn ? "Column" : "Row",
            next => {

                Selection.updateStyle("display", "flex");

                Selection.updateStyle("flexDirection", composeDirection(next === "Column", isReversed));

                rerender();

            }
        )));

        const reverseCheckbox = document.createElement("input");

        reverseCheckbox.type = "checkbox";

        reverseCheckbox.checked = isReversed;

        reverseCheckbox.addEventListener("change", () => {

            Selection.updateStyle("flexDirection", composeDirection(isColumn, reverseCheckbox.checked));

        });

        rows.push(this.row("Invertir orden", reverseCheckbox));

        rows.push(this.row("Espacio", this.numberWithUnit(
            this.px(this.styleValue(el, "gap")),
            "px",
            v => Selection.updateStyle("gap", v + "px"),
            { min: 0 }
        )));

        rows.push(this.row("Alinear elementos", this.selectInput(
            [
                { value: "flex-start", label: "Inicio" },
                { value: "center", label: "Centro" },
                { value: "flex-end", label: "Final" },
                { value: "stretch", label: "Estirar" }
            ],
            this.styleValue(el, "alignItems") || "flex-start",
            v => Selection.updateStyle("alignItems", v)
        )));

        rows.push(this.row("Justificar contenido", this.selectInput(
            [
                { value: "flex-start", label: "Inicio" },
                { value: "center", label: "Centro" },
                { value: "flex-end", label: "Final" },
                { value: "space-between", label: "Espacio entre" },
                { value: "space-around", label: "Espacio alrededor" }
            ],
            this.styleValue(el, "justifyContent") || "flex-start",
            v => Selection.updateStyle("justifyContent", v)
        )));

        return rows;

    }

    // Grid-item placement (column/row span) — belongs to the *child*, not
    // the grid container, since CSS grid placement is a property of each
    // item. Shown on every element regardless of its parent, same as the
    // rest of Layout's controls; it's a no-op unless the parent happens to
    // be in Grid mode, which the hint below explains.
    parseGridSpan(value) {

        const m = /span\s+(\d+)/.exec(value || "");

        return m ? parseInt(m[1], 10) : 1;

    }

    buildGridItemRows(el, rerender) {

        const rows = [];

        const colRow = this.row("Columnas que ocupa", this.numberWithUnit(
            this.parseGridSpan(el.style.gridColumn), "",
            v => {

                const n = Math.max(1, Math.round(v));

                Selection.updateStyle("gridColumn", n <= 1 ? "" : `span ${n}`);

            },
            { min: 1, step: 1 }
        ));

        const rowRow = this.row("Filas que ocupa", this.numberWithUnit(
            this.parseGridSpan(el.style.gridRow), "",
            v => {

                const n = Math.max(1, Math.round(v));

                Selection.updateStyle("gridRow", n <= 1 ? "" : `span ${n}`);

            },
            { min: 1, step: 1 }
        ));

        rows.push(this.twoUp(colRow, rowRow));

        const hint = document.createElement("div");

        hint.className = "modal-subtitle";

        hint.textContent = t("Solo tiene efecto si el elemento contenedor (el padre) está en modo Cuadrícula (Grid).");

        rows.push(hint);

        return rows;

    }

    buildLayoutSection(el, rerender) {

        const rows = [];

        rows.push(this.subheading("Tamaño"));

        rows.push(...this.buildSizeRow(el, "width", "Ancho", rerender));

        rows.push(...this.buildSizeRow(el, "height", "Alto", rerender));

        rows.push(this.subheading("Posición"));

        rows.push(...this.buildPositionRows(el, rerender));

        rows.push(this.subheading("Distribución de contenido"));

        rows.push(...this.buildContentsLayoutRows(el, rerender));

        rows.push(this.subheading("Posición en la cuadrícula (como hijo)"));

        rows.push(...this.buildGridItemRows(el, rerender));

        return this.section("Diseño", rows, { collapsed: true });

    }

    /* =====================================================
       Responsive — per-breakpoint overrides (see responsive.js).
       Only editable while a non-Desktop breakpoint is selected in the
       top bar; on Desktop this section just explains that.
       ===================================================== */

    buildResponsiveSection(el, rerender) {

        const bp = window.Responsive?.current || "desktop";

        const rows = [];

        if (bp === "desktop") {

            const hint = document.createElement("div");

            hint.className = "modal-subtitle";

            hint.textContent = t("Elige Tablet o Móvil arriba para anular estilos solo en ese tamaño.");

            rows.push(hint);

            return this.section("Responsive", rows, { collapsed: true });

        }

        const data = window.Responsive.getData(el);

        const overrides = data?.[bp] || {};

        const hideCheckbox = document.createElement("input");

        hideCheckbox.type = "checkbox";

        hideCheckbox.checked = overrides.display === "none";

        hideCheckbox.addEventListener("change", () => {

            if (hideCheckbox.checked)
                window.Responsive.updateProperty(el, "display", "none");

            else
                window.Responsive.removeProperty(el, "display");

            rerender();

        });

        rows.push(this.row("Ocultar en este tamaño", hideCheckbox));

        const stackCheckbox = document.createElement("input");

        stackCheckbox.type = "checkbox";

        stackCheckbox.checked = overrides.flexDirection === "column";

        stackCheckbox.addEventListener("change", () => {

            if (stackCheckbox.checked)
                window.Responsive.updateProperty(el, "flexDirection", "column");

            else
                window.Responsive.removeProperty(el, "flexDirection");

            rerender();

        });

        rows.push(this.row("Apilar verticalmente", stackCheckbox));

        rows.push(...this.buildResponsiveOverrideRow(
            el, rerender, overrides, "width", "Ancho en este tamaño",
            "+ Anular ancho en este tamaño", "Quitar anulación de ancho",
            "100%", v => v + "px"
        ));

        rows.push(...this.buildResponsiveOverrideRow(
            el, rerender, overrides, "fontSize", "Tamaño de texto en este tamaño",
            "+ Anular tamaño de texto en este tamaño", "Quitar anulación de tamaño de texto",
            "14px", v => v + "px"
        ));

        return this.section("Responsive", rows, { collapsed: false });

    }

    // Shared "+ Add override" / "value field + Remove" pattern for the
    // two numeric responsive overrides (width, font size) — same
    // add/remove convention as buildHoverRows and buildShadowRows.
    buildResponsiveOverrideRow(el, rerender, overrides, prop, label, addLabel, removeLabel, defaultValue, format) {

        const rows = [];

        if (overrides[prop] !== undefined) {

            rows.push(this.row(label, this.numberWithUnit(
                parseFloat(overrides[prop]) || 0,
                "px",
                v => window.Responsive.updateProperty(el, prop, format(v)),
                { min: 0 }
            )));

            const removeBtn = document.createElement("button");

            removeBtn.type = "button";

            removeBtn.className = "add-link";

            removeBtn.textContent = t(removeLabel);

            removeBtn.addEventListener("click", () => {

                window.Responsive.removeProperty(el, prop);

                rerender();

            });

            rows.push(removeBtn);

        } else {

            const addBtn = document.createElement("button");

            addBtn.type = "button";

            addBtn.className = "section-action-btn";

            addBtn.textContent = t(addLabel);

            addBtn.addEventListener("click", () => {

                window.Responsive.updateProperty(el, prop, defaultValue);

                rerender();

            });

            rows.push(addBtn);

        }

        return rows;

    }

    /* =====================================================
       Espaciado — relleno (padding) + margen
       ===================================================== */

    spacingMode(el, prop) {

        // Prefer the mode the user explicitly picked — value-based inference
        // is ambiguous (e.g. 0/0/0/0 could be "Ninguno" o "Todos" con valor 0).
        const override = this.spacingModes.get(el)?.[prop];

        if (override)
            return override;

        const t = this.px(el.style[prop + "Top"]);
        const r = this.px(el.style[prop + "Right"]);
        const b = this.px(el.style[prop + "Bottom"]);
        const l = this.px(el.style[prop + "Left"]);

        if (t === 0 && r === 0 && b === 0 && l === 0)
            return "None";

        if (t === r && r === b && b === l)
            return "All";

        if (t === b && l === r)
            return "X & Y";

        return "Individual";

    }

    setSpacingMode(el, prop, mode) {

        const existing = this.spacingModes.get(el) || {};

        existing[prop] = mode;

        this.spacingModes.set(el, existing);

    }

    setSpacing(prop, sides) {

        Object.entries(sides).forEach(([side, value]) => {

            Selection.updateStyle(prop + side, value + "px");

        });

    }

    buildSpacingRows(el, rerender, prop) {

        const mode = this.spacingMode(el, prop);

        const rows = [];

        rows.push(this.row("Modo", this.segmented(
            [
                { value: "None", label: "Ninguno" },
                { value: "All", label: "Todos" },
                { value: "X & Y", label: "X e Y" },
                { value: "Individual", label: "Individual" }
            ],
            mode,
            next => {

                this.setSpacingMode(el, prop, next);

                if (next === "None")
                    this.setSpacing(prop, { Top: 0, Right: 0, Bottom: 0, Left: 0 });

                else if (next === "All") {

                    const v = this.px(el.style[prop + "Top"]) || 0;

                    this.setSpacing(prop, { Top: v, Right: v, Bottom: v, Left: v });

                }

                rerender();

            }
        )));

        if (mode === "All") {

            rows.push(this.row("Todos los lados", this.numberWithUnit(
                this.px(el.style[prop + "Top"]), "px",
                v => this.setSpacing(prop, { Top: v, Right: v, Bottom: v, Left: v }),
                { min: 0 }
            )));

        } else if (mode === "X & Y") {

            const xRow = this.row("Horizontal", this.numberWithUnit(
                this.px(el.style[prop + "Left"]), "px",
                v => this.setSpacing(prop, { Left: v, Right: v }),
                { min: 0 }
            ));

            const yRow = this.row("Vertical", this.numberWithUnit(
                this.px(el.style[prop + "Top"]), "px",
                v => this.setSpacing(prop, { Top: v, Bottom: v }),
                { min: 0 }
            ));

            rows.push(this.twoUp(xRow, yRow));

        } else if (mode === "Individual") {

            const topRow = this.row("Arriba", this.numberWithUnit(
                this.px(el.style[prop + "Top"]), "px",
                v => this.setSpacing(prop, { Top: v }), { min: 0 }
            ));

            const rightRow = this.row("Derecha", this.numberWithUnit(
                this.px(el.style[prop + "Right"]), "px",
                v => this.setSpacing(prop, { Right: v }), { min: 0 }
            ));

            const bottomRow = this.row("Abajo", this.numberWithUnit(
                this.px(el.style[prop + "Bottom"]), "px",
                v => this.setSpacing(prop, { Bottom: v }), { min: 0 }
            ));

            const leftRow = this.row("Izquierda", this.numberWithUnit(
                this.px(el.style[prop + "Left"]), "px",
                v => this.setSpacing(prop, { Left: v }), { min: 0 }
            ));

            rows.push(this.twoUp(topRow, rightRow));

            rows.push(this.twoUp(bottomRow, leftRow));

        }

        return rows;

    }

    buildSpacingSection(el, rerender) {

        const rows = [];

        rows.push(this.subheading("Relleno (padding)"));

        rows.push(...this.buildSpacingRows(el, rerender, "padding"));

        rows.push(this.subheading("Margen"));

        rows.push(...this.buildSpacingRows(el, rerender, "margin"));

        return this.section("Espaciado", rows, { collapsed: true });

    }

    /* =====================================================
       Apariencia — fondo/radio/opacidad + borde
       ===================================================== */

    // Fondo sólido, o degradado (lineal/radial) — the gradient string is
    // always generated by this same code (never freeform user text), so
    // it can be reliably parsed back out of backgroundImage every render.
    // Background patterns (data-bg-pattern is the source of truth, same
    // approach as shadow layers) — backgroundImage/backgroundSize are
    // always fully re-derived from it, never parsed back out of CSS.
    getBgPattern(el) {

        try {

            return JSON.parse(el.getAttribute("data-bg-pattern") || "null");

        } catch (e) {

            return null;

        }

    }

    composeBgPattern(type, color, size) {

        if (type === "stripes")
            return { image: `repeating-linear-gradient(45deg, ${color} 0 2px, transparent 2px ${size}px)`, size: "" };

        if (type === "dots")
            return { image: `radial-gradient(${color} 1.5px, transparent 1.5px)`, size: `${size}px ${size}px` };

        if (type === "grid")
            return { image: `linear-gradient(${color} 1px, transparent 1px), linear-gradient(90deg, ${color} 1px, transparent 1px)`, size: `${size}px ${size}px` };

        return { image: "", size: "" };

    }

    saveBgPattern(el, pattern) {

        window.History?.snapshot();

        if (pattern) {

            el.setAttribute("data-bg-pattern", JSON.stringify(pattern));

            const { image, size } = this.composeBgPattern(pattern.type, pattern.color, pattern.size);

            el.style.backgroundImage = image;

            el.style.backgroundSize = size;

        } else {

            el.removeAttribute("data-bg-pattern");

            el.style.backgroundImage = "";

            el.style.backgroundSize = "";

        }

    }

    buildFondoRows(el, rerender) {

        const bgImage = el.style.backgroundImage || "";

        const pattern = this.getBgPattern(el);

        const isPattern = !!pattern;

        const isGradient = !isPattern && /^(linear|radial)-gradient/.test(bgImage);

        const bgType = isPattern ? "Pattern" : (isGradient ? "Gradient" : "Solid");

        const rows = [];

        rows.push(this.row("Tipo de fondo", this.segmented(
            [
                { value: "Solid", label: "Sólido" },
                { value: "Gradient", label: "Degradado" },
                { value: "Pattern", label: "Patrón" }
            ],
            bgType,
            next => {

                if (next === "Gradient") {

                    this.saveBgPattern(el, null);

                    const base = Utils.rgbToHex(this.styleValue(el, "backgroundColor") || "#B4A996");

                    Selection.updateStyle("backgroundImage", `linear-gradient(135deg, ${base}, #2A2A2A)`);

                } else if (next === "Pattern") {

                    this.saveBgPattern(el, { type: "dots", color: "#B4A996", size: 16 });

                } else {

                    this.saveBgPattern(el, null);

                    Selection.updateStyle("backgroundImage", "");

                }

                rerender();

            }
        )));

        if (isPattern) {

            rows.push(this.row("Estilo", this.selectInput(
                [
                    { value: "stripes", label: "Rayas diagonales" },
                    { value: "dots", label: "Puntos" },
                    { value: "grid", label: "Cuadrícula" }
                ],
                pattern.type,
                next => this.saveBgPattern(el, { ...pattern, type: next })
            )));

            rows.push(this.row("Color del patrón", this.colorInput(
                pattern.color,
                v => this.saveBgPattern(el, { ...pattern, color: v })
            )));

            rows.push(this.row("Tamaño", this.numberWithUnit(
                pattern.size,
                "px",
                v => this.saveBgPattern(el, { ...pattern, size: v }),
                { min: 4, max: 80 }
            )));

            rows.push(this.row("Color de fondo", this.colorInput(
                this.styleValue(el, "backgroundColor") || "#1A1A1A",
                v => Selection.updateStyle("backgroundColor", v)
            )));

        } else if (!isGradient) {

            rows.push(this.row("Color", this.colorInput(
                this.styleValue(el, "backgroundColor"),
                v => Selection.updateStyle("backgroundColor", v)
            )));

        } else {

            const isRadial = bgImage.startsWith("radial-gradient");

            // The browser normalizes any color we write (hex, rgb...) to
            // rgb()/rgba() when serializing style.backgroundImage back —
            // so parsing must accept either form and always re-hex it for
            // the <input type="color"> fields, which only accept hex.
            const colorTokens = bgImage.match(/#[0-9a-fA-F]{6}|rgba?\([^)]+\)/g) || [];

            const colors = (colorTokens.length >= 2 ? colorTokens : ["#B4A996", "#2A2A2A"]).map(c => Utils.rgbToHex(c));

            const angleMatch = bgImage.match(/linear-gradient\((\d+)deg/);

            const angle = angleMatch ? Number(angleMatch[1]) : 135;

            const compose = (type, ang, c1, c2) => type === "Radial"
                ? `radial-gradient(circle, ${c1}, ${c2})`
                : `linear-gradient(${ang}deg, ${c1}, ${c2})`;

            rows.push(this.row("Forma", this.segmented(
                [
                    { value: "Linear", label: "Lineal" },
                    { value: "Radial", label: "Radial" }
                ],
                isRadial ? "Radial" : "Linear",
                next => {

                    Selection.updateStyle("backgroundImage", compose(next, angle, colors[0], colors[1]));

                    rerender();

                }
            )));

            if (!isRadial) {

                rows.push(this.row("Ángulo", this.selectInput(
                    [
                        { value: "180", label: "Arriba → Abajo" },
                        { value: "90", label: "Izquierda → Derecha" },
                        { value: "135", label: "Diagonal ↘" },
                        { value: "0", label: "Abajo → Arriba" },
                        { value: "270", label: "Derecha → Izquierda" }
                    ],
                    String(angle),
                    next => Selection.updateStyle("backgroundImage", compose("Linear", Number(next), colors[0], colors[1]))
                )));

            }

            const c1Row = this.row("Color 1", this.colorInput(
                colors[0],
                v => Selection.updateStyle("backgroundImage", compose(isRadial ? "Radial" : "Linear", angle, v, colors[1]))
            ));

            const c2Row = this.row("Color 2", this.colorInput(
                colors[1],
                v => Selection.updateStyle("backgroundImage", compose(isRadial ? "Radial" : "Linear", angle, colors[0], v))
            ));

            rows.push(this.twoUp(c1Row, c2Row));

        }

        rows.push(this.row("Radio", this.numberWithUnit(
            this.px(this.styleValue(el, "borderRadius")),
            "px",
            v => Selection.updateStyle("borderRadius", v + "px"),
            { min: 0 }
        )));

        rows.push(this.row("Opacidad", this.numberWithUnit(
            parseFloat(this.styleValue(el, "opacity")) ?? 1,
            "",
            v => Selection.updateStyle("opacity", String(Math.min(1, Math.max(0, v)))),
            { min: 0, max: 1, step: 0.01 }
        )));

        return rows;

    }

    // Shadow layers live in data-shadows (an array of { preset, color }) —
    // the real source of truth — and el.style.boxShadow is always fully
    // re-derived from it (comma-joined), never parsed back out of CSS.
    // That lets multiple shadows stack (e.g. a tight dark contact shadow
    // plus a soft coloured glow) without any string-parsing ambiguity.
    getShadowLayers(el) {

        try {

            return JSON.parse(el.getAttribute("data-shadows") || "[]");

        } catch (e) {

            return [];

        }

    }

    saveShadowLayers(el, layers) {

        window.History?.snapshot();

        if (layers.length) {

            el.setAttribute("data-shadows", JSON.stringify(layers));

            el.style.boxShadow = layers.map(l => composeShadow(l.preset, l.color)).join(", ");

        } else {

            el.removeAttribute("data-shadows");

            el.style.boxShadow = "";

        }

    }

    buildShadowRows(el, rerender) {

        const layers = this.getShadowLayers(el);

        const rows = [];

        layers.forEach((layer, index) => {

            const intensityRow = this.row("Intensidad", this.segmented(
                SHADOW_PRESETS,
                layer.preset,
                next => {

                    const next2 = [...layers];

                    next2[index] = { ...layer, preset: next };

                    this.saveShadowLayers(el, next2);

                    rerender();

                }
            ));

            const colorInput = this.colorInput(
                layer.color,
                v => {

                    const next2 = [...layers];

                    next2[index] = { ...layer, color: v };

                    this.saveShadowLayers(el, next2);

                }
            );

            const removeBtn = document.createElement("button");

            removeBtn.type = "button";

            removeBtn.className = "remove-attr";

            removeBtn.textContent = "✕";

            removeBtn.addEventListener("click", () => {

                this.saveShadowLayers(el, layers.filter((_, i) => i !== index));

                rerender();

            });

            const colorRow = document.createElement("div");

            colorRow.className = "property-row";

            const colorLabel = document.createElement("label");

            colorLabel.textContent = t("Color") + (layers.length > 1 ? " " + (index + 1) : "");

            colorRow.appendChild(colorLabel);

            colorRow.appendChild(colorInput);

            colorRow.appendChild(removeBtn);

            rows.push(intensityRow);

            rows.push(colorRow);

            if (index < layers.length - 1)
                rows.push(this.subheading(""));

        });

        const addBtn = document.createElement("button");

        addBtn.type = "button";

        addBtn.className = layers.length ? "add-link" : "section-action-btn";

        addBtn.textContent = layers.length ? t("+ Añadir otra capa de sombra") : t("+ Añadir sombra");

        addBtn.addEventListener("click", () => {

            this.saveShadowLayers(el, [...layers, { preset: "medium", color: "#000000" }]);

            rerender();

        });

        rows.push(addBtn);

        return rows;

    }

    // Glassmorphism: backdrop-filter blur + (if the element had no
    // background of its own) a translucent fill and a soft light border,
    // so the blur is actually visible instead of doing nothing.
    buildGlassRows(el, rerender) {

        const blurMatch = (el.style.backdropFilter || "").match(/blur\((\d+(?:\.\d+)?)px\)/);

        const hasGlass = !!blurMatch;

        const rows = [];

        const checkbox = document.createElement("input");

        checkbox.type = "checkbox";

        checkbox.checked = hasGlass;

        checkbox.addEventListener("change", () => {

            if (checkbox.checked) {

                Selection.updateStyle("backdropFilter", "blur(12px)");

                Selection.updateStyle("webkitBackdropFilter", "blur(12px)");

                const hasBg = el.style.backgroundColor || el.style.backgroundImage;

                if (!hasBg) {

                    Selection.updateStyle("backgroundColor", "rgba(255, 255, 255, 0.12)");

                    Selection.updateStyle("borderWidth", "1px");

                    Selection.updateStyle("borderStyle", "solid");

                    Selection.updateStyle("borderColor", "rgba(255, 255, 255, 0.25)");

                }

            } else {

                Selection.updateStyle("backdropFilter", "");

                Selection.updateStyle("webkitBackdropFilter", "");

            }

            rerender();

        });

        rows.push(this.row("Vidrio esmerilado", checkbox));

        if (hasGlass) {

            rows.push(this.row("Intensidad", this.numberWithUnit(
                Number(blurMatch[1]),
                "px",
                v => {

                    Selection.updateStyle("backdropFilter", `blur(${v}px)`);

                    Selection.updateStyle("webkitBackdropFilter", `blur(${v}px)`);

                },
                { min: 0, max: 40 }
            )));

        }

        return rows;

    }

    // Pure-CSS :hover transition — data only (see hover.js), never live
    // on the canvas itself, same convention as Logic and Animation.
    buildHoverRows(el, rerender) {

        const data = window.HoverFX ? window.HoverFX.getData(el) : null;

        const rows = [];

        if (!data) {

            const btn = document.createElement("button");

            btn.type = "button";

            btn.className = "section-action-btn";

            btn.textContent = t("+ Añadir transición al pasar el ratón");

            btn.addEventListener("click", () => {

                window.HoverFX?.ensureData(el);

                rerender();

            });

            rows.push(btn);

        } else {

            const def = HOVER_PROPS.find(p => p.value === data.property) || HOVER_PROPS[0];

            rows.push(this.row("Propiedad", this.selectInput(
                HOVER_PROPS, data.property,
                v => { window.HoverFX.updateData(el, { property: v }); rerender(); }
            )));

            if (def.type === "color") {

                rows.push(this.row("Valor", this.colorInput(
                    data.value || "#8B8B8B",
                    v => window.HoverFX.updateData(el, { value: v })
                )));

            } else if (def.type === "number") {

                rows.push(this.row("Valor", this.numberWithUnit(
                    data.value ?? (data.property === "scale" ? 1.05 : 0.8),
                    "",
                    v => window.HoverFX.updateData(el, { value: v }),
                    { min: def.min, max: def.max, step: def.step }
                )));

            } else if (def.type === "shadow") {

                rows.push(this.row("Intensidad", this.selectInput(
                    SHADOW_PRESETS, data.value || "medium",
                    v => window.HoverFX.updateData(el, { value: v })
                )));

                rows.push(this.row("Color de sombra", this.colorInput(
                    data.shadowColor || "#000000",
                    v => window.HoverFX.updateData(el, { shadowColor: v })
                )));

            }

            rows.push(this.row("Duración", this.numberWithUnit(
                data.duration ?? HOVER_DEFAULT_DURATION,
                "ms",
                v => window.HoverFX.updateData(el, { duration: v }),
                { min: 0, step: 50 }
            )));

            const removeBtn = document.createElement("button");

            removeBtn.type = "button";

            removeBtn.className = "add-link";

            removeBtn.textContent = t("Quitar transición");

            removeBtn.addEventListener("click", () => {

                window.HoverFX?.remove(el);

                rerender();

            });

            rows.push(removeBtn);

        }

        return rows;

    }

    // Gradient borders use border-image (not background-image, which the
    // Fondo controls above already own) — data-border-gradient is the
    // source of truth, same pattern as shadow layers / bg patterns.
    getBorderGradient(el) {

        try {

            return JSON.parse(el.getAttribute("data-border-gradient") || "null");

        } catch (e) {

            return null;

        }

    }

    saveBorderGradient(el, grad) {

        window.History?.snapshot();

        if (grad) {

            el.setAttribute("data-border-gradient", JSON.stringify(grad));

            el.style.borderImage = `linear-gradient(to right, ${grad.color1}, ${grad.color2}) 1`;

        } else {

            el.removeAttribute("data-border-gradient");

            el.style.borderImage = "";

        }

    }

    buildBorderRows(el, rerender) {

        const hasBorder = this.styleValue(el, "borderStyle") &&
                           this.styleValue(el, "borderStyle") !== "none";

        const rows = [];

        if (!hasBorder) {

            const btn = document.createElement("button");

            btn.type = "button";

            btn.className = "section-action-btn";

            btn.textContent = t("+ Añadir borde");

            btn.addEventListener("click", () => {

                Selection.updateStyle("borderWidth", "1px");

                Selection.updateStyle("borderStyle", "solid");

                Selection.updateStyle("borderColor", "#8B8B8B");

                rerender();

            });

            rows.push(btn);

        } else {

            rows.push(this.row("Grosor", this.numberWithUnit(
                this.px(this.styleValue(el, "borderWidth")),
                "px",
                v => Selection.updateStyle("borderWidth", v + "px"),
                { min: 0 }
            )));

            rows.push(this.row("Estilo", this.selectInput(
                [
                    { value: "solid", label: "Sólido" },
                    { value: "dashed", label: "Discontinuo" },
                    { value: "dotted", label: "Punteado" }
                ],
                this.styleValue(el, "borderStyle"),
                v => Selection.updateStyle("borderStyle", v)
            )));

            rows.push(this.row("Color", this.colorInput(
                this.styleValue(el, "borderColor"),
                v => Selection.updateStyle("borderColor", v)
            )));

            const borderGrad = this.getBorderGradient(el);

            rows.push(this.row("Estilo de color", this.segmented(
                [
                    { value: "Solid", label: "Sólido" },
                    { value: "Gradient", label: "Degradado" }
                ],
                borderGrad ? "Gradient" : "Solid",
                next => {

                    if (next === "Gradient")
                        this.saveBorderGradient(el, { color1: "#B4A996", color2: "#2A2A2A" });

                    else
                        this.saveBorderGradient(el, null);

                    rerender();

                }
            )));

            if (borderGrad) {

                const g1Row = this.row("Color 1", this.colorInput(
                    borderGrad.color1,
                    v => this.saveBorderGradient(el, { ...borderGrad, color1: v })
                ));

                const g2Row = this.row("Color 2", this.colorInput(
                    borderGrad.color2,
                    v => this.saveBorderGradient(el, { ...borderGrad, color2: v })
                ));

                rows.push(this.twoUp(g1Row, g2Row));

            }

            const removeBtn = document.createElement("button");

            removeBtn.type = "button";

            removeBtn.className = "add-link";

            removeBtn.textContent = t("Quitar borde");

            removeBtn.addEventListener("click", () => {

                Selection.updateStyle("borderWidth", "");

                Selection.updateStyle("borderStyle", "none");

                Selection.updateStyle("borderColor", "");

                el.removeAttribute("data-border-gradient");

                el.style.borderImage = "";

                rerender();

            });

            rows.push(removeBtn);

        }

        return rows;

    }

    buildAppearanceSection(el, rerender) {

        const rows = [];

        rows.push(...this.buildFondoRows(el, rerender));

        rows.push(this.subheading("Borde"));

        rows.push(...this.buildBorderRows(el, rerender));

        rows.push(this.subheading("Sombra"));

        rows.push(...this.buildShadowRows(el, rerender));

        rows.push(this.subheading("Vidrio esmerilado"));

        rows.push(...this.buildGlassRows(el, rerender));

        rows.push(this.subheading("Transición al pasar el ratón"));

        rows.push(...this.buildHoverRows(el, rerender));

        return this.section("Apariencia", rows, { collapsed: true });

    }

    /* =====================================================
       Animación — línea de tiempo con fotogramas clave (ver animation.js)
       ===================================================== */

    buildAnimationSection(el, rerender) {

        const rows = [];

        const hasAnimation = window.Animation ? window.Animation.hasAnimation(el) : false;

        if (!hasAnimation) {

            const btn = document.createElement("button");

            btn.type = "button";

            btn.className = "section-action-btn";

            btn.textContent = t("+ Crear animación");

            btn.addEventListener("click", () => {

                window.Animation?.ensureData(el);

                window.Animation?.open(el);

            });

            rows.push(btn);

            if (typeof ANIMATION_PRESET_MENU !== "undefined") {

                rows.push(this.subheading("Efectos rápidos"));

                ANIMATION_PRESET_MENU.forEach(preset => {

                    const presetBtn = document.createElement("button");

                    presetBtn.type = "button";

                    presetBtn.className = "add-link";

                    presetBtn.textContent = preset.icon + " " + t(preset.label, preset.label);

                    presetBtn.addEventListener("click", () => {

                        window.Animation?.[preset.method]?.(el);

                        window.Animation?.open(el);

                    });

                    rows.push(presetBtn);

                });

            }

        } else {

            const data = window.Animation.getData(el);

            const trackCount = Object.values(data.tracks || {}).filter(t => t?.length).length;

            const summary = document.createElement("div");

            summary.className = "modal-subtitle";

            summary.style.margin = "0 0 8px";

            summary.textContent =
                `${trackCount} pista${trackCount === 1 ? "" : "s"} · ${(data.duration / 1000).toFixed(2)}s` +
                (data.loop ? " · bucle" : "") +
                (data.autoplay ? " · autorreproducción" : " · manual");

            rows.push(summary);

            const editBtn = document.createElement("button");

            editBtn.type = "button";

            editBtn.className = "section-action-btn";

            editBtn.textContent = t("Editar línea de tiempo");

            editBtn.addEventListener("click", () => window.Animation?.open(el));

            rows.push(editBtn);

            const removeBtn = document.createElement("button");

            removeBtn.type = "button";

            removeBtn.className = "add-link";

            removeBtn.textContent = t("Eliminar animación");

            removeBtn.addEventListener("click", () => {

                window.Animation?.remove(el);

                rerender();

            });

            rows.push(removeBtn);

        }

        return this.section("Animación", rows, { collapsed: true });

    }

    /* =====================================================
       Lógica — interacciones simples (cuándo -> acción -> objetivo)
       ===================================================== */

    buildLogicSection(el, rerender) {

        const rules = window.Logic ? window.Logic.getRules(el) : [];

        const rows = rules.map((rule, index) => this.buildLogicRuleRow(el, rule, index, rerender));

        const addBtn = document.createElement("button");

        addBtn.type = "button";

        addBtn.className = "add-link";

        addBtn.textContent = t("+ Añadir regla");

        addBtn.addEventListener("click", () => {

            window.Logic?.addRule(el);

            rerender();

        });

        rows.push(addBtn);

        return this.section("Lógica", rows, { collapsed: rules.length === 0 });

    }

    buildLogicRuleRow(el, rule, index, rerender) {

        const card = document.createElement("div");

        card.className = "logic-rule";

        const header = document.createElement("div");

        header.className = "logic-rule-header";

        const label = document.createElement("span");

        label.textContent = t("Regla") + " " + (index + 1);

        const removeBtn = document.createElement("button");

        removeBtn.type = "button";

        removeBtn.className = "remove-attr";

        removeBtn.textContent = "✕";

        removeBtn.addEventListener("click", () => {

            window.Logic.removeRule(el, index);

            rerender();

        });

        header.appendChild(label);

        header.appendChild(removeBtn);

        card.appendChild(header);

        card.appendChild(this.row("Cuándo", this.selectInput(
            LOGIC_TRIGGERS, rule.trigger,
            v => { window.Logic.updateRule(el, index, { trigger: v }); rerender(); }
        )));

        const triggerFields = LOGIC_TRIGGER_FIELDS[rule.trigger] || [];

        triggerFields.forEach(field => {

            card.appendChild(this.buildLogicField(el, rule, index, field));

        });

        card.appendChild(this.row("Acción", this.selectInput(
            LOGIC_ACTIONS, rule.action,
            v => { window.Logic.updateRule(el, index, { action: v }); rerender(); }
        )));

        const fields = LOGIC_ACTION_FIELDS[rule.action] || ["target"];

        fields.forEach(field => {

            card.appendChild(this.buildLogicField(el, rule, index, field));

        });

        return card;

    }

    buildLogicField(el, rule, index, field) {

        if (field === "target") {

            return this.row("Objetivo", this.selectInput(
                window.Logic.getTargetOptions(), rule.target || "self",
                v => window.Logic.updateRule(el, index, { target: v })
            ));

        }

        if (field === "property") {

            return this.row("Propiedad", this.selectInput(
                LOGIC_STYLE_PROPS, rule.property || "backgroundColor",
                v => window.Logic.updateRule(el, index, { property: v })
            ));

        }

        if (field === "value") {

            return this.row("Valor", this.textInput(
                rule.value || "",
                v => window.Logic.updateRule(el, index, { value: v })
            ));

        }

        if (field === "color") {

            return this.row("Color", this.colorInput(
                rule.value || "#B4A996",
                v => window.Logic.updateRule(el, index, { value: v })
            ));

        }

        if (field === "className") {

            return this.row("Clase CSS", this.textInput(
                rule.className || "",
                v => window.Logic.updateRule(el, index, { className: v })
            ));

        }

        if (field === "attrName") {

            return this.row("Atributo", this.textInput(
                rule.attrName || "",
                v => window.Logic.updateRule(el, index, { attrName: v })
            ));

        }

        if (field === "url") {

            return this.row("URL", this.textInput(
                rule.url || "",
                v => window.Logic.updateRule(el, index, { url: v })
            ));

        }

        if (field === "duration") {

            return this.row("Duración", this.numberWithUnit(
                rule.duration != null ? rule.duration : LOGIC_DEFAULT_DURATION,
                "ms",
                v => window.Logic.updateRule(el, index, { duration: v }),
                { min: 0, step: 50 }
            ));

        }

        if (field === "key") {

            const input = this.textInput(
                rule.key || "",
                v => window.Logic.updateRule(el, index, { key: v })
            );

            input.placeholder = t("p. ej. Enter, Escape, a (vacío = cualquiera)");

            return this.row("Tecla", input);

        }

        if (field === "delay") {

            return this.row("Retraso", this.numberWithUnit(
                rule.delay != null ? rule.delay : 1000,
                "ms",
                v => window.Logic.updateRule(el, index, { delay: v }),
                { min: 0, step: 100 }
            ));

        }

        if (field === "storageKey") {

            const input = this.textInput(
                rule.storageKey || "",
                v => window.Logic.updateRule(el, index, { storageKey: v })
            );

            input.placeholder = t("clave, p. ej. nombre-usuario");

            return this.row("Clave", input);

        }

        if (field === "date") {

            const input = document.createElement("input");

            input.type = "datetime-local";

            input.value = rule.value || "";

            input.addEventListener("change", () => {

                window.Logic.updateRule(el, index, { value: input.value });

            });

            return this.row("Fecha objetivo", input);

        }

        if (field === "httpMethod") {

            return this.row("Método", this.selectInput(
                LOGIC_HTTP_METHODS, rule.httpMethod || "GET",
                v => { window.Logic.updateRule(el, index, { httpMethod: v }); }
            ));

        }

        if (field === "body") {

            const textarea = document.createElement("textarea");

            textarea.className = "logic-body-input";

            textarea.rows = 3;

            textarea.placeholder = t('{"clave": "valor"} (opcional, ignorado en GET)');

            textarea.value = rule.body || "";

            textarea.addEventListener("input", () => {

                window.Logic.updateRule(el, index, { body: textarea.value });

            });

            return this.row("Cuerpo", textarea);

        }

        if (field === "responseHandling") {

            return this.row("Al recibir respuesta", this.selectInput(
                LOGIC_RESPONSE_HANDLING_OPTIONS, rule.responseHandling || "none",
                v => { window.Logic.updateRule(el, index, { responseHandling: v }); rerender(); }
            ));

        }

        if (field === "newTab") {

            const checkbox = document.createElement("input");

            checkbox.type = "checkbox";

            checkbox.checked = !!rule.newTab;

            checkbox.addEventListener("change", () => {

                window.Logic.updateRule(el, index, { newTab: checkbox.checked });

            });

            return this.row("Nueva pestaña", checkbox);

        }

        const empty = document.createElement("div");

        return empty;

    }

    /* =====================================================
       Avanzado — atributos personalizados + exportar selección
       ===================================================== */

    buildAttributeRows(el, rerender) {

        const rows = [];

        const skip = new Set([
            "class", "style", "draggable", "data-lid", "data-logic", "data-prev-display",
            "data-animation", "data-kind", "data-hover", "data-tag",
            "data-shadows", "data-bg-pattern", "data-border-gradient", "data-responsive", "data-code"
        ]);

        [...el.attributes].forEach(attr => {

            if (skip.has(attr.name))
                return;

            const attrRow = document.createElement("div");

            attrRow.className = "attr-row";

            const keyInput = document.createElement("input");

            keyInput.type = "text";

            keyInput.value = attr.name;

            keyInput.placeholder = t("atributo");

            const valInput = document.createElement("input");

            valInput.type = "text";

            valInput.value = attr.value;

            valInput.placeholder = t("valor");

            valInput.addEventListener("input", () => {

                Selection.updateAttribute(attr.name, valInput.value);

            });

            keyInput.addEventListener("change", () => {

                const newName = keyInput.value.trim();

                if (!newName || newName === attr.name)
                    return;

                window.History?.snapshot();

                el.removeAttribute(attr.name);

                el.setAttribute(newName, valInput.value);

                rerender();

            });

            const removeBtn = document.createElement("button");

            removeBtn.type = "button";

            removeBtn.className = "remove-attr";

            removeBtn.textContent = "✕";

            removeBtn.addEventListener("click", () => {

                window.History?.snapshot();

                el.removeAttribute(attr.name);

                rerender();

            });

            attrRow.appendChild(keyInput);

            attrRow.appendChild(valInput);

            attrRow.appendChild(removeBtn);

            rows.push(attrRow);

        });

        const addBtn = document.createElement("button");

        addBtn.type = "button";

        addBtn.className = "add-link";

        addBtn.textContent = t("+ Añadir atributo");

        addBtn.addEventListener("click", () => {

            window.History?.snapshot();

            el.setAttribute("data-attr", "");

            rerender();

        });

        rows.push(addBtn);

        return rows;

    }

    buildExportSelectionButton(el, rerender) {

        const btn = document.createElement("button");

        btn.type = "button";

        btn.className = "section-action-btn";

        btn.textContent = t("Exportar selección");

        btn.addEventListener("click", () => {

            const clone = el.cloneNode(true);

            clone.classList.remove("selected", "hovered", "dragging", "canvas-movable", "free-dragging");

            clone.removeAttribute("draggable");

            clone.querySelectorAll("*").forEach(child => {

                child.classList.remove("selected", "hovered", "dragging", "canvas-movable", "free-dragging");

                child.removeAttribute("draggable");

            });

            Utils.download("seleccion.html", clone.outerHTML);

        });

        return btn;

    }

    buildAdvancedSection(el, rerender) {

        const rows = [];

        rows.push(...this.buildAttributeRows(el, rerender));

        rows.push(this.subheading("Exportar"));

        rows.push(this.buildExportSelectionButton(el, rerender));

        return this.section("Avanzado", rows, { collapsed: true });

    }

}

window.Renderer = new Renderer();
