// web/editor/resizeHandles.js
//
// Direct "by eye" resizing on the canvas: small square handles on the
// selected element's edges/corners, dragged with the mouse. Resize-only
// (no rotate) — the user picked this scope explicitly.
//
// Design choices:
// - Every element gets all 8 handles (nw/n/ne/w/e/sw/s/se), regardless of
//   Position mode. For absolutely-positioned elements, dragging a west/
//   north handle both resizes AND repositions (left/top), since that edge
//   is the one moving. Normal-flow elements don't have a meaningful left/
//   top to move (their position comes from document flow, not those
//   properties), so a west/north drag there only resizes — the box grows
//   away from that edge rather than visually tracking the cursor exactly.
//   Not pixel-perfect for flow elements, but still useful (Figma's
//   auto-layout resize handles behave the same way), and offering all 8
//   uniformly is simpler to understand than a handle count that silently
//   changes with Position.
// - Handles are appended to document.body with position:fixed, positioned
//   from each frame's real getBoundingClientRect() — the same pattern
//   canvas.js's "+" menu already uses (see showAddMenu). This is
//   deliberately NOT a child of #canvas: getExportHtml() clones #canvas
//   wholesale for export/preview, and anything living inside it needs
//   explicit stripping (like .selected/.hovered/draggable already are).
//   Living outside #canvas sidesteps that risk entirely — nothing to leak.
// - A lightweight requestAnimationFrame loop (running only while something
//   is selected) keeps the handles glued to the target regardless of what
//   moved it — inspector field edits, undo/redo, the animation timeline
//   preview, another drag, canvas-container scrolling, whatever. Simpler
//   and more robust than trying to hook every possible mutation source.
// - Disabled entirely outside the Desktop breakpoint (see responsive.js):
//   these handles write straight to the element's real inline style, which
//   is the Desktop source of truth. Resizing "by eye" while previewing
//   Tablet/Mobile would silently edit Desktop while the user is looking at
//   a different size — confusing. Responsive per-breakpoint sizing has its
//   own override fields in the inspector instead.
// - Mirrors canvas.js's freeDragStart() drag mechanics: one
//   window.History?.snapshot() taken right before the first real movement
//   (not per pixel), direct el.style mutation during the drag (bypassing
//   Selection.updateStyle to avoid snapshot/event spam on every mousemove),
//   window.Inspector?.refresh() on mouseup so the Layout section's Fixed
//   size fields reflect the new numbers.

const RESIZE_HANDLE_SIZE = 8;

const RESIZE_HANDLE_DIRS = ["nw", "n", "ne", "w", "e", "sw", "s", "se"];

const RESIZE_MIN_SIZE = 20;

class ResizeHandlesManager {

    constructor() {

        this.target = null;

        this.handles = new Map();

        this.rafId = null;

        this.dragging = false;

        this.handleMouseDown = null; // set per-handle in attach()

    }

    initialize() {

        Selection.addListener("selectionChanged", ({ element }) => this.attach(element));

        Selection.addListener("selectionCleared", () => this.detach());

        // NOTE: reads Selection.getSelected(), not this.target — attach()
        // nulls this.target out when it bails early (e.g. the breakpoint
        // guard below), so re-deriving from Selection's own state (which
        // switching breakpoints never touches) is what makes handles
        // actually reappear when coming back to Desktop.
        window.Responsive?.onChange(() => this.attach(Selection.getSelected()));

    }

    isDesktop() {

        return !window.Responsive || window.Responsive.current === "desktop";

    }

    directionsFor(el) {

        return RESIZE_HANDLE_DIRS;

    }

    cursorFor(dir) {

        if (dir === "n" || dir === "s")
            return "ns-resize";

        if (dir === "e" || dir === "w")
            return "ew-resize";

        if (dir === "ne" || dir === "sw")
            return "nesw-resize";

        return "nwse-resize"; // nw, se

    }

    attach(element) {

        // Always start clean — avoids leftover handles from a previous
        // target/direction-set when re-attaching for the same element
        // (e.g. after a Position toggle).
        this.detach();

        if (!element || !this.isDesktop())
            return;

        const canvas = document.getElementById("canvas");

        if (!canvas || !canvas.contains(element))
            return;

        this.target = element;

        this.directionsFor(element).forEach(dir => {

            const handle = document.createElement("div");

            handle.className = "resize-handle";

            handle.dataset.dir = dir;

            handle.style.cursor = this.cursorFor(dir);

            handle.addEventListener("mousedown", (e) => this.startResize(e, dir));

            document.body.appendChild(handle);

            this.handles.set(dir, handle);

        });

        this.startLoop();

    }

    detach() {

        this.stopLoop();

        this.handles.forEach(h => h.remove());

        this.handles.clear();

        this.target = null;

    }

    // Selection.emit() (see selection.js) has no try/catch around its
    // listener calls, so a throw in here would break element selection
    // app-wide, not just this feature. requestAnimationFrame isn't
    // implemented in every environment this code might run in (e.g. the
    // jsdom test harness) — fall back to a plain timer rather than assume
    // it exists.
    raf(fn) {

        if (typeof window.requestAnimationFrame === "function")
            return window.requestAnimationFrame(fn);

        return window.setTimeout(fn, 16);

    }

    cancelRaf(id) {

        if (typeof window.cancelAnimationFrame === "function")
            window.cancelAnimationFrame(id);

        else
            window.clearTimeout(id);

    }

    startLoop() {

        const tick = () => {

            if (!this.target || !document.body.contains(this.target)) {

                this.detach();

                return;

            }

            this.reposition();

            this.rafId = this.raf(tick);

        };

        this.rafId = this.raf(tick);

    }

    stopLoop() {

        if (this.rafId)
            this.cancelRaf(this.rafId);

        this.rafId = null;

    }

    reposition() {

        const rect = this.target.getBoundingClientRect();

        const half = RESIZE_HANDLE_SIZE / 2;

        const positions = {
            nw: { x: rect.left, y: rect.top },
            n: { x: rect.left + rect.width / 2, y: rect.top },
            ne: { x: rect.left + rect.width, y: rect.top },
            w: { x: rect.left, y: rect.top + rect.height / 2 },
            e: { x: rect.left + rect.width, y: rect.top + rect.height / 2 },
            sw: { x: rect.left, y: rect.top + rect.height },
            s: { x: rect.left + rect.width / 2, y: rect.top + rect.height },
            se: { x: rect.left + rect.width, y: rect.top + rect.height }
        };

        this.handles.forEach((handle, dir) => {

            const p = positions[dir];

            handle.style.left = (p.x - half) + "px";
            handle.style.top = (p.y - half) + "px";

        });

    }

    startResize(event, dir) {

        if (event.button !== 0)
            return;

        event.preventDefault();

        event.stopPropagation();

        const el = this.target;

        if (!el)
            return;

        // Absolute and Fixed both have a real left/top the west/north
        // handles can move; Inline and Sticky don't (Sticky's top is a
        // scroll-trigger offset, not a position to drag).
        const isAbsolute = el.style.position === "absolute" || el.style.position === "fixed";

        const startRect = el.getBoundingClientRect();

        const startX = event.clientX;
        const startY = event.clientY;

        const startWidth = startRect.width;
        const startHeight = startRect.height;

        const startLeft = parseFloat(el.style.left) || 0;
        const startTop = parseFloat(el.style.top) || 0;

        let moved = false;

        this.dragging = true;

        const onMouseMove = (moveEvent) => {

            const dx = moveEvent.clientX - startX;
            const dy = moveEvent.clientY - startY;

            if (!moved && (Math.abs(dx) > 2 || Math.abs(dy) > 2)) {

                moved = true;

                // One snapshot for the whole drag, not per pixel.
                window.History?.snapshot();

            }

            if (!moved)
                return;

            let newWidth = startWidth;
            let newHeight = startHeight;

            if (dir.includes("e"))
                newWidth = Math.max(RESIZE_MIN_SIZE, startWidth + dx);

            if (dir.includes("w"))
                newWidth = Math.max(RESIZE_MIN_SIZE, startWidth - dx);

            if (dir.includes("s"))
                newHeight = Math.max(RESIZE_MIN_SIZE, startHeight + dy);

            if (dir.includes("n"))
                newHeight = Math.max(RESIZE_MIN_SIZE, startHeight - dy);

            if (dir.includes("e") || dir.includes("w"))
                el.style.width = newWidth + "px";

            if (dir.includes("n") || dir.includes("s"))
                el.style.height = newHeight + "px";

            // Only absolutely-positioned elements have a real left/top to
            // move — flow elements resize from the fixed edge without
            // repositioning (see the file header comment).
            if (isAbsolute) {

                if (dir.includes("w"))
                    el.style.left = (startLeft + (startWidth - newWidth)) + "px";

                if (dir.includes("n"))
                    el.style.top = (startTop + (startHeight - newHeight)) + "px";

            }

        };

        const onMouseUp = () => {

            document.removeEventListener("mousemove", onMouseMove);

            document.removeEventListener("mouseup", onMouseUp);

            this.dragging = false;

            // Refresh the inspector so the Layout section's Fixed-mode
            // width/height (and, for absolute elements, top/left) fields
            // reflect where the element actually landed.
            if (moved)
                window.Inspector?.refresh();

        };

        document.addEventListener("mousemove", onMouseMove);

        document.addEventListener("mouseup", onMouseUp);

    }

}

window.ResizeHandles = new ResizeHandlesManager();
