// web/editor/responsive.js
//
// Responsive breakpoints: Desktop (the base — every element's normal
// inline style, unchanged) plus Tablet/Mobile overrides layered on top.
//
// Design choice: overrides are NEVER written into the element's inline
// style (that's the single source of truth for the Desktop appearance,
// and every other part of the app — Selection.updateStyle, Animation,
// Hover, etc. — assumes it stays that way). Instead, each element that
// has a responsive override carries a data-responsive JSON attribute:
//
//   { "tablet": { "display": "none" }, "mobile": { "flexDirection": "column" } }
//
// While editing at a non-Desktop breakpoint, those overrides are applied
// live via a single injected <style> tag in the *editor's own* <head>
// (never inside #canvas, so it's automatically excluded when app.js
// clones #canvas for export/preview — same reasoning as why "selected"/
// "hovered" classes never leak into the export). At export time, the
// same data is compiled into real `@media (max-width: ...)` blocks,
// keyed by each element's data-lid (the same targeting convention Logic/
// Animation/Hover already use).
//
// Because the base appearance is an inline style, and inline styles beat
// stylesheet rules on specificity no matter what, both the live preview
// rule and the exported media-query rule need !important to actually
// override it. Not the prettiest CSS, but correct and necessary given
// how the rest of this app already represents "the base style".

const RESPONSIVE_BREAKPOINTS = ["tablet", "mobile"];

// Preview width applied to the canvas while editing at that breakpoint
// (purely visual — matches the presets already used in Settings/
// StartScreen so the numbers feel consistent across the app).
const RESPONSIVE_PREVIEW_WIDTH = { tablet: 768, mobile: 375 };

// max-width used in the *exported* page's real @media queries — standard,
// widely-used breakpoint values (not tied to the preview width above).
const RESPONSIVE_EXPORT_MAX_WIDTH = { tablet: 768, mobile: 480 };

class ResponsiveManager {

    constructor() {

        this.current = "desktop";

        this.listeners = [];

        this._desktopWidth = "";

    }

    initialize() {

        const switchEl = document.getElementById("breakpoint-switch");

        if (switchEl) {

            switchEl.addEventListener("click", (e) => {

                const btn = e.target.closest("button[data-breakpoint]");

                if (btn)
                    this.setBreakpoint(btn.dataset.breakpoint);

            });

        }

        this.updateSwitchUI();

    }

    onChange(cb) {

        this.listeners.push(cb);

    }

    camelToKebab(prop) {

        return prop.replace(/[A-Z]/g, c => "-" + c.toLowerCase());

    }

    resolveLid(el) {

        if (window.Logic)
            return window.Logic.resolveLid(el);

        if (!el.dataset.lid)
            el.dataset.lid = "lid-" + Math.random().toString(36).slice(2, 9);

        return el.dataset.lid;

    }

    /* =========================================================
       Data model — data-responsive JSON per element.
       ========================================================= */

    getData(el) {

        try {

            const raw = el.getAttribute("data-responsive");

            return raw ? JSON.parse(raw) : null;

        } catch (e) {

            return null;

        }

    }

    ensureData(el) {

        return this.getData(el) || { tablet: {}, mobile: {} };

    }

    saveData(el, data) {

        window.History?.snapshot();

        el.setAttribute("data-responsive", JSON.stringify(data));

    }

    getProperty(el, prop) {

        const data = this.getData(el);

        return data?.[this.current]?.[prop];

    }

    updateProperty(el, prop, value) {

        if (this.current === "desktop")
            return;

        const data = this.ensureData(el);

        if (!data[this.current])
            data[this.current] = {};

        data[this.current][prop] = value;

        this.saveData(el, data);

        this.applyPreviewCSS();

    }

    removeProperty(el, prop) {

        if (this.current === "desktop")
            return;

        const data = this.getData(el);

        if (!data?.[this.current] || !(prop in data[this.current]))
            return;

        delete data[this.current][prop];

        const hasAny = RESPONSIVE_BREAKPOINTS.some(bp => data[bp] && Object.keys(data[bp]).length);

        if (hasAny)
            this.saveData(el, data);

        else {

            window.History?.snapshot();

            el.removeAttribute("data-responsive");

        }

        this.applyPreviewCSS();

    }

    /* =========================================================
       Breakpoint switching
       ========================================================= */

    setBreakpoint(bp) {

        if (!["desktop", ...RESPONSIVE_BREAKPOINTS].includes(bp) || bp === this.current)
            return;

        const canvas = document.getElementById("canvas");

        if (this.current === "desktop" && bp !== "desktop" && canvas)
            this._desktopWidth = canvas.style.maxWidth || "";

        this.current = bp;

        if (canvas) {

            if (bp === "desktop")
                canvas.style.maxWidth = this._desktopWidth || "";

            else
                canvas.style.maxWidth = RESPONSIVE_PREVIEW_WIDTH[bp] + "px";

        }

        this.applyPreviewCSS();

        this.updateSwitchUI();

        this.listeners.forEach(cb => {

            try {
                cb(bp);
            } catch (e) {
                console.error("responsive listener error", e);
            }

        });

    }

    updateSwitchUI() {

        const switchEl = document.getElementById("breakpoint-switch");

        if (!switchEl)
            return;

        switchEl.querySelectorAll("button[data-breakpoint]").forEach(btn => {

            btn.classList.toggle("active", btn.dataset.breakpoint === this.current);

        });

    }

    /* =========================================================
       Live editor preview — an injected <style> in <head>, never
       touching inline styles, never part of the exported clone.
       ========================================================= */

    applyPreviewCSS() {

        let styleEl = document.getElementById("responsive-preview-style");

        if (!styleEl) {

            styleEl = document.createElement("style");

            styleEl.id = "responsive-preview-style";

            document.head.appendChild(styleEl);

        }

        if (this.current === "desktop") {

            styleEl.textContent = "";

            return;

        }

        const canvas = document.getElementById("canvas");

        if (!canvas)
            return;

        let css = "";

        canvas.querySelectorAll("[data-responsive]").forEach(el => {

            const data = this.getData(el);

            const overrides = data?.[this.current];

            if (!overrides || !Object.keys(overrides).length)
                return;

            const lid = this.resolveLid(el);

            const decls = Object.entries(overrides)
                .map(([prop, value]) => `${this.camelToKebab(prop)}: ${value} !important;`)
                .join(" ");

            css += `[data-lid="${lid}"] { ${decls} }\n`;

        });

        styleEl.textContent = css;

    }

    /* =========================================================
       Export — real @media (max-width: ...) blocks.
       ========================================================= */

    buildExportCSS(root) {

        const elements = [...root.querySelectorAll("[data-responsive]")];

        if (!elements.length)
            return "";

        let css = "";

        RESPONSIVE_BREAKPOINTS.forEach(bp => {

            let body = "";

            elements.forEach(el => {

                let data;

                try {
                    data = JSON.parse(el.getAttribute("data-responsive"));
                } catch (e) {
                    return;
                }

                const overrides = data?.[bp];

                if (!overrides || !Object.keys(overrides).length)
                    return;

                const lid = this.resolveLid(el);

                const decls = Object.entries(overrides)
                    .map(([prop, value]) => `${this.camelToKebab(prop)}: ${value} !important;`)
                    .join(" ");

                body += `  [data-lid="${lid}"] { ${decls} }\n`;

            });

            if (body)
                css += `@media (max-width: ${RESPONSIVE_EXPORT_MAX_WIDTH[bp]}px) {\n${body}}\n`;

        });

        return css;

    }

}

window.Responsive = new ResponsiveManager();
