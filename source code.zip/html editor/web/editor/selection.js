// web/editor/selection.js

class SelectionManager {

    constructor() {

        this.selectedElement = null;
        this.hoveredElement = null;

        this.canvas = null;

        this.listeners = [];

    }

    initialize() {

        this.canvas = document.getElementById("canvas");

        if (!this.canvas) {
            console.error("Canvas not found.");
            return;
        }

        this.canvas.addEventListener("click", this.onClick.bind(this));

        this.canvas.addEventListener("mouseover", this.onHover.bind(this));

        this.canvas.addEventListener("mouseout", this.onLeave.bind(this));

        document.addEventListener("keydown", this.onKeyDown.bind(this));

    }

    onClick(event) {

    event.stopPropagation();

    const target = event.target.closest(
        "h1,h2,h3,h4,h5,h6,p,div,span,button,input,textarea,img,a,section,article,main,header,footer,nav,ul,ol,li"
    );

    if (!target || target.id === "canvas") {

        this.clear();

        return;

    }

    this.select(target);

    }

    onHover(event) {

    const target = event.target.closest(
        "h1,h2,h3,h4,h5,h6,p,div,span,button,input,textarea,img,a,section,article,main,header,footer,nav,ul,ol,li"
    );

    if (!target || target.id === "canvas")
        return;

    if (target === this.selectedElement)
        return;

    this.hoveredElement = target;

    target.classList.add("hovered");

    }

    onLeave(event) {

    const target = event.target.closest(
        "h1,h2,h3,h4,h5,h6,p,div,span,button,input,textarea,img,a,section,article,main,header,footer,nav,ul,ol,li"
    );

    if (!target)
        return;

    target.classList.remove("hovered");

    }

    onKeyDown(event) {

        if (event.key === "Escape") {

            this.clear();

        }

    }

    select(element) {

        if (!element)
            return;

        if (this.selectedElement) {

            this.selectedElement.classList.remove("selected");

        }

        this.selectedElement = element;

        this.selectedElement.classList.add("selected");

        this.emit("selectionChanged", {

            element: this.selectedElement,

            tag: this.selectedElement.dataset.tag ||
                 this.selectedElement.tagName.toLowerCase()

        });

    }

    clear() {

        if (this.selectedElement) {

            this.selectedElement.classList.remove("selected");

        }

        this.selectedElement = null;

        this.emit("selectionCleared");

    }

    getSelected() {

        return this.selectedElement;

    }

    getTag() {

        if (!this.selectedElement)
            return null;

        return this.selectedElement.dataset.tag ||
               this.selectedElement.tagName.toLowerCase();

    }

    getComputedStyle() {

        if (!this.selectedElement)
            return null;

        return window.getComputedStyle(this.selectedElement);

    }

    getInlineStyle(property) {

        if (!this.selectedElement)
            return "";

        return this.selectedElement.style[property];

    }

    updateStyle(property, value) {

        if (!this.selectedElement)
            return;

        // Snapshot before mutating so Undo reverts to the pre-edit state
        window.History?.snapshot();

        this.selectedElement.style[property] = value;

        this.emit("styleChanged", {

            property,

            value,

            element: this.selectedElement

        });

    }

    updateAttribute(attribute, value) {

        if (!this.selectedElement)
            return;

        window.History?.snapshot();

        this.selectedElement.setAttribute(attribute, value);

        this.emit("attributeChanged", {

            attribute,

            value,

            element: this.selectedElement

        });

    }

    updateText(value) {

        if (!this.selectedElement)
            return;

        window.History?.snapshot();

        this.selectedElement.textContent = value;

        this.emit("textChanged", {

            value,

            element: this.selectedElement

        });

    }

    removeSelected() {

        if (!this.selectedElement)
            return;

        window.History?.snapshot();

        const removed = this.selectedElement;

        this.clear();

        removed.remove();

        this.emit("elementRemoved");

    }

    duplicateSelected() {

        if (!this.selectedElement)
            return;

        window.History?.snapshot();

        const clone = this.selectedElement.cloneNode(true);

        this.selectedElement.parentNode.insertBefore(

            clone,

            this.selectedElement.nextSibling

        );

        this.select(clone);

        this.emit("elementDuplicated");

    }

    addListener(event, callback) {

        this.listeners.push({

            event,

            callback

        });

    }

    emit(event, data = {}) {

        this.listeners.forEach(listener => {

            if (listener.event === event) {

                listener.callback(data);

            }

        });

    }

}

window.Selection = new SelectionManager();