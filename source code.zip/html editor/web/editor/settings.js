// web/editor/settings.js
//
// Project settings modal (the ⚲ button in the left sidebar): canvas size
// presets (Desktop/Tablet/Móvil) + custom width, and page background color.
// Applies live to the #canvas element.

class SettingsManager {

    constructor() {

        this.handleEscape = this.handleEscape.bind(this);

    }

    initialize() {

        document.getElementById("project-settings")?.addEventListener(
            "click",
            () => this.open()
        );

    }

    handleEscape(e) {

        if (e.key === "Escape")
            this.close();

    }

    close() {

        document.getElementById("settings-overlay")?.remove();

        document.removeEventListener("keydown", this.handleEscape);

    }

    open() {

        this.close();

        const canvas = document.getElementById("canvas");

        if (!canvas)
            return;

        const overlay = document.createElement("div");

        overlay.id = "settings-overlay";

        overlay.className = "modal-overlay";

        overlay.addEventListener("click", (e) => {

            if (e.target === overlay)
                this.close();

        });

        const modal = document.createElement("div");

        modal.className = "modal";

        const title = document.createElement("h2");

        title.className = "modal-title";

        title.textContent = t("Configuración del lienzo");

        modal.appendChild(title);

        /* ---- size presets ---- */

        const presets = document.createElement("div");

        presets.className = "segmented-control";

        presets.style.marginBottom = "16px";

        const currentWidth = parseInt(canvas.style.maxWidth) || 900;

        const PRESETS = [["Desktop", 1280], ["Tablet", 768], ["Móvil", 375]];

        PRESETS.forEach(([label, px]) => {

            const btn = document.createElement("button");

            btn.type = "button";

            btn.textContent = t(label, label);

            if (currentWidth === px)
                btn.classList.add("active");

            btn.addEventListener("click", () => {

                canvas.style.maxWidth = px + "px";

                widthInput.value = px;

                [...presets.children].forEach(b => b.classList.remove("active"));

                btn.classList.add("active");

            });

            presets.appendChild(btn);

        });

        modal.appendChild(presets);

        /* ---- custom width ---- */

        const widthRow = document.createElement("div");

        widthRow.className = "property-row";

        widthRow.style.marginBottom = "12px";

        const widthLabel = document.createElement("label");

        widthLabel.textContent = t("Ancho");

        const widthWrap = document.createElement("div");

        widthWrap.className = "input-unit-wrap";

        const widthInput = document.createElement("input");

        widthInput.type = "number";

        widthInput.min = 320;

        widthInput.value = currentWidth;

        widthInput.addEventListener("input", () => {

            if (widthInput.value === "")
                return;

            canvas.style.maxWidth = widthInput.value + "px";

            [...presets.children].forEach(b => b.classList.remove("active"));

        });

        const unit = document.createElement("span");

        unit.className = "unit";

        unit.textContent = "px";

        widthWrap.appendChild(widthInput);

        widthWrap.appendChild(unit);

        widthRow.appendChild(widthLabel);

        widthRow.appendChild(widthWrap);

        modal.appendChild(widthRow);

        /* ---- background color ---- */

        const bgRow = document.createElement("div");

        bgRow.className = "property-row";

        const bgLabel = document.createElement("label");

        bgLabel.textContent = t("Color de fondo");

        const bgInput = document.createElement("input");

        bgInput.type = "color";

        bgInput.value = Utils.rgbToHex(
            canvas.style.backgroundColor || window.getComputedStyle(canvas).backgroundColor
        );

        bgInput.addEventListener("input", () => {

            canvas.style.backgroundColor = bgInput.value;

        });

        bgRow.appendChild(bgLabel);

        bgRow.appendChild(bgInput);

        modal.appendChild(bgRow);

        /* ---- close ---- */

        const closeBtn = document.createElement("button");

        closeBtn.type = "button";

        closeBtn.className = "btn primary";

        closeBtn.style.marginTop = "16px";

        closeBtn.style.width = "100%";

        closeBtn.textContent = t("Cerrar");

        closeBtn.addEventListener("click", () => this.close());

        modal.appendChild(closeBtn);

        overlay.appendChild(modal);

        document.body.appendChild(overlay);

        document.addEventListener("keydown", this.handleEscape);

    }

}

window.Settings = new SettingsManager();
