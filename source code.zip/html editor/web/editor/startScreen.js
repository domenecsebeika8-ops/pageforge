// web/editor/startScreen.js
//
// Shown once when the app launches: pick a starting template and configure
// the page title + canvas size, all on the same screen. Confirming replaces
// the canvas contents with the chosen template and applies the size.

// Seed content for each starting template — stamped onto the canvas once
// when the user picks a template, so (like Canvas's element presets) it's
// written directly in the base language (English) rather than kept as a
// live-translated i18n key: it's page content the user immediately owns
// and edits, not app chrome.
const START_TEMPLATES = {

    blank: "",

    landing: `
        <div class="canvas-element" style="text-align:center;padding:40px 20px;">
            <h1 class="canvas-element">Your amazing product</h1>
            <p class="canvas-element">A sentence that explains the value of what you offer.</p>
            <button class="canvas-element">Get started now</button>
        </div>
    `,

    portfolio: `
        <div class="canvas-element">
            <h1 class="canvas-element">My Portfolio</h1>
            <p class="canvas-element">A selection of my projects.</p>
        </div>
        <div class="canvas-element" style="display:flex;flex-wrap:wrap;gap:16px;">
            <img class="canvas-element" src="${Utils.imagePlaceholder("Image", 300, 160)}" alt="Image" style="display:block;flex:1;min-width:160px;height:160px;object-fit:cover;">
            <img class="canvas-element" src="${Utils.imagePlaceholder("Image", 300, 160)}" alt="Image" style="display:block;flex:1;min-width:160px;height:160px;object-fit:cover;">
            <img class="canvas-element" src="${Utils.imagePlaceholder("Image", 300, 160)}" alt="Image" style="display:block;flex:1;min-width:160px;height:160px;object-fit:cover;">
        </div>
    `,

    blog: `
        <div class="canvas-element" style="margin-bottom:32px;">
            <h1 class="canvas-element">My Blog</h1>
            <p class="canvas-element">Notes, ideas, and things I've learned.</p>
        </div>
        <div class="canvas-element" style="padding:16px 0;border-top:1px solid #E5E5E5;">
            <span class="canvas-element" style="font-size:12px;color:#999;">January 12, 2026</span>
            <h2 class="canvas-element" style="margin:6px 0;">First post title</h2>
            <p class="canvas-element">A short summary of what this blog post is about.</p>
        </div>
        <div class="canvas-element" style="padding:16px 0;border-top:1px solid #E5E5E5;">
            <span class="canvas-element" style="font-size:12px;color:#999;">January 3, 2026</span>
            <h2 class="canvas-element" style="margin:6px 0;">Second post title</h2>
            <p class="canvas-element">Another short summary for this second post.</p>
        </div>
    `,

    store: `
        <div class="canvas-element" style="text-align:center;margin-bottom:32px;">
            <h1 class="canvas-element">Simple Store</h1>
            <p class="canvas-element">Products selected just for you.</p>
        </div>
        <div class="canvas-element" style="display:flex;gap:16px;">
            <div class="canvas-element" style="flex:1;">
                <img class="canvas-element" src="${Utils.imagePlaceholder("Image", 280, 140)}" alt="Image" style="display:block;width:100%;height:140px;object-fit:cover;border-radius:8px;margin-bottom:8px;">
                <strong class="canvas-element">Product one</strong>
                <p class="canvas-element" style="margin:4px 0;">$29.99</p>
                <button class="canvas-element">Add to cart</button>
            </div>
            <div class="canvas-element" style="flex:1;">
                <img class="canvas-element" src="${Utils.imagePlaceholder("Image", 280, 140)}" alt="Image" style="display:block;width:100%;height:140px;object-fit:cover;border-radius:8px;margin-bottom:8px;">
                <strong class="canvas-element">Product two</strong>
                <p class="canvas-element" style="margin:4px 0;">$39.99</p>
                <button class="canvas-element">Add to cart</button>
            </div>
        </div>
    `,

    resume: `
        <div class="canvas-element" style="margin-bottom:24px;">
            <h1 class="canvas-element">First Last</h1>
            <p class="canvas-element">Product Designer — city@email.com</p>
        </div>
        <div class="canvas-element" style="margin-bottom:20px;">
            <h2 class="canvas-element">Experience</h2>
            <p class="canvas-element"><strong class="canvas-element">Role — Company</strong> (2023 – present)</p>
            <p class="canvas-element">Brief description of your responsibilities and achievements.</p>
        </div>
        <div class="canvas-element">
            <h2 class="canvas-element">Skills</h2>
            <p class="canvas-element">Product design, prototyping, user research.</p>
        </div>
    `

};

const START_TEMPLATE_OPTIONS = [
    { key: "blank", label: "En blanco", desc: "Empieza desde cero." },
    { key: "landing", label: "Landing simple", desc: "Titular, texto y botón de llamada a la acción." },
    { key: "portfolio", label: "Portfolio básico", desc: "Encabezado y una cuadrícula de proyectos." },
    { key: "blog", label: "Blog", desc: "Encabezado y una lista de artículos." },
    { key: "store", label: "Tienda simple", desc: "Encabezado y una cuadrícula de productos." },
    { key: "resume", label: "Currículum", desc: "Nombre, experiencia y habilidades." }
];

const START_SIZE_PRESETS = [["Desktop", 1280], ["Tablet", 768], ["Móvil", 375]];

class StartScreenManager {

    constructor() {

        this.selectedTemplate = "blank";

        this.selectedWidth = 1280;

    }

    show() {

        const canvas = document.getElementById("canvas");

        if (!canvas)
            return;

        const overlay = document.createElement("div");

        overlay.id = "start-overlay";

        overlay.className = "modal-overlay";

        const modal = document.createElement("div");

        modal.className = "modal";

        modal.style.width = "420px";

        const title = document.createElement("h2");

        title.className = "modal-title";

        title.textContent = t("Nuevo proyecto");

        modal.appendChild(title);

        const subtitle = document.createElement("div");

        subtitle.className = "modal-subtitle";

        subtitle.textContent = t("Elige una plantilla y configura tu página.");

        modal.appendChild(subtitle);

        /* ---- template picker ---- */

        modal.appendChild(this.fieldLabel("Plantilla"));

        const templateGrid = document.createElement("div");

        templateGrid.style.cssText = "display:flex;flex-direction:column;gap:8px;margin-bottom:16px;";

        START_TEMPLATE_OPTIONS.forEach(tpl => {

            const card = document.createElement("button");

            card.type = "button";

            card.className = "template-card";

            if (tpl.key === this.selectedTemplate)
                card.classList.add("active");

            const strong = document.createElement("strong");

            strong.textContent = t(tpl.label, tpl.label);

            const span = document.createElement("span");

            span.textContent = t(tpl.desc, tpl.desc);

            card.appendChild(strong);

            card.appendChild(span);

            card.addEventListener("click", () => {

                this.selectedTemplate = tpl.key;

                [...templateGrid.children].forEach(c => c.classList.remove("active"));

                card.classList.add("active");

            });

            templateGrid.appendChild(card);

        });

        modal.appendChild(templateGrid);

        /* ---- page title ---- */

        modal.appendChild(this.fieldLabel("Título de la página"));

        const titleInput = document.createElement("input");

        titleInput.type = "text";

        titleInput.value = t("Mi página");

        titleInput.style.cssText =
            "width:100%;background:var(--bg-app);border:1px solid transparent;color:var(--text-primary);" +
            "padding:8px 10px;border-radius:6px;font-size:13px;margin-bottom:16px;";

        modal.appendChild(titleInput);

        /* ---- canvas size ---- */

        modal.appendChild(this.fieldLabel("Tamaño de lienzo"));

        const sizeSeg = document.createElement("div");

        sizeSeg.className = "segmented-control";

        sizeSeg.style.marginBottom = "20px";

        START_SIZE_PRESETS.forEach(([label, px]) => {

            const btn = document.createElement("button");

            btn.type = "button";

            btn.textContent = t(label, label);

            if (px === this.selectedWidth)
                btn.classList.add("active");

            btn.addEventListener("click", () => {

                this.selectedWidth = px;

                [...sizeSeg.children].forEach(b => b.classList.remove("active"));

                btn.classList.add("active");

            });

            sizeSeg.appendChild(btn);

        });

        modal.appendChild(sizeSeg);

        /* ---- start ---- */

        const startBtn = document.createElement("button");

        startBtn.type = "button";

        startBtn.className = "btn primary";

        startBtn.style.cssText = "width:100%;padding:10px 0;font-size:13px;";

        startBtn.textContent = t("Empezar");

        startBtn.addEventListener("click", () => {

            canvas.innerHTML = START_TEMPLATES[this.selectedTemplate] ?? "";

            canvas.style.maxWidth = this.selectedWidth + "px";

            window.pageSettings.title = titleInput.value.trim() || t("Página sin título");

            window.History?.clear();

            window.Selection?.clear();

            overlay.remove();

        });

        modal.appendChild(startBtn);

        overlay.appendChild(modal);

        document.body.appendChild(overlay);

    }

    fieldLabel(text) {

        const label = document.createElement("label");

        label.textContent = t(text, text);

        label.style.cssText = "font-size:11px;color:var(--text-secondary);display:block;margin-bottom:8px;";

        return label;

    }

}

window.StartScreen = new StartScreenManager();
