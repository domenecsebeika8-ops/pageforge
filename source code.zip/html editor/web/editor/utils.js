// web/editor/utils.js

class Utils {

    /* =========================================================
       DOM
    ========================================================= */

    static create(tag, options = {}) {

        const element = document.createElement(tag);

        Object.entries(options).forEach(([key, value]) => {

            switch (key) {

                case "class":
                    element.className = value;
                    break;

                case "text":
                    element.textContent = value;
                    break;

                case "html":
                    element.innerHTML = value;
                    break;

                default:
                    element.setAttribute(key, value);

            }

        });

        return element;

    }

    /* ========================================================= */

    static empty(element) {

        while (element.firstChild)

            element.removeChild(element.firstChild);

    }

    /* ========================================================= */

    static clamp(value, min, max) {

        return Math.max(

            min,

            Math.min(

                max,

                value

            )

        );

    }

    /* ========================================================= */

    static capitalize(text) {

        if (!text)

            return "";

        return text.charAt(0).toUpperCase()

            + text.slice(1);

    }

    /* ========================================================= */

    static kebabToCamel(text) {

        return text.replace(

            /-([a-z])/g,

            (_, c) => c.toUpperCase()

        );

    }

    /* ========================================================= */

    static camelToKebab(text) {

        return text.replace(

            /([a-z])([A-Z])/g,

            "$1-$2"

        ).toLowerCase();

    }

    /* ========================================================= */

    static uuid() {

        return crypto.randomUUID();

    }

    /* ========================================================= */

    static rgbToHex(rgb) {

        if (!rgb)

            return "#000000";

        if (rgb.startsWith("#"))

            return rgb;

        const values = rgb.match(/\d+/g);

        if (!values)

            return "#000000";

        return "#"

            + values

                .slice(0,3)

                .map(v =>

                    Number(v)

                        .toString(16)

                        .padStart(2,"0")

                )

                .join("");

    }

    /* ========================================================= */

    static hexToRgb(hex) {

        hex = hex.replace("#","");

        const bigint = parseInt(hex,16);

        const r = (bigint >> 16) & 255;

        const g = (bigint >> 8) & 255;

        const b = bigint & 255;

        return `rgb(${r}, ${g}, ${b})`;

    }

    /* ========================================================= */

    static copy(text) {

        navigator.clipboard.writeText(text);

    }

    /* ========================================================= */

    static download(filename, content) {

        // Inside the pywebview desktop shell, prefer the native Save
        // dialog (see main.py's save_file) — a blob: URL + <a download>
        // click doesn't reliably trigger a real download in the embedded
        // WebView2 (it can get handed off to Windows' "Open with"
        // resolver instead, which fails).
        if (window.pywebview?.api?.save_file) {

            window.pywebview.api.save_file(filename, content);

            return;

        }

        // Fallback for running in a regular browser tab (e.g. testing).
        const blob = new Blob(

            [content],

            {

                type: "text/plain"

            }

        );

        const url = URL.createObjectURL(blob);

        const a = document.createElement("a");

        a.href = url;

        a.download = filename;

        a.click();

        URL.revokeObjectURL(url);

    }

    /* ========================================================= */

    // A gray placeholder box with a centered label, as a data: URI SVG —
    // used everywhere the app needs a stand-in image (the "Image" preset,
    // the "Card"/"Label" presets' nested images, the start templates'
    // project/product slots). Centralized here so every placeholder is a
    // real <img>, not a plain styled <div> — that matters because only a
    // real <img> gets the Image section (upload/crop/filters/fit/fade) in
    // the inspector; Renderer.resolveKind() infers kind "image" from the
    // tag name alone when no data-kind is set, so this alone is enough to
    // make any of these instantly editable as a proper image.
    static imagePlaceholder(label, w = 300, h = 180) {

        return "data:image/svg+xml;utf8," + encodeURIComponent(
            `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">` +
            `<rect width="100%" height="100%" fill="#E5E5E5"/>` +
            `<text x="50%" y="50%" font-family="sans-serif" font-size="16" fill="#999" ` +
            `text-anchor="middle" dominant-baseline="middle">${label}</text></svg>`
        );

    }

    /* ========================================================= */

    static debounce(callback, delay = 250) {

        let timer;

        return (...args) => {

            clearTimeout(timer);

            timer = setTimeout(() => {

                callback(...args);

            }, delay);

        };

    }

    /* ========================================================= */

    static throttle(callback, delay = 100) {

        let waiting = false;

        return (...args) => {

            if (waiting)

                return;

            callback(...args);

            waiting = true;

            setTimeout(() => {

                waiting = false;

            }, delay);

        };

    }

}

window.Utils = Utils;